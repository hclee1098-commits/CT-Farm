CT-Farm 별도 React Native 앱 빌드 소스입니다. APK/IPA가 아닙니다.
Node 24.3 이상 호환 버전에서 npm ci --workspaces=false 후 설정하세요.
.env.example의 공개 API 주소를 .env.local에 설정합니다. 비밀키를 넣지 마세요.
기존 DB/업로드/웹/API 환경파일은 포함하지 않았습니다.
Android SDK 37 / build-tools 37.0.0 / NDK 27.1.12297006, iOS는 Mac/Xcode/서명이 필요합니다.
EAS 원격 업로드/서명은 별도 계정·승인·검증이 필요합니다. 개발 키로 운영 배포하지 마세요.
보안 검토 미완료: 생성 시점 모바일 npm audit은 Expo CLI Zod3/deepmerge 영향 8개 패키지(높음3/낮음5)를 보고했습니다.
개발 서버는 localhost만 사용하고 신뢰할 수 없는 설정/플러그인을 실행하지 마세요. 운영 배포 전 호환 보안 대응이 필요합니다.
실제 카메라/보안 저장소/기기 UI/Android APK/iOS 바이너리는 아직 검증하지 않았습니다.
