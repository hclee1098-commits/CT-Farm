# SECURE STARTER V5 수정본

보안 수정 및 검증 내역은 `검증결과.md`를 확인하세요. 기존 회원가입·로그인·세션 갱신·로그아웃·게시글 CRUD·파일 업로드/다운로드/삭제·툴킷 화면을 유지했습니다.

## Windows 신규 설치

필수 환경: Node.js 22 이상, Windows PowerShell 5.1, 실행 중인 Docker Desktop.

프로젝트 루트에서 Windows PowerShell을 열고 실행합니다.

```powershell
.\SECURE-LIFECYCLE.ps1 -Action SETUP
.\SECURE-LIFECYCLE.ps1 -Action STARTER
```

종료:

```powershell
.\SECURE-LIFECYCLE.ps1 -Action STOP
```

최초 설치가 환경 변수와 설치 식별자를 생성하고 충돌하지 않는 포트를 예약합니다. 화면 주소는 설치/시작 메시지를 확인하세요. 실제 비밀키는 제공된 예시 값 대신 새로 생성됩니다. 기존 데이터가 확인되면 기존 보호 로직이 적용됩니다.

## Windows EXE 생성

첨부에 기존 EXE의 바이너리가 없으므로 EXE를 동봉하지 않았습니다. .NET Framework의 C# 컴파일러가 있는 Windows에서 다음 명령으로 SETUP.exe, STARTER.exe, STOP.exe를 생성할 수 있습니다.

```powershell
.\tools\build-launchers.ps1
```

기존 EXE가 있으면 먼저 백업합니다. 새 EXE의 컴파일·실행과 Windows 프로세스 제어는 클라우드에서 검증하지 못했습니다. 소스의 SETUP 동작도 동일한 런처에서 지원하도록 보완했습니다.

## 기존 설치에 적용할 때

기존 설치 폴더와 실제 DB는 클라우드에 제공되지 않았습니다. 이 압축 파일은 소스 수정본이며 운영 데이터의 백업을 대신하지 않습니다. 기존 설치를 변경하기 전에 해당 PC에서 프로젝트 폴더와 PostgreSQL 데이터를 별도로 백업하세요. 기존 `.env`, `apps/api/.env`, `apps/web/.env.local`, `.starter-state`, `uploads` 및 Docker 볼륨을 새 파일로 교체하거나 삭제하지 마세요.

Prisma 스키마와 마이그레이션 SQL은 변경하지 않았습니다. DB 초기화 명령을 추가하지 않았습니다. 설치 경로를 옮기면 기존 V5의 설치 식별자 검사가 중단시키므로 원래 설치 경로를 유지하세요.

## 검증 명령

Windows의 문법/BOM 검사와 전체 검증:

```powershell
.\tools\verify-starter.ps1
```

Node.js 공통 검증:

```text
npm ci
npm run verify
node tools/smoke-web.mjs
```

`npm run verify`는 소스 인코딩·잠금 파일 검사, Prisma Client 생성, API/웹 테스트, 전체 빌드, 의존성 보안 검사를 순서대로 실행합니다. `smoke-web.mjs`는 빌드된 웹 서버를 임시 포트에서 실행해 루트 이동과 9개 화면의 HTTP 응답/보안 헤더를 확인한 뒤 해당 서버를 종료합니다. 브라우저 클릭 동작의 E2E 검사를 대신하지 않습니다.

Windows 실제 서비스 통합 검증은 SETUP/STARTER 실행 후 다음 명령을 사용합니다.

```powershell
.\SECURE-TEST.ps1
```

이 스크립트는 설치 식별자의 포트와 Docker 프로젝트를 사용하고 임시 테스트 계정을 생성한 뒤 그 계정만 정리합니다. 실제 PostgreSQL·Redis·Docker 통합 동작은 클라우드에서 검증하지 못했습니다.

## 설정 및 보존된 이전 스크립트

- 웹 API 주소는 `NEXT_PUBLIC_API_BASE_URL`, `NEXT_PUBLIC_API_URL` 순으로 적용합니다. HTTP(S) 출처 또는 `/api/v1`까지의 주소를 허용하며 모든 웹 클라이언트가 같은 규칙을 사용합니다.
- 운영 환경의 허용 웹 출처는 HTTPS여야 합니다. 예시 JWT 비밀키는 시작 단계에서 거부합니다.
- Next/React 버전을 잠금 파일의 검증된 버전으로 고정했습니다.
- 모든 PS1은 UTF-8 BOM/CRLF로 저장했으며 `.editorconfig`에 해당 규칙을 추가했습니다.
- 이전 부별 생성 스크립트는 이력 보존용으로 남겼습니다. 완성된 V5에 다시 적용하지 마세요. `SECURITY-REVISION.json`이 있는 대상에는 적용을 차단합니다.
- 원본에서 비어 있던 `repair-starter-part8.ps1`은 실행 시 이유를 알리고 중단하도록 변경했습니다. 제공되지 않은 복구 기능을 만들어냈다고 간주하면 안 됩니다.

