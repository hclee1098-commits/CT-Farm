<!-- filepath: apps/api/src/bootstrap/README.md - 통합 API 서버 실행 방법 및 보안 설정 안내 -->
# Express 통합 서버

## 1. 개요

이 디렉터리는 인증, CRUD, 파일 관리 기능을
하나의 Express 서버로 통합합니다.

기존 API 모듈은 변경하지 않습니다.

## 2. 서버 주소

기본 포트는 4000입니다.

기본 주소:

http://localhost:4000

## 3. 환경 변수

PORT=4000

TRUST_PROXY_HOPS=0

JSON_BODY_LIMIT=1mb

SHUTDOWN_TIMEOUT_MS=10000

기존 DATABASE_URL, REDIS_URL, JWT 관련 설정은
기존 환경 설정 파일을 그대로 사용합니다.

## 4. 개발 실행

API 프로젝트에 tsx가 설치되어 있어야 합니다.

루트 디렉터리에서 실행:

npm run dev -w @starter/api

또는:

npm run dev

루트 dev 명령이 API와 웹을 동시에 실행하도록
설정되어 있는 경우 두 서버가 함께 실행됩니다.

## 5. 헬스체크

GET /health

GET /health/live

GET /health/ready

/health/live는 HTTP 프로세스 상태를 확인합니다.

/health/ready는 PostgreSQL과 Redis 연결을 확인합니다.

## 6. 인증 API

/api/v1/auth

웹과 모바일 앱이 동일한 회원 데이터를 사용합니다.

## 7. 게시글 API

/api/v1/notes

JWT 인증이 필요합니다.

## 8. 파일 API

/api/v1/files

JWT 인증이 필요합니다.

## 9. 보안 설정

Helmet을 사용하여 HTTP 보안 헤더를 적용합니다.

CORS는 기존 환경 변수에 등록된 출처만 허용합니다.

JSON 요청 본문 크기를 제한합니다.

Redis 기반 API 요청 제한을 적용합니다.

요청마다 새로운 Request ID를 생성합니다.

비밀번호와 인증 토큰은 HTTP 로그에 기록하지 않습니다.

## 10. Reverse Proxy

기본 TRUST_PROXY_HOPS는 0입니다.

프록시 서버를 사용하는 경우
실제 프록시 홉 수와 네트워크 구성을 확인해야 합니다.

잘못된 프록시 설정은 IP 기반 요청 제한의
신뢰성을 떨어뜨릴 수 있습니다.

## 11. 서버 종료

SIGINT 또는 SIGTERM을 받으면
새로운 HTTP 요청 수신을 중지합니다.

진행 중인 요청의 종료를 기다린 뒤
Prisma와 Redis 연결을 정리합니다.

## 12. 주의사항

기존 1~4부의 실제 TypeScript 타입 호환성은
빌드 검사를 통해 확인해야 합니다.

이 통합 서버만으로 모든 보안 검증이
완료되었다고 판단해서는 안 됩니다.

운영 환경에서는 HTTPS, 프록시 설정,
데이터베이스 권한, 인증 보안, 파일 검사,
백업 및 복구 정책을 추가로 검증해야 합니다.

## 13. 운영 배포

현재 통합 실행 명령은 개발 환경을 기준으로 합니다.

운영 배포에서는 TypeScript 빌드 결과를
실행하도록 별도 배포 구성을 검증해야 합니다.

운영 환경에 tsx 개발 실행 명령을
그대로 사용하는 것은 권장하지 않습니다.

