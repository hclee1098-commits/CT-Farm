<!-- filepath: apps/api/src/modules/auth/README.md - 웹과 모바일 앱 인증 API 사용 방법 안내 -->
# 인증 API 사용 설명서

## 개요

웹 브라우저와 모바일 앱은 동일한 회원 데이터베이스를 사용합니다.

Refresh Token 전달 방식은 서로 다릅니다.

웹 브라우저:
- Access Token: 메모리에 저장
- Refresh Token: HttpOnly Cookie

모바일 앱:
- Access Token: 메모리에 저장
- Refresh Token: 운영체제 보안 저장소

## 웹 회원가입

POST /api/v1/auth/web/register

요청 JSON 예시:

{
  "email": "test@example.com",
  "password": "StrongPassword123!",
  "name": "테스트회원"
}

성공하면 회원 정보와 Access Token을 반환합니다.

Refresh Token은 HttpOnly Cookie로 전달됩니다.

## 웹 로그인

POST /api/v1/auth/web/login

요청 JSON 예시:

{
  "email": "test@example.com",
  "password": "StrongPassword123!"
}

웹에서는 credentials: "include" 옵션을 사용합니다.

## 웹 토큰 갱신

POST /api/v1/auth/web/refresh

Refresh Token은 쿠키에서 자동으로 읽습니다.

성공하면 새로운 Access Token을 반환합니다.

## 웹 로그아웃

POST /api/v1/auth/web/logout

현재 브라우저의 Refresh Token 세션을 종료합니다.

## 모바일 앱 회원가입

POST /api/v1/auth/mobile/register

요청 JSON 예시:

{
  "email": "test@example.com",
  "password": "StrongPassword123!",
  "name": "테스트회원"
}

## 모바일 앱 로그인

POST /api/v1/auth/mobile/login

요청 JSON 예시:

{
  "email": "test@example.com",
  "password": "StrongPassword123!"
}

성공하면 Access Token과 Refresh Token을 반환합니다.

모바일 앱은 Refresh Token을 안전한 저장소에 보관해야 합니다.

## 모바일 앱 토큰 갱신

POST /api/v1/auth/mobile/refresh

요청 JSON 예시:

{
  "refreshToken": "기존_Refresh_Token"
}

성공하면 새로운 Access Token과 Refresh Token을 반환합니다.

기존 Refresh Token은 사용할 수 없게 됩니다.

## 모바일 앱 로그아웃

POST /api/v1/auth/mobile/logout

요청 JSON 예시:

{
  "refreshToken": "현재_Refresh_Token"
}

## 내 정보 조회

GET /api/v1/auth/me

요청 헤더:

Authorization: Bearer ACCESS_TOKEN

## 전체 기기 로그아웃

POST /api/v1/auth/logout-all

요청 헤더:

Authorization: Bearer ACCESS_TOKEN

모든 Refresh Token 세션을 종료합니다.

기존 Access Token도 무효화됩니다.

## 보안 주의사항

1. 운영 환경에서는 반드시 HTTPS를 사용합니다.
2. JWT 비밀키를 소스코드에 저장하지 않습니다.
3. Refresh Token을 로그에 기록하지 않습니다.
4. 모바일 앱은 운영체제 보안 저장소를 사용합니다.
5. Refresh Token은 갱신할 때마다 교체합니다.
6. 인증 요청에는 Rate Limiting을 적용합니다.
7. 쿠키 기반 요청에는 CSRF 방어가 필요합니다.
8. 실제 운영 전 보안 테스트를 수행해야 합니다.

