<!-- filepath: apps/api/src/modules/notes/README.md - 게시글 CRUD API 사용법과 보안 설계 안내 -->
# 게시글 CRUD API 사용 설명서

## 1. 개요

이 모듈은 웹과 모바일 앱에서 공통으로 사용하는
게시글 CRUD 기능을 제공합니다.

모든 API는 JWT Access Token 인증이 필요합니다.

게시글은 사용자별로 분리됩니다.

다른 사용자의 게시글은 조회, 수정, 삭제할 수 없습니다.

## 2. 인증

모든 요청에 다음 HTTP 헤더가 필요합니다.

Authorization: Bearer ACCESS_TOKEN

## 3. 게시글 등록

POST /api/v1/notes

요청 JSON:

{
  "title": "게시글 제목",
  "content": "게시글 내용"
}

성공 HTTP 상태 코드: 201

## 4. 게시글 목록 조회

GET /api/v1/notes

지원하는 Query 파라미터:

page: 페이지 번호

limit: 페이지당 조회 개수

search: 제목과 내용 검색어

sortBy: 정렬 필드

sortOrder: 정렬 방향

기본값:

page = 1

limit = 20

sortBy = createdAt

sortOrder = desc

조회 개수는 최대 100개입니다.

정렬 필드:

createdAt

updatedAt

title

정렬 방향:

asc

desc

예시:

GET /api/v1/notes?page=1&limit=20

GET /api/v1/notes?search=테스트

GET /api/v1/notes?sortBy=title&sortOrder=asc

GET /api/v1/notes?page=2&limit=10&search=안내

## 5. 목록 응답

{
  "success": true,
  "data": {
    "items": [],
    "pagination": {
      "page": 1,
      "limit": 20,
      "total": 0,
      "totalPages": 0,
      "hasNext": false,
      "hasPrevious": false
    }
  },
  "message": "게시글 목록을 조회했습니다."
}

## 6. 게시글 상세 조회

GET /api/v1/notes/:id

게시글 ID는 UUID 형식이어야 합니다.

## 7. 게시글 전체 수정

PUT /api/v1/notes/:id

요청 JSON:

{
  "title": "수정한 제목",
  "content": "수정한 내용"
}

제목과 내용을 모두 전달해야 합니다.

## 8. 게시글 부분 수정

PATCH /api/v1/notes/:id

요청 JSON:

{
  "title": "수정한 제목"
}

또는:

{
  "content": "수정한 내용"
}

수정할 필드를 하나 이상 전달해야 합니다.

## 9. 게시글 삭제

DELETE /api/v1/notes/:id

삭제에 성공하면 deleted: true를 반환합니다.

## 10. 보안 정책

1. 모든 요청에 JWT 인증을 적용합니다.

2. ownerId는 클라이언트에서 받지 않습니다.

3. ownerId는 인증된 사용자 정보에서 가져옵니다.

4. 데이터베이스 조회 시 ownerId 조건을 적용합니다.

5. 수정 및 삭제 시에도 ownerId 조건을 적용합니다.

6. 다른 사용자의 게시글은 404로 응답합니다.

7. 정렬 가능한 필드를 제한합니다.

8. 페이지당 조회 개수를 최대 100개로 제한합니다.

9. 제목과 내용 길이를 제한합니다.

10. 반환할 데이터베이스 필드를 명시합니다.

11. 검색에는 Prisma의 매개변수화된 쿼리를 사용합니다.

12. 클라이언트는 사용자 입력을 HTML로 직접 삽입하지 않아야 합니다.

## 11. 주의사항

이 모듈은 인증 모듈과 Prisma 연결 모듈에 의존합니다.

Express 서버에 notesRouter를 등록해야 실제 API가 동작합니다.

이 모듈의 DTO 테스트만으로 DB 접근 권한이
검증되었다고 판단해서는 안 됩니다.

운영 전에는 실제 PostgreSQL을 이용한
사용자별 접근 권한 통합 테스트가 필요합니다.

