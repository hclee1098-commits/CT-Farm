// filepath: apps/web/src/app/layout.tsx - Next.js 최상위 HTML 레이아웃
import type { ReactNode } from "react";

export default function RootLayout({
  children
}: {
  children: ReactNode;
}) {
  return (
    <html lang="ko">
      <body>{children}</body>
    </html>
  );
}

