// filepath: apps/web/src/app/starter/page.tsx - Starter Kit 메인 대시보드
"use client";

import Link from "next/link";

import {
  useAuth
} from "./_lib/auth";

export default function StarterHome() {

  const {
    user,
    loading
  } = useAuth();

  return (
    <div className="starter-container">

      <section className="starter-hero">

        <div className="starter-badge">
          FULLSTACK STARTER KIT
        </div>

        <h1>
          웹과 모바일 앱을 위한
          <br />
          공통 개발 환경
        </h1>

        <p>
          Next.js, Express, PostgreSQL,
          Prisma, Redis를 연결한
          풀스택 공통 프로젝트입니다.
        </p>

        {!loading && !user && (
          <div className="starter-actions">

            <Link
              href="/starter/register"
              className="starter-button large"
            >
              시작하기
            </Link>

            <Link
              href="/starter/login"
              className="starter-button secondary large"
            >
              로그인
            </Link>

          </div>
        )}

        {!loading && user && (
          <div className="starter-welcome">

            <h2>
              {user.name}님, 환영합니다.
            </h2>

            <p>
              공통 기능을 활용해
              새로운 서비스를 개발할 수 있습니다.
            </p>

          </div>
        )}

      </section>

      <section className="starter-grid">

        <Link
          href="/starter/notes"
          className="starter-card"
        >

          <div className="starter-card-icon">
            📝
          </div>

          <h2>게시글 관리</h2>

          <p>
            게시글 등록, 조회, 수정, 삭제와
            검색 및 페이징을 제공합니다.
          </p>

          <span>기능 열기 →</span>

        </Link>

        <Link
          href="/starter/files"
          className="starter-card"
        >

          <div className="starter-card-icon">
            📁
          </div>

          <h2>파일 관리</h2>

          <p>
            파일 업로드, 다운로드,
            목록 조회 및 삭제 기능을 제공합니다.
          </p>

          <span>기능 열기 →</span>

        </Link>

        <div className="starter-card">

          <div className="starter-card-icon">
            🔐
          </div>

          <h2>공통 인증 시스템</h2>

          <p>
            JWT 인증과 Refresh Token을
            이용해 웹과 모바일 앱에서
            동일한 회원 시스템을 사용합니다.
          </p>

        </div>

      </section>

      {user && (
        <section className="starter-panel">

          <h2>내 계정 정보</h2>

          <div className="starter-info-row">
            <strong>이름</strong>
            <span>{user.name}</span>
          </div>

          <div className="starter-info-row">
            <strong>이메일</strong>
            <span>{user.email}</span>
          </div>

          <div className="starter-info-row">
            <strong>회원 ID</strong>
            <span>{user.id}</span>
          </div>

        </section>
      )}

    </div>
  );
}

