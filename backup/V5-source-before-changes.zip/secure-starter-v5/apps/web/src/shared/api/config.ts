// 모든 웹 API 호출이 같은 설정 우선순위와 출처를 사용합니다.
export function resolveApiOrigin(value: string): string {
  const url = new URL(value);
  if (!/^https?:$/.test(url.protocol) || url.username || url.password ||
      url.search || url.hash || !["/", "/api/v1", "/api/v1/"].includes(url.pathname)) {
    throw new Error("API 주소에는 HTTP(S) 출처 또는 /api/v1 주소를 지정하세요.");
  }
  return url.origin;
}

export const API_ORIGIN = resolveApiOrigin(
  process.env.NEXT_PUBLIC_API_BASE_URL ??
  process.env.NEXT_PUBLIC_API_URL ??
  "http://localhost:4000"
);
export const API_BASE_URL = `${API_ORIGIN}/api/v1`;

