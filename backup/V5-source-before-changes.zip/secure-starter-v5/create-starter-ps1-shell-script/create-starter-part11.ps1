﻿# filepath: create-starter-part11.ps1 - 11부 API 요청 추적 및 서버 준비 상태 관리 기능 생성

$ErrorActionPreference = "Stop"

Set-StrictMode -Version Latest

# ============================================================
# 1. 프로젝트 경로
# ============================================================

$Root = Join-Path $env:USERPROFILE "Desktop\secure-starter"

# 보안 검토가 끝난 프로젝트에 예전 생성 코드를 덮어쓰지 않습니다.
if (Test-Path -LiteralPath (Join-Path $Root "SECURITY-REVISION.json")) {
    throw "보안 수정이 적용된 V5입니다. 이전 부별 생성 스크립트 적용을 차단합니다."
}


if (-not (Test-Path -LiteralPath $Root)) {
    throw "secure-starter 프로젝트가 없습니다."
}

Set-Location $Root

Write-Host ""
Write-Host "============================================"
Write-Host " 11부 API 운영 안정성 강화"
Write-Host "============================================"
Write-Host ""

# ============================================================
# 2. 파일 경로 설정
# ============================================================

$AppRelative = "apps/api/src/bootstrap/app.ts"

$RequestRelative = "apps/api/src/bootstrap/observability/request-context.ts"

$ReadinessRelative = "apps/api/src/bootstrap/observability/readiness.ts"

$AppFile = Join-Path $Root $AppRelative

$RequestFile = Join-Path $Root $RequestRelative

$ReadinessFile = Join-Path $Root $ReadinessRelative

# ============================================================
# 3. 기존 프로젝트 확인
# ============================================================

if (-not (Test-Path -LiteralPath $AppFile)) {
    throw "기존 Express 애플리케이션 파일이 없습니다."
}

# 새로 생성할 파일이 이미 존재하면 덮어쓰지 않습니다.

foreach ($File in @($RequestFile, $ReadinessFile)) {

    if (Test-Path -LiteralPath $File) {

        throw "이미 파일이 존재합니다. 기존 파일을 보호하기 위해 중단합니다: $File"

    }

}

# ============================================================
# 4. 기존 Express 구조 확인
# ============================================================

$AppSource = [System.IO.File]::ReadAllText($AppFile)

# 이미 통합된 코드가 있다면 중복 적용하지 않습니다.

if (
    $AppSource.Contains("requestContext") -or
    $AppSource.Contains("readinessRouter") -or
    $AppSource.Contains('"/health/ready"')
) {

    throw "11부 기능이 이미 존재하거나 일부 적용되어 있습니다. 중복 수정을 중단합니다."

}

# 첫 번째 import 구문 확인

$ImportPattern = '(?m)^[ \t]*import\s'

$ImportMatches = [regex]::Matches(
    $AppSource,
    $ImportPattern
)

if ($ImportMatches.Count -eq 0) {

    throw "기존 app.ts의 import 구조를 확인할 수 없습니다."

}

# Express 애플리케이션 생성 구문 확인

$CreatePattern = '(?m)^[ \t]*(?:export\s+)?const\s+app(?:\s*:\s*[A-Za-z_][\w<>]*)?\s*=\s*express\s*\(\s*\)\s*;?'

$CreateMatches = [regex]::Matches(
    $AppSource,
    $CreatePattern
)

if ($CreateMatches.Count -ne 1) {

    throw "Express 애플리케이션 생성 구문이 예상과 다릅니다. 안전을 위해 수정하지 않습니다."

}

# 기존 미들웨어 등록 위치 확인

$UsePattern = '(?m)^[ \t]*app\.use\s*\('

$UseMatches = [regex]::Matches(
    $AppSource,
    $UsePattern
)

if ($UseMatches.Count -eq 0) {

    throw "기존 Express 미들웨어 등록 위치를 찾지 못했습니다."

}

if ($UseMatches[0].Index -le $CreateMatches[0].Index) {

    throw "Express 초기화 순서가 예상과 다릅니다."

}

# 기존 404 처리 위치 확인

$NotFoundPattern = '(?m)^[ \t]*app\.use\s*\(\s*notFoundHandler\s*\)\s*;?'

$NotFoundMatches = [regex]::Matches(
    $AppSource,
    $NotFoundPattern
)

if ($NotFoundMatches.Count -ne 1) {

    throw "기존 404 처리 위치를 확인할 수 없습니다. 안전을 위해 수정하지 않습니다."

}

if ($NotFoundMatches[0].Index -le $UseMatches[0].Index) {

    throw "404 처리 순서가 예상과 다릅니다."

}

Write-Host "[완료] 기존 Express 구조 확인" -ForegroundColor Green

# ============================================================
# 5. 요청 추적 미들웨어 소스
# ============================================================

$RequestSource = @'
// filepath: apps/api/src/bootstrap/observability/request-context.ts - 모든 HTTP 요청에 고유 식별자를 부여하는 공통 미들웨어

import {
  randomUUID
} from "node:crypto";

import type {
  RequestHandler
} from "express";

// ============================================================
// 요청 식별자 생성
// ============================================================

// 클라이언트가 전달한 임의의 Request ID를 신뢰하지 않습니다.
//
// 외부에서 전달한 식별자를 그대로 사용하면
// 로그 추적 과정에서 식별자 위조 문제가 발생할 수 있습니다.
//
// 따라서 서버에서 새로운 UUID를 생성합니다.

export const requestContext: RequestHandler = (
  req,
  res,
  next
) => {

  // ==========================================================
  // 고유 요청 식별자
  // ==========================================================

  const requestId = randomUUID();

  // 기존 HTTP 로깅 시스템과 연결합니다.
  req.id = requestId;

  // ==========================================================
  // HTTP 응답 헤더
  // ==========================================================

  // 브라우저와 모바일 앱에서
  // 서버 로그와 동일한 요청 식별자를 확인할 수 있습니다.

  res.setHeader(
    "X-Request-Id",
    requestId
  );

  // 응답이 별도의 캐시 시스템에 저장되더라도
  // 요청 식별자 헤더가 다른 요청에 재사용되지 않도록
  // 기존 캐시 정책을 변경하지는 않습니다.
  //
  // 실제 운영 환경에서는 CDN 및 프록시의
  // 응답 헤더 처리 정책도 함께 설정해야 합니다.

  next();
};
'@

# ============================================================
# 6. 서버 준비 상태 관리 소스
# ============================================================

$ReadinessSource = @'
// filepath: apps/api/src/bootstrap/observability/readiness.ts - PostgreSQL과 Redis의 준비 상태를 확인하는 운영용 API

import {
  Router
} from "express";

import {
  checkDatabase
} from "../../infrastructure/prisma";

import {
  checkRedis
} from "../../infrastructure/redis";

import {
  asyncHandler
} from "../../common/validate";

import {
  success,
  failure
} from "../../common/response";

// ============================================================
// 준비 상태 라우터
// ============================================================

export const readinessRouter = Router();

// ============================================================
// 상태 확인 캐시
// ============================================================

// 준비 상태 확인 요청이 짧은 시간에 반복되더라도
// 데이터베이스에 불필요한 조회가 발생하지 않도록 합니다.
//
// 캐시 시간은 3초입니다.

const CACHE_DURATION_MS = 3000;

interface ReadinessCache {
  ready: boolean;
  expiresAt: number;
}

let readinessCache: ReadinessCache | null = null;

// 동시에 여러 요청이 들어오면
// 하나의 상태 확인 작업을 공유합니다.

let activeCheck: Promise<boolean> | null = null;

// ============================================================
// 실제 서비스 준비 상태 확인
// ============================================================

async function performReadinessCheck(): Promise<boolean> {

  try {

    // PostgreSQL과 Redis를 병렬로 확인합니다.

    const [
      databaseReady,
      redisReady
    ] = await Promise.all([
      checkDatabase(),
      checkRedis()
    ]);

    // 두 서비스가 모두 정상이어야 준비 완료입니다.

    return databaseReady && redisReady;

  } catch {

    // 연결 오류의 상세 내용은 외부에 공개하지 않습니다.

    return false;

  }
}

// ============================================================
// 캐시 및 동시 실행 제어
// ============================================================

async function getReadiness(): Promise<boolean> {

  const now = Date.now();

  // 유효한 캐시가 있다면 재사용합니다.

  if (
    readinessCache &&
    now < readinessCache.expiresAt
  ) {

    return readinessCache.ready;

  }

  // 이미 상태 확인이 진행 중이면
  // 동일한 Promise를 재사용합니다.

  if (!activeCheck) {

    activeCheck = performReadinessCheck();

  }

  const currentCheck = activeCheck;

  try {

    const ready = await currentCheck;

    // 상태 확인 결과를 짧게 캐싱합니다.

    readinessCache = {
      ready,
      expiresAt: Date.now() + CACHE_DURATION_MS
    };

    return ready;

  } finally {

    // 현재 작업이 여전히 활성 작업일 때만 해제합니다.

    if (activeCheck === currentCheck) {

      activeCheck = null;

    }

  }
}

// ============================================================
// GET /health/ready
// ============================================================

// 이 API는 서버가 실제 요청을 처리할 준비가 되었는지
// 확인하기 위한 운영용 엔드포인트입니다.
//
// PostgreSQL 또는 Redis 연결에 문제가 있다면
// HTTP 503을 반환합니다.
//
// 외부 응답에는 내부 연결 주소나 비밀번호를 포함하지 않습니다.

readinessRouter.get(
  "/",

  asyncHandler(async (_req, res) => {

    // 상태 확인 응답을 브라우저나 프록시에 저장하지 않습니다.

    res.setHeader(
      "Cache-Control",
      "no-store"
    );

    const ready = await getReadiness();

    if (!ready) {

      failure(
        res,
        503,
        "SERVICE_NOT_READY",
        "서비스가 요청을 처리할 준비가 되지 않았습니다."
      );

      return;

    }

    success(
      res,
      {
        ready: true
      },
      "서비스가 정상적으로 준비되었습니다."
    );

  })
);
'@

# ============================================================
# 7. 기존 app.ts 통합 코드 준비
# ============================================================

# 원본 파일의 줄바꿈 형식을 확인합니다.

$Eol = "`n"

if ($AppSource.Contains("`r`n")) {

    $Eol = "`r`n"

}

# ============================================================
# 8. import 추가
# ============================================================

$ImportBlock = @'
import { requestContext } from "./observability/request-context";
import { readinessRouter } from "./observability/readiness";
'@

$ImportBlock = $ImportBlock.Replace(
    "`n",
    $Eol
)

$ImportBlock += $Eol + $Eol

$NewAppSource = $AppSource.Insert(
    $ImportMatches[0].Index,
    $ImportBlock
)

# ============================================================
# 9. 요청 추적 미들웨어 등록
# ============================================================

# 기존 미들웨어보다 먼저 등록합니다.
#
# 이렇게 해야 이후 로깅 및 오류 처리 과정에서
# 동일한 요청 식별자를 사용할 수 있습니다.

$NewUseMatches = [regex]::Matches(
    $NewAppSource,
    $UsePattern
)

if ($NewUseMatches.Count -eq 0) {

    throw "요청 추적 미들웨어 삽입 위치를 찾지 못했습니다."

}

$UseMatch = $NewUseMatches[0]

$UseLineStart = $NewAppSource.LastIndexOf(
    "`n",
    [Math]::Max(0, $UseMatch.Index - 1)
) + 1

$UseIndent = $NewAppSource.Substring(
    $UseLineStart,
    $UseMatch.Index - $UseLineStart
)

$RequestRegistration = (
    $UseIndent +
    "app.use(requestContext);" +
    $Eol +
    $Eol
)

$NewAppSource = $NewAppSource.Insert(
    $UseMatch.Index,
    $RequestRegistration
)

# ============================================================
# 10. 준비 상태 API 등록
# ============================================================

# 기존 404 처리보다 먼저 등록합니다.
#
# 기존 보안 미들웨어와 요청 제한 설정을 유지하면서
# 새로운 엔드포인트만 추가합니다.

$NewNotFoundMatches = [regex]::Matches(
    $NewAppSource,
    $NotFoundPattern
)

if ($NewNotFoundMatches.Count -ne 1) {

    throw "준비 상태 API 등록 위치를 확인하지 못했습니다."

}

$NotFoundMatch = $NewNotFoundMatches[0]

$NotFoundLineStart = $NewAppSource.LastIndexOf(
    "`n",
    [Math]::Max(0, $NotFoundMatch.Index - 1)
) + 1

$NotFoundIndent = $NewAppSource.Substring(
    $NotFoundLineStart,
    $NotFoundMatch.Index - $NotFoundLineStart
)

$ReadinessRegistration = (
    $NotFoundIndent +
    'app.use("/health/ready", readinessRouter);' +
    $Eol +
    $Eol
)

$NewAppSource = $NewAppSource.Insert(
    $NotFoundMatch.Index,
    $ReadinessRegistration
)

Write-Host "[완료] 기존 API 통합 코드 준비" -ForegroundColor Green

# ============================================================
# 11. 기존 파일 백업
# ============================================================

$BackupRoot = Join-Path $env:USERPROFILE (
    "Desktop\starter-part11-backup-" +
    (Get-Date -Format "yyyyMMdd_HHmmss")
)

$BackupFile = Join-Path $BackupRoot $AppRelative

$BackupDirectory = Split-Path $BackupFile -Parent

New-Item `
    -ItemType Directory `
    -Path $BackupDirectory `
    -Force |
    Out-Null

Copy-Item `
    -LiteralPath $AppFile `
    -Destination $BackupFile

Write-Host ""
Write-Host "[완료] 기존 app.ts 백업" -ForegroundColor Green

Write-Host "백업 위치: $BackupRoot"

# ============================================================
# 12. 파일 생성 및 저장
# ============================================================

$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)

try {

    # --------------------------------------------------------
    # 요청 추적 파일 생성
    # --------------------------------------------------------

    $RequestDirectory = Split-Path $RequestFile -Parent

    New-Item `
        -ItemType Directory `
        -Path $RequestDirectory `
        -Force |
        Out-Null

    [System.IO.File]::WriteAllText(
        $RequestFile,
        $RequestSource,
        $Utf8NoBom
    )

    Write-Host "[생성 완료] $RequestRelative" -ForegroundColor Green

    # --------------------------------------------------------
    # 서버 준비 상태 파일 생성
    # --------------------------------------------------------

    [System.IO.File]::WriteAllText(
        $ReadinessFile,
        $ReadinessSource,
        $Utf8NoBom
    )

    Write-Host "[생성 완료] $ReadinessRelative" -ForegroundColor Green

    # --------------------------------------------------------
    # 기존 Express 애플리케이션 통합
    # --------------------------------------------------------

    [System.IO.File]::WriteAllText(
        $AppFile,
        $NewAppSource,
        $Utf8NoBom
    )

    Write-Host "[수정 완료] $AppRelative" -ForegroundColor Green

}
catch {

    Write-Host ""
    Write-Host "[오류] 파일 저장에 실패했습니다." -ForegroundColor Red

    Write-Host "[진행] 기존 파일을 복원합니다." -ForegroundColor Yellow

    # 기존 app.ts 복원

    Copy-Item `
        -LiteralPath $BackupFile `
        -Destination $AppFile `
        -Force

    # 이번 작업에서 새로 생성한 파일 제거

    foreach ($File in @($RequestFile, $ReadinessFile)) {

        if (Test-Path -LiteralPath $File) {

            Remove-Item `
                -LiteralPath $File `
                -Force

        }

    }

    throw
}

# ============================================================
# 13. 생성 결과 확인
# ============================================================

$CreatedFiles = @(
    $RequestFile,
    $ReadinessFile
)

foreach ($File in $CreatedFiles) {

    if (-not (Test-Path -LiteralPath $File)) {

        throw "생성된 파일을 확인할 수 없습니다: $File"

    }

}

$SavedApp = [System.IO.File]::ReadAllText($AppFile)

if ($SavedApp -ne $NewAppSource) {

    throw "기존 app.ts 저장 결과가 예상과 다릅니다."

}

# ============================================================
# 14. 작업 완료
# ============================================================

Write-Host ""
Write-Host "============================================"
Write-Host " 11부 API 운영 안정성 강화 완료"
Write-Host "============================================"
Write-Host ""

Write-Host "[완료] Request ID 자동 생성" -ForegroundColor Green
Write-Host "[완료] HTTP 응답 추적 헤더" -ForegroundColor Green
Write-Host "[완료] 기존 로깅 시스템 연동" -ForegroundColor Green
Write-Host "[완료] PostgreSQL 준비 상태 확인" -ForegroundColor Green
Write-Host "[완료] Redis 준비 상태 확인" -ForegroundColor Green
Write-Host "[완료] HTTP 503 장애 응답" -ForegroundColor Green
Write-Host "[완료] 상태 확인 캐시" -ForegroundColor Green
Write-Host "[완료] 기존 파일 백업" -ForegroundColor Green

Write-Host ""
Write-Host "신규 파일: 2개"
Write-Host "수정 파일: 1개"
Write-Host "데이터베이스 변경: 없음"
Write-Host "패키지 변경: 없음"
Write-Host "인코딩: UTF-8 BOM 없음"
Write-Host ""

Write-Host "백업 위치: $BackupRoot"

Write-Host ""
Write-Host "신규 API: GET /health/ready"
Write-Host ""

