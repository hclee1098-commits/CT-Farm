﻿# filepath: create-starter-part2.ps1 - 풀스택 Starter Kit 인증 모듈 생성 스크립트

$ErrorActionPreference = "Stop"

# 기존 프로젝트 위치
$Root = Join-Path $PSScriptRoot "secure-starter"

# 보안 검토가 끝난 프로젝트에 예전 생성 코드를 덮어쓰지 않습니다.
if (Test-Path -LiteralPath (Join-Path $Root "SECURITY-REVISION.json")) {
    throw "보안 수정이 적용된 V5입니다. 이전 부별 생성 스크립트 적용을 차단합니다."
}


# 프로젝트 존재 여부 확인
if (-not (Test-Path $Root)) {
    throw "secure-starter 프로젝트가 없습니다. 1부를 먼저 실행하세요."
}

# Prisma 스키마가 존재하는지 확인
$SchemaPath = Join-Path $Root "apps/api/prisma/schema.prisma"

if (-not (Test-Path $SchemaPath)) {
    throw "Prisma 스키마가 없습니다. 1부가 정상적으로 생성되었는지 확인하세요."
}

# UTF-8 BOM 없는 인코딩
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)

# 파일 생성 함수
function Save-Source2 {
    param(
        [string]$RelativePath,
        [string]$Description,
        [string]$Content
    )

    $FullPath = Join-Path $Root $RelativePath
    $Directory = Split-Path $FullPath -Parent

    # 기존 파일 보호
    if (Test-Path $FullPath) {
        throw "이미 존재하는 파일입니다. 기존 파일을 보호하기 위해 중단합니다: $RelativePath"
    }

    if (-not (Test-Path $Directory)) {
        New-Item -ItemType Directory -Path $Directory -Force | Out-Null
    }

    $Extension = [System.IO.Path]::GetExtension($RelativePath)

    $Header = switch ($Extension) {
        ".ts" {
            "// filepath: $RelativePath - $Description`n"
        }
        ".tsx" {
            "// filepath: $RelativePath - $Description`n"
        }
        ".md" {
            "<!-- filepath: $RelativePath - $Description -->`n"
        }
        default {
            "# filepath: $RelativePath - $Description`n"
        }
    }

    $FinalContent = $Header + $Content

    [System.IO.File]::WriteAllText(
        $FullPath,
        $FinalContent,
        $Utf8NoBom
    )

    Write-Host "[생성 완료] $RelativePath" -ForegroundColor Green
}

Write-Host ""
Write-Host "========================================"
Write-Host " 2부 인증 시스템 생성 시작"
Write-Host "========================================"
Write-Host ""


# ============================================================
# 인증 요청 DTO
# ============================================================

Save-Source2 "apps/api/src/modules/auth/auth.dto.ts" "회원가입과 로그인 및 토큰 갱신 요청 데이터 검증" @'
import { z } from "zod";

// 이메일 형식을 검증하고 소문자로 통일합니다.
const emailSchema = z.string()
  .trim()
  .email("올바른 이메일 주소를 입력해 주세요.")
  .max(254, "이메일 주소가 너무 깁니다.")
  .transform((value) => value.toLowerCase());

// bcrypt는 비밀번호의 앞 72바이트까지만 사용합니다.
// 따라서 UTF-8 기준으로 72바이트를 초과하지 않도록 제한합니다.
const passwordSchema = z.string()
  .min(12, "비밀번호는 최소 12자 이상이어야 합니다.")
  .max(128, "비밀번호가 너무 깁니다.")
  .refine(
    (value) => Buffer.byteLength(value, "utf8") <= 72,
    "비밀번호는 UTF-8 기준 72바이트 이하여야 합니다."
  );

// 회원가입 요청 검증
export const registerSchema = z.object({
  email: emailSchema,

  password: passwordSchema,

  name: z.string()
    .trim()
    .min(2, "이름은 최소 2자 이상이어야 합니다.")
    .max(60, "이름은 최대 60자까지 입력할 수 있습니다.")
}).strict();

// 로그인 요청 검증
export const loginSchema = z.object({
  email: emailSchema,

  password: z.string()
    .min(1, "비밀번호를 입력해 주세요.")
    .max(128, "비밀번호가 너무 깁니다.")
}).strict();

// 모바일 Refresh Token 갱신 요청
export const refreshSchema = z.object({
  refreshToken: z.string()
    .min(40, "Refresh Token 형식이 올바르지 않습니다.")
    .max(256, "Refresh Token 형식이 올바르지 않습니다.")
}).strict();

// 모바일 로그아웃 요청
export const logoutSchema = refreshSchema;

// 타입 정의
export type RegisterInput = z.infer<typeof registerSchema>;

export type LoginInput = z.infer<typeof loginSchema>;

export type RefreshInput = z.infer<typeof refreshSchema>;

export type LogoutInput = z.infer<typeof logoutSchema>;
'@


# ============================================================
# 인증 Repository
# ============================================================

Save-Source2 "apps/api/src/modules/auth/auth.repository.ts" "Prisma를 이용한 회원과 인증 세션 데이터 접근" @'
import { prisma } from "../../infrastructure/prisma";
import { AppError } from "../../common/errors";

// 외부에 노출해도 되는 회원 필드
export const publicUserSelect = {
  id: true,
  email: true,
  name: true,
  createdAt: true,
  updatedAt: true
} as const;

// 데이터베이스 접근 로직을 한곳에서 관리합니다.
export const authRepository = {

  // 이메일로 회원 검색
  findByEmail(email: string) {
    return prisma.user.findUnique({
      where: {
        email
      }
    });
  },

  // 회원 ID로 회원 검색
  findById(id: string) {
    return prisma.user.findUnique({
      where: {
        id
      }
    });
  },

  // 외부 응답용 회원 정보 조회
  findPublicUser(id: string) {
    return prisma.user.findUnique({
      where: {
        id
      },
      select: publicUserSelect
    });
  },

  // 회원 생성
  createUser(data: {
    email: string;
    passwordHash: string;
    name: string;
  }) {
    return prisma.user.create({
      data,
      select: publicUserSelect
    });
  },

  // Refresh Token 세션 생성
  createSession(data: {
    userId: string;
    tokenHash: string;
    expiresAt: Date;
  }) {
    return prisma.refreshSession.create({
      data
    });
  },

  // Refresh Token 해시로 세션 조회
  findSession(tokenHash: string) {
    return prisma.refreshSession.findUnique({
      where: {
        tokenHash
      },
      include: {
        user: {
          select: {
            id: true,
            tokenVersion: true
          }
        }
      }
    });
  },

  // Refresh Token을 원자적으로 교체합니다.
  // 동시에 같은 토큰으로 갱신 요청이 들어와도
  // 하나의 요청만 성공하도록 처리합니다.
  async rotateSession(data: {
    oldSessionId: string;
    userId: string;
    newTokenHash: string;
    newExpiresAt: Date;
  }) {
    return prisma.$transaction(async (tx) => {

      const now = new Date();

      // 기존 세션을 사용 불가능한 상태로 변경
      const updated = await tx.refreshSession.updateMany({
        where: {
          id: data.oldSessionId,
          userId: data.userId,
          revokedAt: null,
          expiresAt: {
            gt: now
          }
        },
        data: {
          revokedAt: now
        }
      });

      // 이미 사용되었거나 만료된 토큰
      if (updated.count !== 1) {
        throw new AppError(
          401,
          "REFRESH_TOKEN_REUSED",
          "이미 사용되었거나 만료된 인증 토큰입니다."
        );
      }

      // 새로운 세션 생성
      return tx.refreshSession.create({
        data: {
          userId: data.userId,
          tokenHash: data.newTokenHash,
          expiresAt: data.newExpiresAt
        }
      });
    });
  },

  // 특정 Refresh Token 세션 종료
  async revokeSession(tokenHash: string) {
    const now = new Date();

    return prisma.refreshSession.updateMany({
      where: {
        tokenHash,
        revokedAt: null
      },
      data: {
        revokedAt: now
      }
    });
  },

  // 회원의 모든 세션 종료
  // Access Token도 무효화합니다.
  async revokeAllSessions(userId: string) {
    return prisma.$transaction(async (tx) => {

      const user = await tx.user.update({
        where: {
          id: userId
        },
        data: {
          tokenVersion: {
            increment: 1
          }
        }
      });

      await tx.refreshSession.updateMany({
        where: {
          userId,
          revokedAt: null
        },
        data: {
          revokedAt: new Date()
        }
      });

      return user;
    });
  }
};
'@


# ============================================================
# 인증 Service
# ============================================================

Save-Source2 "apps/api/src/modules/auth/auth.service.ts" "회원가입, 로그인, JWT 발급, 토큰 교체 및 로그아웃 처리" @'
import bcrypt from "bcrypt";
import crypto from "node:crypto";

import { AppError } from "../../common/errors";
import { createAccessToken } from "../../common/auth.middleware";

import { authRepository } from "./auth.repository";

import type {
  RegisterInput,
  LoginInput
} from "./auth.dto";

// 비밀번호 해싱 비용
const BCRYPT_ROUNDS = 12;

// Refresh Token 유효기간: 30일
export const REFRESH_TOKEN_MAX_AGE_MS =
  30 * 24 * 60 * 60 * 1000;

// 암호학적으로 안전한 난수 토큰 생성
function generateRefreshToken(): string {
  return crypto.randomBytes(48).toString("base64url");
}

// Refresh Token은 SHA-256 해시로 변환해서 저장합니다.
// 원본 토큰을 데이터베이스에 저장하지 않습니다.
function hashRefreshToken(token: string): string {
  return crypto
    .createHash("sha256")
    .update(token, "utf8")
    .digest("hex");
}

// 회원의 새로운 인증 세션 생성
async function createSession(
  userId: string,
  tokenVersion: number
) {
  const refreshToken = generateRefreshToken();

  const tokenHash = hashRefreshToken(refreshToken);

  const expiresAt = new Date(
    Date.now() + REFRESH_TOKEN_MAX_AGE_MS
  );

  await authRepository.createSession({
    userId,
    tokenHash,
    expiresAt
  });

  const accessToken = createAccessToken(
    userId,
    tokenVersion
  );

  return {
    accessToken,
    refreshToken,
    expiresAt
  };
}

// 인증 비즈니스 로직
export const authService = {

  // 회원가입
  async register(input: RegisterInput) {

    // 이메일 중복 검사
    const existing = await authRepository.findByEmail(
      input.email
    );

    if (existing) {
      throw new AppError(
        409,
        "EMAIL_ALREADY_EXISTS",
        "이미 가입된 이메일 주소입니다."
      );
    }

    // bcrypt 단방향 해싱
    const passwordHash = await bcrypt.hash(
      input.password,
      BCRYPT_ROUNDS
    );

    // 회원 생성
    const user = await authRepository.createUser({
      email: input.email,
      passwordHash,
      name: input.name
    });

    // 신규 회원의 최초 인증 세션 생성
    const tokens = await createSession(
      user.id,
      0
    );

    return {
      user,
      ...tokens
    };
  },

  // 로그인
  async login(input: LoginInput) {

    const user = await authRepository.findByEmail(
      input.email
    );

    // 존재하지 않는 계정과 비밀번호 오류를
    // 동일한 메시지로 처리합니다.
    if (!user) {
      throw new AppError(
        401,
        "INVALID_CREDENTIALS",
        "이메일 또는 비밀번호가 올바르지 않습니다."
      );
    }

    const passwordMatches = await bcrypt.compare(
      input.password,
      user.passwordHash
    );

    if (!passwordMatches) {
      throw new AppError(
        401,
        "INVALID_CREDENTIALS",
        "이메일 또는 비밀번호가 올바르지 않습니다."
      );
    }

    const tokens = await createSession(
      user.id,
      user.tokenVersion
    );

    const publicUser = await authRepository.findPublicUser(
      user.id
    );

    if (!publicUser) {
      throw new AppError(
        401,
        "USER_NOT_FOUND",
        "회원 정보를 찾을 수 없습니다."
      );
    }

    return {
      user: publicUser,
      ...tokens
    };
  },

  // Refresh Token 갱신
  async refresh(refreshToken: string) {

    const tokenHash = hashRefreshToken(refreshToken);

    // DB에 저장된 세션 검색
    const session = await authRepository.findSession(
      tokenHash
    );

    if (
      !session ||
      session.revokedAt ||
      session.expiresAt <= new Date()
    ) {
      throw new AppError(
        401,
        "INVALID_REFRESH_TOKEN",
        "로그인 세션이 만료되었거나 유효하지 않습니다."
      );
    }

    // 새로운 Refresh Token 발급
    const newRefreshToken = generateRefreshToken();

    const newTokenHash = hashRefreshToken(
      newRefreshToken
    );

    const newExpiresAt = new Date(
      Date.now() + REFRESH_TOKEN_MAX_AGE_MS
    );

    // 기존 토큰을 폐기하고 새 토큰으로 교체
    await authRepository.rotateSession({
      oldSessionId: session.id,
      userId: session.userId,
      newTokenHash,
      newExpiresAt
    });

    // 새로운 Access Token 발급
    const accessToken = createAccessToken(
      session.userId,
      session.user.tokenVersion
    );

    return {
      accessToken,
      refreshToken: newRefreshToken,
      expiresAt: newExpiresAt
    };
  },

  // 현재 기기 로그아웃
  async logout(refreshToken: string) {

    const tokenHash = hashRefreshToken(refreshToken);

    await authRepository.revokeSession(
      tokenHash
    );

    return {
      loggedOut: true
    };
  },

  // 전체 기기 로그아웃
  async logoutAll(userId: string) {

    await authRepository.revokeAllSessions(
      userId
    );

    return {
      loggedOut: true
    };
  },

  // 내 정보 조회
  async getMe(userId: string) {

    const user = await authRepository.findPublicUser(
      userId
    );

    if (!user) {
      throw new AppError(
        404,
        "USER_NOT_FOUND",
        "회원 정보를 찾을 수 없습니다."
      );
    }

    return user;
  }
};
'@


# ============================================================
# 인증 Controller
# ============================================================

Save-Source2 "apps/api/src/modules/auth/auth.controller.ts" "웹과 모바일 앱의 인증 API 라우팅 및 응답 처리" @'
import {
  Router,
  Request,
  Response,
  NextFunction
} from "express";

import { env } from "../../config/env";

import { AppError } from "../../common/errors";
import { success } from "../../common/response";

import {
  validate,
  asyncHandler
} from "../../common/validate";

import {
  requireAuth
} from "../../common/auth.middleware";

import {
  authLimiter,
  refreshLimiter
} from "../../infrastructure/rate-limit";

import {
  registerSchema,
  loginSchema,
  refreshSchema,
  logoutSchema
} from "./auth.dto";

import type {
  RegisterInput,
  LoginInput,
  RefreshInput,
  LogoutInput
} from "./auth.dto";

import {
  authService,
  REFRESH_TOKEN_MAX_AGE_MS
} from "./auth.service";

// 인증 라우터
export const authRouter = Router();

// 운영 환경에서는 __Host- 접두사를 사용합니다.
// 해당 접두사는 Secure 및 Path=/ 조건을 요구합니다.
const REFRESH_COOKIE_NAME = env.IS_PRODUCTION
  ? "__Host-refresh_token"
  : "refresh_token";

// 웹 브라우저용 Refresh Token 쿠키 설정
function setRefreshCookie(
  res: Response,
  refreshToken: string
): void {
  res.cookie(
    REFRESH_COOKIE_NAME,
    refreshToken,
    {
      httpOnly: true,
      secure: env.IS_PRODUCTION,
      sameSite: "strict",
      path: "/",
      maxAge: REFRESH_TOKEN_MAX_AGE_MS
    }
  );
}

// 웹 브라우저용 Refresh Token 쿠키 삭제
function clearRefreshCookie(res: Response): void {
  res.clearCookie(
    REFRESH_COOKIE_NAME,
    {
      httpOnly: true,
      secure: env.IS_PRODUCTION,
      sameSite: "strict",
      path: "/"
    }
  );
}

// 웹 요청의 Origin을 검증합니다.
// CORS 설정만으로는 CSRF 공격을 완전히 막을 수 없으므로
// 쿠키를 사용하는 인증 API에 추가 검증을 적용합니다.
function requireWebOrigin(
  req: Request,
  _res: Response,
  next: NextFunction
): void {
  const origin = req.headers.origin;

  if (
    !origin ||
    !env.CORS_ORIGIN_LIST.includes(origin)
  ) {
    return next(
      new AppError(
        403,
        "INVALID_ORIGIN",
        "허용되지 않은 웹 출처에서 요청했습니다."
      )
    );
  }

  next();
}

// 웹 쿠키에서 Refresh Token 추출
function getWebRefreshToken(req: Request): string {
  const token = req.cookies?.[REFRESH_COOKIE_NAME];

  if (
    typeof token !== "string" ||
    token.length < 40 ||
    token.length > 256
  ) {
    throw new AppError(
      401,
      "REFRESH_TOKEN_REQUIRED",
      "로그인 세션이 없습니다."
    );
  }

  return token;
}


// ============================================================
// 웹 회원가입
// ============================================================

authRouter.post(
  "/web/register",
  requireWebOrigin,
  authLimiter,
  validate("body", registerSchema),
  asyncHandler(async (req, res) => {

    const input = req.body as RegisterInput;

    const result = await authService.register(input);

    // 웹은 Refresh Token을 JSON으로 반환하지 않습니다.
    setRefreshCookie(
      res,
      result.refreshToken
    );

    success(
      res,
      {
        user: result.user,
        accessToken: result.accessToken
      },
      "회원가입이 완료되었습니다.",
      201
    );
  })
);


// ============================================================
// 웹 로그인
// ============================================================

authRouter.post(
  "/web/login",
  requireWebOrigin,
  authLimiter,
  validate("body", loginSchema),
  asyncHandler(async (req, res) => {

    const input = req.body as LoginInput;

    const result = await authService.login(input);

    setRefreshCookie(
      res,
      result.refreshToken
    );

    success(
      res,
      {
        user: result.user,
        accessToken: result.accessToken
      },
      "로그인되었습니다."
    );
  })
);


// ============================================================
// 웹 Refresh Token 갱신
// ============================================================

authRouter.post(
  "/web/refresh",
  requireWebOrigin,
  refreshLimiter,
  asyncHandler(async (req, res) => {

    const refreshToken = getWebRefreshToken(req);

    const result = await authService.refresh(
      refreshToken
    );

    // 새로운 Refresh Token으로 쿠키 교체
    setRefreshCookie(
      res,
      result.refreshToken
    );

    success(
      res,
      {
        accessToken: result.accessToken
      },
      "인증 토큰이 갱신되었습니다."
    );
  })
);


// ============================================================
// 웹 로그아웃
// ============================================================

authRouter.post(
  "/web/logout",
  requireWebOrigin,
  asyncHandler(async (req, res) => {

    const refreshToken =
      req.cookies?.[REFRESH_COOKIE_NAME];

    if (typeof refreshToken === "string") {
      await authService.logout(refreshToken);
    }

    clearRefreshCookie(res);

    success(
      res,
      {
        loggedOut: true
      },
      "로그아웃되었습니다."
    );
  })
);


// ============================================================
// 모바일 앱 회원가입
// ============================================================

authRouter.post(
  "/mobile/register",
  authLimiter,
  validate("body", registerSchema),
  asyncHandler(async (req, res) => {

    const input = req.body as RegisterInput;

    const result = await authService.register(input);

    // 모바일 앱은 Refresh Token을 안전한 저장소에
    // 보관할 수 있도록 응답 본문으로 전달합니다.
    success(
      res,
      {
        user: result.user,
        accessToken: result.accessToken,
        refreshToken: result.refreshToken
      },
      "회원가입이 완료되었습니다.",
      201
    );
  })
);


// ============================================================
// 모바일 앱 로그인
// ============================================================

authRouter.post(
  "/mobile/login",
  authLimiter,
  validate("body", loginSchema),
  asyncHandler(async (req, res) => {

    const input = req.body as LoginInput;

    const result = await authService.login(input);

    success(
      res,
      {
        user: result.user,
        accessToken: result.accessToken,
        refreshToken: result.refreshToken
      },
      "로그인되었습니다."
    );
  })
);


// ============================================================
// 모바일 앱 Refresh Token 갱신
// ============================================================

authRouter.post(
  "/mobile/refresh",
  refreshLimiter,
  validate("body", refreshSchema),
  asyncHandler(async (req, res) => {

    const input = req.body as RefreshInput;

    const result = await authService.refresh(
      input.refreshToken
    );

    success(
      res,
      {
        accessToken: result.accessToken,
        refreshToken: result.refreshToken
      },
      "인증 토큰이 갱신되었습니다."
    );
  })
);


// ============================================================
// 모바일 앱 로그아웃
// ============================================================

authRouter.post(
  "/mobile/logout",
  validate("body", logoutSchema),
  asyncHandler(async (req, res) => {

    const input = req.body as LogoutInput;

    const result = await authService.logout(
      input.refreshToken
    );

    success(
      res,
      result,
      "로그아웃되었습니다."
    );
  })
);


// ============================================================
// 내 정보 조회
// ============================================================

authRouter.get(
  "/me",
  requireAuth,
  asyncHandler(async (req, res) => {

    const userId = req.userId!;

    const user = await authService.getMe(
      userId
    );

    success(
      res,
      user,
      "회원 정보를 조회했습니다."
    );
  })
);


// ============================================================
// 전체 기기 로그아웃
// ============================================================

authRouter.post(
  "/logout-all",
  requireAuth,
  asyncHandler(async (req, res) => {

    const userId = req.userId!;

    const result = await authService.logoutAll(
      userId
    );

    // 웹 브라우저에 저장된 쿠키도 삭제합니다.
    clearRefreshCookie(res);

    success(
      res,
      result,
      "모든 기기에서 로그아웃되었습니다."
    );
  })
);
'@


# ============================================================
# 인증 DTO 테스트
# ============================================================

Save-Source2 "apps/api/src/modules/auth/auth.dto.test.ts" "회원가입과 로그인 요청값 검증 자동 테스트" @'
import {
  describe,
  expect,
  it
} from "vitest";

import {
  registerSchema,
  loginSchema,
  refreshSchema
} from "./auth.dto";

describe("회원가입 입력값 검증", () => {

  it("올바른 회원가입 요청을 허용합니다.", () => {

    const result = registerSchema.safeParse({
      email: "TEST@EXAMPLE.COM",
      password: "StrongPassword123!",
      name: "테스트회원"
    });

    expect(result.success).toBe(true);

    if (result.success) {
      expect(result.data.email).toBe(
        "test@example.com"
      );
    }
  });

  it("잘못된 이메일을 거부합니다.", () => {

    const result = registerSchema.safeParse({
      email: "invalid-email",
      password: "StrongPassword123!",
      name: "테스트회원"
    });

    expect(result.success).toBe(false);
  });

  it("짧은 비밀번호를 거부합니다.", () => {

    const result = registerSchema.safeParse({
      email: "test@example.com",
      password: "1234",
      name: "테스트회원"
    });

    expect(result.success).toBe(false);
  });

  it("bcrypt 허용 바이트를 초과한 비밀번호를 거부합니다.", () => {

    const result = registerSchema.safeParse({
      email: "test@example.com",
      password: "가".repeat(30),
      name: "테스트회원"
    });

    expect(result.success).toBe(false);
  });

  it("허용되지 않은 추가 필드를 거부합니다.", () => {

    const result = registerSchema.safeParse({
      email: "test@example.com",
      password: "StrongPassword123!",
      name: "테스트회원",
      isAdmin: true
    });

    expect(result.success).toBe(false);
  });
});

describe("로그인 입력값 검증", () => {

  it("정상적인 로그인 요청을 허용합니다.", () => {

    const result = loginSchema.safeParse({
      email: "test@example.com",
      password: "StrongPassword123!"
    });

    expect(result.success).toBe(true);
  });

  it("비밀번호가 없는 요청을 거부합니다.", () => {

    const result = loginSchema.safeParse({
      email: "test@example.com",
      password: ""
    });

    expect(result.success).toBe(false);
  });
});

describe("Refresh Token 입력값 검증", () => {

  it("너무 짧은 Refresh Token을 거부합니다.", () => {

    const result = refreshSchema.safeParse({
      refreshToken: "short"
    });

    expect(result.success).toBe(false);
  });
});
'@


# ============================================================
# 인증 API 사용 설명서
# ============================================================

Save-Source2 "apps/api/src/modules/auth/README.md" "웹과 모바일 앱 인증 API 사용 방법 안내" @'
# 인증 API 사용 설명서

## 개요

웹 브라우저와 모바일 앱은 동일한 회원 데이터베이스를 사용합니다.

Refresh Token 전달 방식은 서로 다릅니다.

웹 브라우저:
- Access Token: 메모리에 저장
- Refresh Token: HttpOnly Cookie

모바일 앱:
- Access Token: 메모리에 저장
- Refresh Token: 운영체제 보안 저장소

## 웹 회원가입

POST /api/v1/auth/web/register

요청 JSON 예시:

{
  "email": "test@example.com",
  "password": "StrongPassword123!",
  "name": "테스트회원"
}

성공하면 회원 정보와 Access Token을 반환합니다.

Refresh Token은 HttpOnly Cookie로 전달됩니다.

## 웹 로그인

POST /api/v1/auth/web/login

요청 JSON 예시:

{
  "email": "test@example.com",
  "password": "StrongPassword123!"
}

웹에서는 credentials: "include" 옵션을 사용합니다.

## 웹 토큰 갱신

POST /api/v1/auth/web/refresh

Refresh Token은 쿠키에서 자동으로 읽습니다.

성공하면 새로운 Access Token을 반환합니다.

## 웹 로그아웃

POST /api/v1/auth/web/logout

현재 브라우저의 Refresh Token 세션을 종료합니다.

## 모바일 앱 회원가입

POST /api/v1/auth/mobile/register

요청 JSON 예시:

{
  "email": "test@example.com",
  "password": "StrongPassword123!",
  "name": "테스트회원"
}

## 모바일 앱 로그인

POST /api/v1/auth/mobile/login

요청 JSON 예시:

{
  "email": "test@example.com",
  "password": "StrongPassword123!"
}

성공하면 Access Token과 Refresh Token을 반환합니다.

모바일 앱은 Refresh Token을 안전한 저장소에 보관해야 합니다.

## 모바일 앱 토큰 갱신

POST /api/v1/auth/mobile/refresh

요청 JSON 예시:

{
  "refreshToken": "기존_Refresh_Token"
}

성공하면 새로운 Access Token과 Refresh Token을 반환합니다.

기존 Refresh Token은 사용할 수 없게 됩니다.

## 모바일 앱 로그아웃

POST /api/v1/auth/mobile/logout

요청 JSON 예시:

{
  "refreshToken": "현재_Refresh_Token"
}

## 내 정보 조회

GET /api/v1/auth/me

요청 헤더:

Authorization: Bearer ACCESS_TOKEN

## 전체 기기 로그아웃

POST /api/v1/auth/logout-all

요청 헤더:

Authorization: Bearer ACCESS_TOKEN

모든 Refresh Token 세션을 종료합니다.

기존 Access Token도 무효화됩니다.

## 보안 주의사항

1. 운영 환경에서는 반드시 HTTPS를 사용합니다.
2. JWT 비밀키를 소스코드에 저장하지 않습니다.
3. Refresh Token을 로그에 기록하지 않습니다.
4. 모바일 앱은 운영체제 보안 저장소를 사용합니다.
5. Refresh Token은 갱신할 때마다 교체합니다.
6. 인증 요청에는 Rate Limiting을 적용합니다.
7. 쿠키 기반 요청에는 CSRF 방어가 필요합니다.
8. 실제 운영 전 보안 테스트를 수행해야 합니다.
'@


# ============================================================
# 완료 안내
# ============================================================

Write-Host ""
Write-Host "========================================"
Write-Host " 2부 인증 시스템 생성 완료"
Write-Host "========================================"
Write-Host ""

Write-Host "생성된 파일:" -ForegroundColor Cyan
Write-Host "1. auth.dto.ts"
Write-Host "2. auth.repository.ts"
Write-Host "3. auth.service.ts"
Write-Host "4. auth.controller.ts"
Write-Host "5. auth.dto.test.ts"
Write-Host "6. README.md"

Write-Host ""
Write-Host "기존 프로젝트 파일은 변경하지 않았습니다."
Write-Host ""

