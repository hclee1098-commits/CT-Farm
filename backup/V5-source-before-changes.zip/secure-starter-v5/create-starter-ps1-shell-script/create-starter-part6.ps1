﻿# filepath: create-starter-part6.ps1 - Next.js 프론트엔드 전체 소스코드 생성 스크립트

$ErrorActionPreference = "Stop"

# ============================================================
# 6부 기본 설정
# ============================================================

$Root = Join-Path $PSScriptRoot "secure-starter"

# 보안 검토가 끝난 프로젝트에 예전 생성 코드를 덮어쓰지 않습니다.
if (Test-Path -LiteralPath (Join-Path $Root "SECURITY-REVISION.json")) {
    throw "보안 수정이 적용된 V5입니다. 이전 부별 생성 스크립트 적용을 차단합니다."
}


$WebRoot = Join-Path $Root "apps\web"

$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)

Write-Host ""
Write-Host "============================================"
Write-Host " 6부 Next.js 프론트엔드 생성 시작"
Write-Host "============================================"
Write-Host ""

# ============================================================
# 기존 프로젝트 확인
# ============================================================

if (-not (Test-Path $Root)) {
    throw "secure-starter 프로젝트가 없습니다."
}

if (-not (Test-Path $WebRoot)) {
    throw "apps/web 프로젝트가 없습니다."
}

$PackagePath = Join-Path $WebRoot "package.json"

if (-not (Test-Path $PackagePath)) {
    throw "웹 프로젝트의 package.json이 없습니다."
}

$Package = Get-Content $PackagePath -Raw -Encoding UTF8 |
    ConvertFrom-Json

if (-not $Package.dependencies.next) {
    throw "Next.js 의존성이 없습니다. 기존 웹 프로젝트 설정을 확인하세요."
}

# ============================================================
# App Router 위치 확인
# ============================================================

$SrcApp = Join-Path $WebRoot "src\app"

$DefaultApp = Join-Path $WebRoot "app"

if (Test-Path $SrcApp) {

    $AppRoot = $SrcApp

    $AppRelative = "apps/web/src/app"

}
elseif (Test-Path $DefaultApp) {

    $AppRoot = $DefaultApp

    $AppRelative = "apps/web/app"

}
else {

    $AppRoot = $SrcApp

    $AppRelative = "apps/web/src/app"

    New-Item `
        -ItemType Directory `
        -Path $AppRoot `
        -Force | Out-Null
}

Write-Host "[확인] App Router: $AppRelative" -ForegroundColor Cyan

# ============================================================
# 기존 파일 보호
# ============================================================

$StarterRoot = Join-Path $AppRoot "starter"

if (Test-Path $StarterRoot) {
    throw "starter 경로가 이미 존재합니다. 기존 파일을 보호하기 위해 중단합니다."
}

$EnvExamplePath = Join-Path $WebRoot ".env.local.example"

if (Test-Path $EnvExamplePath) {
    throw ".env.local.example 파일이 이미 존재합니다. 덮어쓰지 않습니다."
}

# ============================================================
# 파일 생성 공통 함수
# ============================================================

function Save-WebFile {

    param(
        [string]$RelativePath,
        [string]$Description,
        [string]$Content
    )

    $FullPath = Join-Path $Root $RelativePath

    $Directory = Split-Path $FullPath -Parent

    if (Test-Path $FullPath) {
        throw "이미 존재하는 파일입니다: $RelativePath"
    }

    if (-not (Test-Path $Directory)) {

        New-Item `
            -ItemType Directory `
            -Path $Directory `
            -Force | Out-Null
    }

    $Extension = [System.IO.Path]::GetExtension($RelativePath)

    $Header = switch ($Extension) {

        ".ts" {
            "// filepath: $RelativePath - $Description`n"
        }

        ".tsx" {
            "// filepath: $RelativePath - $Description`n"
        }

        ".css" {
            "/* filepath: $RelativePath - $Description */`n"
        }

        ".md" {
            "<!-- filepath: $RelativePath - $Description -->`n"
        }

        default {
            "# filepath: $RelativePath - $Description`n"
        }
    }

    $FinalContent = $Header + $Content

    [System.IO.File]::WriteAllText(
        $FullPath,
        $FinalContent,
        $Utf8NoBom
    )

    Write-Host "[생성 완료] $RelativePath" -ForegroundColor Green
}

# ============================================================
# Root Layout이 없는 경우에만 생성
# ============================================================

$RootLayoutPath = Join-Path $AppRoot "layout.tsx"

if (-not (Test-Path $RootLayoutPath)) {

    Save-WebFile "$AppRelative/layout.tsx" "Next.js 최상위 HTML 레이아웃" @'
import type { ReactNode } from "react";

export default function RootLayout({
  children
}: {
  children: ReactNode;
}) {
  return (
    <html lang="ko">
      <body>{children}</body>
    </html>
  );
}
'@
}

# ============================================================
# 프론트엔드 환경 변수
# ============================================================

Save-WebFile "apps/web/.env.local.example" "웹 프론트엔드 API 서버 주소 설정 예시" @'
# Express 백엔드 API 주소
NEXT_PUBLIC_API_URL=http://localhost:4000/api/v1
'@

$EnvLocalPath = Join-Path $WebRoot ".env.local"

if (-not (Test-Path $EnvLocalPath)) {

    [System.IO.File]::WriteAllText(
        $EnvLocalPath,
        "# filepath: apps/web/.env.local - 로컬 웹 API 연결 설정`nNEXT_PUBLIC_API_URL=http://localhost:4000/api/v1`n",
        $Utf8NoBom
    )

    Write-Host "[생성 완료] apps/web/.env.local" -ForegroundColor Green
}
else {

    Write-Host "[보존] 기존 .env.local 파일" -ForegroundColor Yellow
}

# ============================================================
# 공통 API 클라이언트
# ============================================================

Save-WebFile "$AppRelative/starter/_lib/api.ts" "API 주소 및 공통 응답 처리" @'
export const API_BASE_URL = (
  process.env.NEXT_PUBLIC_API_URL ??
  "http://localhost:4000/api/v1"
).replace(/\/+$/, "");

// API 성공 응답
export interface ApiSuccess<T> {
  success: true;
  data: T;
  message: string;
}

// API 실패 응답
export interface ApiFailure {
  success: false;
  errorCode: string;
  message: string;
}

// 회원 정보
export interface PublicUser {
  id: string;
  email: string;
  name: string;
  createdAt: string;
  updatedAt: string;
}

// 공통 페이지 정보
export interface Pagination {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
  hasNext: boolean;
  hasPrevious: boolean;
}

// 공통 목록 응답
export interface PaginatedResult<T> {
  items: T[];
  pagination: Pagination;
}

// API 응답을 공통 규격으로 해석합니다.
export async function readApiResponse<T>(
  response: Response
): Promise<T> {

  const result = await response.json().catch(
    () => null
  ) as ApiSuccess<T> | ApiFailure | null;

  if (
    !response.ok ||
    !result ||
    !result.success
  ) {

    const message =
      result?.message ??
      "서버 요청을 처리하지 못했습니다.";

    throw new Error(message);
  }

  return result.data;
}

// 알 수 없는 오류를 사용자 메시지로 변환합니다.
export function getErrorMessage(
  error: unknown
): string {

  if (error instanceof Error) {
    return error.message;
  }

  return "알 수 없는 오류가 발생했습니다.";
}
'@

# ============================================================
# JWT 인증 상태 관리
# ============================================================

Save-WebFile "$AppRelative/starter/_lib/auth.tsx" "JWT 인증과 Refresh Token 자동 갱신 및 로그인 상태 관리" @'
"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState
} from "react";

import type {
  ReactNode
} from "react";

import {
  API_BASE_URL,
  readApiResponse
} from "./api";

import type {
  PublicUser
} from "./api";

// 로그인 응답
interface LoginResult {
  user: PublicUser;
  accessToken: string;
}

// 토큰 갱신 응답
interface RefreshResult {
  accessToken: string;
}

// 인증 Context 규격
interface AuthContextValue {

  user: PublicUser | null;

  loading: boolean;

  login(
    email: string,
    password: string
  ): Promise<void>;

  register(
    email: string,
    password: string,
    name: string
  ): Promise<void>;

  logout(): Promise<void>;

  logoutAll(): Promise<void>;

  request<T>(
    path: string,
    options?: RequestInit
  ): Promise<T>;

  authorizedFetch(
    path: string,
    options?: RequestInit
  ): Promise<Response>;
}

const AuthContext =
  createContext<AuthContextValue | null>(null);

// 인증 정보를 모든 페이지에 제공합니다.
export function AuthProvider({
  children
}: {
  children: ReactNode;
}) {

  const [user, setUser] =
    useState<PublicUser | null>(null);

  const [loading, setLoading] =
    useState(true);

  // Access Token은 브라우저 메모리에만 보관합니다.
  // localStorage와 sessionStorage에 저장하지 않습니다.
  const accessTokenRef =
    useRef<string | null>(null);

  // 동시에 여러 API가 토큰 갱신을 요청할 때
  // 중복 갱신을 방지합니다.
  const refreshPromiseRef =
    useRef<Promise<string | null> | null>(null);

  const clearAuth = useCallback(() => {

    accessTokenRef.current = null;

    setUser(null);

  }, []);

  // Refresh Token은 HttpOnly 쿠키에 저장되어 있으므로
  // JavaScript에서 직접 읽지 않습니다.
  const renewToken = useCallback(async () => {

    if (!refreshPromiseRef.current) {

      refreshPromiseRef.current = (async () => {

        try {

          const response = await fetch(
            `${API_BASE_URL}/auth/web/refresh`,
            {
              method: "POST",
              credentials: "include",
              cache: "no-store"
            }
          );

          if (!response.ok) {
            clearAuth();
            return null;
          }

          const result =
            await readApiResponse<RefreshResult>(
              response
            );

          accessTokenRef.current =
            result.accessToken;

          return result.accessToken;

        }
        catch {

          clearAuth();

          return null;
        }

      })();
    }

    try {

      return await refreshPromiseRef.current;

    }
    finally {

      refreshPromiseRef.current = null;
    }

  }, [clearAuth]);

  // JWT 인증이 필요한 요청을 처리합니다.
  const authorizedFetch = useCallback(
    async (
      path: string,
      options: RequestInit = {}
    ): Promise<Response> => {

      const send = async (
        token: string | null
      ) => {

        const headers = new Headers(
          options.headers
        );

        if (token) {
          headers.set(
            "Authorization",
            `Bearer ${token}`
          );
        }

        return fetch(
          `${API_BASE_URL}${path}`,
          {
            ...options,
            headers,
            credentials: "include",
            cache: "no-store"
          }
        );
      };

      let response = await send(
        accessTokenRef.current
      );

      // Access Token이 만료되었다면
      // Refresh Token으로 한 번 갱신합니다.
      if (response.status === 401) {

        const newToken = await renewToken();

        if (!newToken) {
          throw new Error(
            "로그인이 필요합니다."
          );
        }

        response = await send(newToken);
      }

      return response;

    },
    [renewToken]
  );

  // JSON API 공통 요청 함수
  const request = useCallback(
    async <T,>(
      path: string,
      options: RequestInit = {}
    ): Promise<T> => {

      const response = await authorizedFetch(
        path,
        options
      );

      return readApiResponse<T>(response);

    },
    [authorizedFetch]
  );

  // 로그인 처리
  const login = useCallback(
    async (
      email: string,
      password: string
    ) => {

      const response = await fetch(
        `${API_BASE_URL}/auth/web/login`,
        {
          method: "POST",

          credentials: "include",

          headers: {
            "Content-Type":
              "application/json; charset=utf-8"
          },

          body: JSON.stringify({
            email,
            password
          })
        }
      );

      const result =
        await readApiResponse<LoginResult>(
          response
        );

      accessTokenRef.current =
        result.accessToken;

      setUser(result.user);

    },
    []
  );

  // 회원가입 처리
  const register = useCallback(
    async (
      email: string,
      password: string,
      name: string
    ) => {

      const response = await fetch(
        `${API_BASE_URL}/auth/web/register`,
        {
          method: "POST",

          credentials: "include",

          headers: {
            "Content-Type":
              "application/json; charset=utf-8"
          },

          body: JSON.stringify({
            email,
            password,
            name
          })
        }
      );

      const result =
        await readApiResponse<LoginResult>(
          response
        );

      accessTokenRef.current =
        result.accessToken;

      setUser(result.user);

    },
    []
  );

  // 현재 기기 로그아웃
  const logout = useCallback(async () => {

    try {

      const response = await fetch(
        `${API_BASE_URL}/auth/web/logout`,
        {
          method: "POST",
          credentials: "include"
        }
      );

      await readApiResponse<{
        loggedOut: boolean;
      }>(response);

    }
    finally {

      clearAuth();
    }

  }, [clearAuth]);

  // 전체 기기 로그아웃
  const logoutAll = useCallback(async () => {

    try {

      await request<{
        loggedOut: boolean;
      }>(
        "/auth/logout-all",
        {
          method: "POST"
        }
      );

    }
    finally {

      clearAuth();
    }

  }, [request, clearAuth]);

  // 브라우저 새로고침 시 로그인 상태 복구
  useEffect(() => {

    let cancelled = false;

    async function initialize() {

      try {

        const token = await renewToken();

        if (token) {

          const response = await fetch(
            `${API_BASE_URL}/auth/me`,
            {
              headers: {
                Authorization:
                  `Bearer ${token}`
              },

              credentials: "include",

              cache: "no-store"
            }
          );

          const currentUser =
            await readApiResponse<PublicUser>(
              response
            );

          if (!cancelled) {
            setUser(currentUser);
          }
        }

      }
      catch {

        if (!cancelled) {
          clearAuth();
        }

      }
      finally {

        if (!cancelled) {
          setLoading(false);
        }
      }
    }

    void initialize();

    return () => {
      cancelled = true;
    };

  }, [renewToken, clearAuth]);

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        login,
        register,
        logout,
        logoutAll,
        request,
        authorizedFetch
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

// 인증 기능을 사용하는 공통 Hook
export function useAuth(): AuthContextValue {

  const context = useContext(AuthContext);

  if (!context) {
    throw new Error(
      "인증 Provider가 설정되지 않았습니다."
    );
  }

  return context;
}
'@

# ============================================================
# 공통 레이아웃
# ============================================================

Save-WebFile "$AppRelative/starter/layout.tsx" "Starter Kit 인증 Provider와 공통 화면 레이아웃" @'
import type {
  ReactNode
} from "react";

import {
  AuthProvider
} from "./_lib/auth";

import {
  StarterShell
} from "./_components/Shell";

import "./starter.css";

export default function StarterLayout({
  children
}: {
  children: ReactNode;
}) {

  return (
    <AuthProvider>
      <StarterShell>
        {children}
      </StarterShell>
    </AuthProvider>
  );
}
'@

# ============================================================
# 공통 네비게이션
# ============================================================

Save-WebFile "$AppRelative/starter/_components/Shell.tsx" "상단 메뉴와 로그인 상태 및 공통 화면 구성" @'
"use client";

import Link from "next/link";

import {
  useRouter
} from "next/navigation";

import type {
  ReactNode
} from "react";

import {
  useState
} from "react";

import {
  useAuth
} from "../_lib/auth";

export function StarterShell({
  children
}: {
  children: ReactNode;
}) {

  const router = useRouter();

  const {
    user,
    loading,
    logout
  } = useAuth();

  const [error, setError] = useState("");

  async function handleLogout() {

    setError("");

    try {

      await logout();

      router.push("/starter/login");

    }
    catch {

      setError(
        "로그아웃 요청을 완료하지 못했습니다. 서버 연결을 확인해 주세요."
      );

    }
  }

  return (
    <div className="starter-root">

      <header className="starter-header">

        <div className="starter-header-inner">

          <Link
            href="/starter"
            className="starter-logo"
          >
            STARTER KIT
          </Link>

          <nav className="starter-nav">

            <Link href="/starter">
              홈
            </Link>

            {user && (
              <>
                <Link href="/starter/notes">
                  게시글
                </Link>

                <Link href="/starter/files">
                  파일 관리
                </Link>
              </>
            )}

          </nav>

          <div className="starter-account">

            {!loading && !user && (
              <>
                <Link
                  href="/starter/login"
                  className="starter-button secondary"
                >
                  로그인
                </Link>

                <Link
                  href="/starter/register"
                  className="starter-button"
                >
                  회원가입
                </Link>
              </>
            )}

            {!loading && user && (
              <>
                <span className="starter-user">
                  {user.name}님
                </span>

                <button
                  type="button"
                  className="starter-button secondary"
                  onClick={handleLogout}
                >
                  로그아웃
                </button>
              </>
            )}

          </div>

        </div>

      </header>

      {error && (
        <div className="starter-global-error">
          {error}
        </div>
      )}

      <main className="starter-main">
        {children}
      </main>

      <footer className="starter-footer">
        Secure Fullstack Starter Kit
      </footer>

    </div>
  );
}
'@

# ============================================================
# 메인 대시보드
# ============================================================

Save-WebFile "$AppRelative/starter/page.tsx" "Starter Kit 메인 대시보드" @'
"use client";

import Link from "next/link";

import {
  useAuth
} from "./_lib/auth";

export default function StarterHome() {

  const {
    user,
    loading
  } = useAuth();

  return (
    <div className="starter-container">

      <section className="starter-hero">

        <div className="starter-badge">
          FULLSTACK STARTER KIT
        </div>

        <h1>
          웹과 모바일 앱을 위한
          <br />
          공통 개발 환경
        </h1>

        <p>
          Next.js, Express, PostgreSQL,
          Prisma, Redis를 연결한
          풀스택 공통 프로젝트입니다.
        </p>

        {!loading && !user && (
          <div className="starter-actions">

            <Link
              href="/starter/register"
              className="starter-button large"
            >
              시작하기
            </Link>

            <Link
              href="/starter/login"
              className="starter-button secondary large"
            >
              로그인
            </Link>

          </div>
        )}

        {!loading && user && (
          <div className="starter-welcome">

            <h2>
              {user.name}님, 환영합니다.
            </h2>

            <p>
              공통 기능을 활용해
              새로운 서비스를 개발할 수 있습니다.
            </p>

          </div>
        )}

      </section>

      <section className="starter-grid">

        <Link
          href="/starter/notes"
          className="starter-card"
        >

          <div className="starter-card-icon">
            📝
          </div>

          <h2>게시글 관리</h2>

          <p>
            게시글 등록, 조회, 수정, 삭제와
            검색 및 페이징을 제공합니다.
          </p>

          <span>기능 열기 →</span>

        </Link>

        <Link
          href="/starter/files"
          className="starter-card"
        >

          <div className="starter-card-icon">
            📁
          </div>

          <h2>파일 관리</h2>

          <p>
            파일 업로드, 다운로드,
            목록 조회 및 삭제 기능을 제공합니다.
          </p>

          <span>기능 열기 →</span>

        </Link>

        <div className="starter-card">

          <div className="starter-card-icon">
            🔐
          </div>

          <h2>공통 인증 시스템</h2>

          <p>
            JWT 인증과 Refresh Token을
            이용해 웹과 모바일 앱에서
            동일한 회원 시스템을 사용합니다.
          </p>

        </div>

      </section>

      {user && (
        <section className="starter-panel">

          <h2>내 계정 정보</h2>

          <div className="starter-info-row">
            <strong>이름</strong>
            <span>{user.name}</span>
          </div>

          <div className="starter-info-row">
            <strong>이메일</strong>
            <span>{user.email}</span>
          </div>

          <div className="starter-info-row">
            <strong>회원 ID</strong>
            <span>{user.id}</span>
          </div>

        </section>
      )}

    </div>
  );
}
'@

# ============================================================
# 로그인 페이지
# ============================================================

Save-WebFile "$AppRelative/starter/login/page.tsx" "이메일과 비밀번호를 이용한 로그인 화면" @'
"use client";

import {
  useState
} from "react";

import Link from "next/link";

import {
  useRouter
} from "next/navigation";

import {
  useAuth
} from "../_lib/auth";

import {
  getErrorMessage
} from "../_lib/api";

export default function LoginPage() {

  const router = useRouter();

  const {
    login
  } = useAuth();

  const [email, setEmail] = useState("");

  const [password, setPassword] = useState("");

  const [submitting, setSubmitting] = useState(false);

  const [error, setError] = useState("");

  async function handleSubmit(
    event: React.FormEvent<HTMLFormElement>
  ) {

    event.preventDefault();

    if (submitting) {
      return;
    }

    setSubmitting(true);

    setError("");

    try {

      await login(email, password);

      router.push("/starter");

    }
    catch (caught) {

      setError(getErrorMessage(caught));

    }
    finally {

      setSubmitting(false);

    }
  }

  return (
    <div className="starter-auth-page">

      <div className="starter-auth-card">

        <h1>로그인</h1>

        <p>
          등록한 계정으로 로그인해 주세요.
        </p>

        {error && (
          <div
            className="starter-error"
            role="alert"
          >
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit}>

          <label htmlFor="login-email">
            이메일
          </label>

          <input
            id="login-email"
            type="email"
            autoComplete="email"
            required
            value={email}
            onChange={(event) =>
              setEmail(event.target.value)
            }
          />

          <label htmlFor="login-password">
            비밀번호
          </label>

          <input
            id="login-password"
            type="password"
            autoComplete="current-password"
            required
            value={password}
            onChange={(event) =>
              setPassword(event.target.value)
            }
          />

          <button
            type="submit"
            className="starter-button full"
            disabled={submitting}
          >
            {submitting
              ? "로그인 중..."
              : "로그인"}
          </button>

        </form>

        <div className="starter-auth-bottom">

          아직 회원이 아니신가요?

          <Link href="/starter/register">
            회원가입
          </Link>

        </div>

      </div>

    </div>
  );
}
'@

# ============================================================
# 회원가입 페이지
# ============================================================

Save-WebFile "$AppRelative/starter/register/page.tsx" "회원가입 입력 화면과 API 연결" @'
"use client";

import {
  useState
} from "react";

import Link from "next/link";

import {
  useRouter
} from "next/navigation";

import {
  useAuth
} from "../_lib/auth";

import {
  getErrorMessage
} from "../_lib/api";

export default function RegisterPage() {

  const router = useRouter();

  const {
    register
  } = useAuth();

  const [name, setName] = useState("");

  const [email, setEmail] = useState("");

  const [password, setPassword] = useState("");

  const [passwordConfirm, setPasswordConfirm] =
    useState("");

  const [submitting, setSubmitting] = useState(false);

  const [error, setError] = useState("");

  async function handleSubmit(
    event: React.FormEvent<HTMLFormElement>
  ) {

    event.preventDefault();

    if (submitting) {
      return;
    }

    if (password !== passwordConfirm) {

      setError(
        "비밀번호 확인이 일치하지 않습니다."
      );

      return;
    }

    setSubmitting(true);

    setError("");

    try {

      await register(
        email,
        password,
        name
      );

      router.push("/starter");

    }
    catch (caught) {

      setError(getErrorMessage(caught));

    }
    finally {

      setSubmitting(false);

    }
  }

  return (
    <div className="starter-auth-page">

      <div className="starter-auth-card">

        <h1>회원가입</h1>

        <p>
          새로운 계정을 생성합니다.
        </p>

        {error && (
          <div
            className="starter-error"
            role="alert"
          >
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit}>

          <label htmlFor="register-name">
            이름
          </label>

          <input
            id="register-name"
            type="text"
            required
            minLength={2}
            maxLength={60}
            autoComplete="name"
            value={name}
            onChange={(event) =>
              setName(event.target.value)
            }
          />

          <label htmlFor="register-email">
            이메일
          </label>

          <input
            id="register-email"
            type="email"
            required
            autoComplete="email"
            value={email}
            onChange={(event) =>
              setEmail(event.target.value)
            }
          />

          <label htmlFor="register-password">
            비밀번호
          </label>

          <input
            id="register-password"
            type="password"
            required
            minLength={12}
            autoComplete="new-password"
            value={password}
            onChange={(event) =>
              setPassword(event.target.value)
            }
          />

          <label htmlFor="register-password-confirm">
            비밀번호 확인
          </label>

          <input
            id="register-password-confirm"
            type="password"
            required
            autoComplete="new-password"
            value={passwordConfirm}
            onChange={(event) =>
              setPasswordConfirm(event.target.value)
            }
          />

          <button
            type="submit"
            className="starter-button full"
            disabled={submitting}
          >
            {submitting
              ? "회원가입 중..."
              : "회원가입"}
          </button>

        </form>

        <div className="starter-auth-bottom">

          이미 계정이 있으신가요?

          <Link href="/starter/login">
            로그인
          </Link>

        </div>

      </div>

    </div>
  );
}
'@

# ============================================================
# 게시글 CRUD 페이지
# ============================================================

Save-WebFile "$AppRelative/starter/notes/page.tsx" "게시글 CRUD와 검색, 정렬, 페이징 화면" @'
"use client";

import {
  useCallback,
  useEffect,
  useState
} from "react";

import Link from "next/link";

import {
  useAuth
} from "../_lib/auth";

import {
  getErrorMessage
} from "../_lib/api";

import type {
  PaginatedResult
} from "../_lib/api";

// 게시글 데이터 구조
interface Note {
  id: string;
  title: string;
  content: string;
  createdAt: string;
  updatedAt: string;
}

export default function NotesPage() {

  const {
    user,
    loading,
    request
  } = useAuth();

  const [items, setItems] = useState<Note[]>([]);

  const [page, setPage] = useState(1);

  const [totalPages, setTotalPages] = useState(1);

  const [total, setTotal] = useState(0);

  const [searchInput, setSearchInput] = useState("");

  const [search, setSearch] = useState("");

  const [sortBy, setSortBy] = useState("createdAt");

  const [sortOrder, setSortOrder] = useState("desc");

  const [title, setTitle] = useState("");

  const [content, setContent] = useState("");

  const [editingId, setEditingId] =
    useState<string | null>(null);

  const [submitting, setSubmitting] = useState(false);

  const [error, setError] = useState("");

  const [message, setMessage] = useState("");

  // 게시글 목록 조회
  const loadNotes = useCallback(async () => {

    try {

      const params = new URLSearchParams({
        page: String(page),
        limit: "10",
        search,
        sortBy,
        sortOrder
      });

      const result =
        await request<PaginatedResult<Note>>(
          `/notes?${params.toString()}`
        );

      setItems(result.items);

      setTotal(result.pagination.total);

      setTotalPages(
        Math.max(
          1,
          result.pagination.totalPages
        )
      );

      setError("");

    }
    catch (caught) {

      setError(getErrorMessage(caught));

    }

  }, [
    request,
    page,
    search,
    sortBy,
    sortOrder
  ]);

  useEffect(() => {

    if (!loading && user) {
      void loadNotes();
    }

  }, [loading, user, loadNotes]);

  // 검색 적용
  function handleSearch(
    event: React.FormEvent<HTMLFormElement>
  ) {

    event.preventDefault();

    setPage(1);

    setSearch(searchInput.trim());
  }

  // 게시글 등록 또는 수정
  async function handleSave(
    event: React.FormEvent<HTMLFormElement>
  ) {

    event.preventDefault();

    if (submitting) {
      return;
    }

    setSubmitting(true);

    setError("");

    setMessage("");

    try {

      const path = editingId
        ? `/notes/${editingId}`
        : "/notes";

      const method = editingId
        ? "PATCH"
        : "POST";

      await request<Note>(
        path,
        {
          method,

          headers: {
            "Content-Type":
              "application/json; charset=utf-8"
          },

          body: JSON.stringify({
            title,
            content
          })
        }
      );

      setTitle("");

      setContent("");

      setEditingId(null);

      setMessage(
        "게시글이 저장되었습니다."
      );

      if (page === 1) {
        await loadNotes();
      }
      else {
        setPage(1);
      }

    }
    catch (caught) {

      setError(getErrorMessage(caught));

    }
    finally {

      setSubmitting(false);

    }
  }

  // 수정할 게시글 선택
  function handleEdit(note: Note) {

    setEditingId(note.id);

    setTitle(note.title);

    setContent(note.content);

    setMessage("");

    window.scrollTo({
      top: 0,
      behavior: "smooth"
    });
  }

  // 수정 취소
  function handleCancelEdit() {

    setEditingId(null);

    setTitle("");

    setContent("");
  }

  // 게시글 삭제
  async function handleDelete(id: string) {

    if (
      !window.confirm(
        "이 게시글을 삭제하시겠습니까?"
      )
    ) {
      return;
    }

    try {

      await request(
        `/notes/${id}`,
        {
          method: "DELETE"
        }
      );

      setMessage(
        "게시글이 삭제되었습니다."
      );

      await loadNotes();

    }
    catch (caught) {

      setError(getErrorMessage(caught));

    }
  }

  if (loading) {
    return (
      <div className="starter-container">
        <p>로그인 상태를 확인하고 있습니다.</p>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="starter-container">

        <div className="starter-panel">

          <h2>로그인이 필요합니다.</h2>

          <Link
            href="/starter/login"
            className="starter-button"
          >
            로그인하기
          </Link>

        </div>

      </div>
    );
  }

  return (
    <div className="starter-container">

      <div className="starter-page-heading">

        <h1>게시글 관리</h1>

        <p>
          게시글 등록, 조회, 수정, 삭제,
          검색 및 정렬 기능입니다.
        </p>

      </div>

      {error && (
        <div className="starter-error" role="alert">
          {error}
        </div>
      )}

      {message && (
        <div className="starter-success">
          {message}
        </div>
      )}

      <section className="starter-panel">

        <h2>
          {editingId
            ? "게시글 수정"
            : "새 게시글 등록"}
        </h2>

        <form onSubmit={handleSave}>

          <label htmlFor="note-title">
            제목
          </label>

          <input
            id="note-title"
            type="text"
            required
            maxLength={120}
            value={title}
            onChange={(event) =>
              setTitle(event.target.value)
            }
          />

          <label htmlFor="note-content">
            내용
          </label>

          <textarea
            id="note-content"
            required
            maxLength={10000}
            rows={6}
            value={content}
            onChange={(event) =>
              setContent(event.target.value)
            }
          />

          <div className="starter-actions">

            <button
              type="submit"
              className="starter-button"
              disabled={submitting}
            >
              {submitting
                ? "저장 중..."
                : editingId
                  ? "수정 완료"
                  : "게시글 등록"}
            </button>

            {editingId && (
              <button
                type="button"
                className="starter-button secondary"
                onClick={handleCancelEdit}
              >
                수정 취소
              </button>
            )}

          </div>

        </form>

      </section>

      <section className="starter-panel">

        <h2>게시글 목록</h2>

        <form
          className="starter-search"
          onSubmit={handleSearch}
        >

          <input
            type="search"
            aria-label="게시글 검색어"
            placeholder="게시글 검색"
            value={searchInput}
            onChange={(event) =>
              setSearchInput(event.target.value)
            }
          />

          <button
            type="submit"
            className="starter-button"
          >
            검색
          </button>

        </form>

        <div className="starter-toolbar">

          <span>
            전체 {total}개
          </span>

          <div className="starter-toolbar-controls">

            <select
              aria-label="정렬 기준"
              value={sortBy}
              onChange={(event) => {
                setPage(1);
                setSortBy(event.target.value);
              }}
            >
              <option value="createdAt">
                등록일
              </option>

              <option value="updatedAt">
                수정일
              </option>

              <option value="title">
                제목
              </option>
            </select>

            <select
              aria-label="정렬 방향"
              value={sortOrder}
              onChange={(event) => {
                setPage(1);
                setSortOrder(event.target.value);
              }}
            >
              <option value="desc">
                내림차순
              </option>

              <option value="asc">
                오름차순
              </option>
            </select>

          </div>

        </div>

        {items.length === 0 && (
          <div className="starter-empty">
            등록된 게시글이 없습니다.
          </div>
        )}

        <div className="starter-list">

          {items.map((note) => (

            <article
              key={note.id}
              className="starter-list-item"
            >

              <h3>{note.title}</h3>

              <p className="starter-note-content">
                {note.content}
              </p>

              <div className="starter-list-bottom">

                <small>
                  {new Date(
                    note.createdAt
                  ).toLocaleString("ko-KR")}
                </small>

                <div className="starter-actions">

                  <button
                    type="button"
                    className="starter-button secondary"
                    onClick={() =>
                      handleEdit(note)
                    }
                  >
                    수정
                  </button>

                  <button
                    type="button"
                    className="starter-button danger"
                    onClick={() =>
                      handleDelete(note.id)
                    }
                  >
                    삭제
                  </button>

                </div>

              </div>

            </article>

          ))}

        </div>

        <div className="starter-pagination">

          <button
            type="button"
            className="starter-button secondary"
            disabled={page <= 1}
            onClick={() =>
              setPage((current) =>
                Math.max(1, current - 1)
              )
            }
          >
            이전
          </button>

          <span>
            {page} / {totalPages}
          </span>

          <button
            type="button"
            className="starter-button secondary"
            disabled={page >= totalPages}
            onClick={() =>
              setPage((current) =>
                current + 1
              )
            }
          >
            다음
          </button>

        </div>

      </section>

    </div>
  );
}
'@

# ============================================================
# 파일 관리 페이지
# ============================================================

Save-WebFile "$AppRelative/starter/files/page.tsx" "파일 업로드, 목록, 다운로드 및 삭제 화면" @'
"use client";

import {
  useCallback,
  useEffect,
  useState
} from "react";

import Link from "next/link";

import {
  useAuth
} from "../_lib/auth";

import {
  getErrorMessage
} from "../_lib/api";

import type {
  PaginatedResult
} from "../_lib/api";

// 파일 메타데이터
interface StoredFile {
  id: string;
  originalName: string;
  mimeType: string;
  size: number;
  createdAt: string;
}

export default function FilesPage() {

  const {
    user,
    loading,
    request,
    authorizedFetch
  } = useAuth();

  const [files, setFiles] =
    useState<StoredFile[]>([]);

  const [selectedFile, setSelectedFile] =
    useState<File | null>(null);

  const [uploading, setUploading] =
    useState(false);

  const [error, setError] = useState("");

  const [message, setMessage] = useState("");

  // 파일 목록 조회
  const loadFiles = useCallback(async () => {

    try {

      const result =
        await request<PaginatedResult<StoredFile>>(
          "/files?page=1&limit=100"
        );

      setFiles(result.items);

      setError("");

    }
    catch (caught) {

      setError(getErrorMessage(caught));

    }

  }, [request]);

  useEffect(() => {

    if (!loading && user) {
      void loadFiles();
    }

  }, [loading, user, loadFiles]);

  // 파일 업로드
  async function handleUpload(
    event: React.FormEvent<HTMLFormElement>
  ) {

    event.preventDefault();

    if (!selectedFile || uploading) {
      return;
    }

    // 사용자 편의를 위한 사전 검사입니다.
    // 최종 용량과 파일 형식은 백엔드에서 검증합니다.
    if (selectedFile.size > 5 * 1024 * 1024) {

      setError(
        "파일 크기는 5MB 이하여야 합니다."
      );

      return;
    }

    setUploading(true);

    setError("");

    setMessage("");

    try {

      const formData = new FormData();

      formData.append(
        "file",
        selectedFile
      );

      await request<StoredFile>(
        "/files",
        {
          method: "POST",
          body: formData
        }
      );

      setSelectedFile(null);

      const input = document.getElementById(
        "starter-file-input"
      ) as HTMLInputElement | null;

      if (input) {
        input.value = "";
      }

      setMessage(
        "파일 업로드가 완료되었습니다."
      );

      await loadFiles();

    }
    catch (caught) {

      setError(getErrorMessage(caught));

    }
    finally {

      setUploading(false);

    }
  }

  // 파일 다운로드
  async function handleDownload(
    file: StoredFile
  ) {

    try {

      const response = await authorizedFetch(
        `/files/${file.id}/download`
      );

      if (!response.ok) {
        throw new Error(
          "파일 다운로드에 실패했습니다."
        );
      }

      const blob = await response.blob();

      const url = URL.createObjectURL(blob);

      const anchor =
        document.createElement("a");

      anchor.href = url;

      anchor.download = file.originalName;

      document.body.appendChild(anchor);

      anchor.click();

      anchor.remove();

      window.setTimeout(() => {
        URL.revokeObjectURL(url);
      }, 1000);

    }
    catch (caught) {

      setError(getErrorMessage(caught));

    }
  }

  // 파일 삭제
  async function handleDelete(
    file: StoredFile
  ) {

    if (
      !window.confirm(
        `"${file.originalName}" 파일을 삭제하시겠습니까?`
      )
    ) {
      return;
    }

    try {

      await request(
        `/files/${file.id}`,
        {
          method: "DELETE"
        }
      );

      setMessage(
        "파일이 삭제되었습니다."
      );

      await loadFiles();

    }
    catch (caught) {

      setError(getErrorMessage(caught));

    }
  }

  if (loading) {
    return (
      <div className="starter-container">
        <p>로그인 상태를 확인하고 있습니다.</p>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="starter-container">

        <div className="starter-panel">

          <h2>로그인이 필요합니다.</h2>

          <Link
            href="/starter/login"
            className="starter-button"
          >
            로그인하기
          </Link>

        </div>

      </div>
    );
  }

  return (
    <div className="starter-container">

      <div className="starter-page-heading">

        <h1>파일 관리</h1>

        <p>
          파일 업로드, 다운로드,
          목록 조회 및 삭제 기능입니다.
        </p>

      </div>

      {error && (
        <div
          className="starter-error"
          role="alert"
        >
          {error}
        </div>
      )}

      {message && (
        <div className="starter-success">
          {message}
        </div>
      )}

      <section className="starter-panel">

        <h2>파일 업로드</h2>

        <form onSubmit={handleUpload}>

          <input
            id="starter-file-input"
            type="file"
            required
            onChange={(event) =>
              setSelectedFile(
                event.target.files?.[0] ?? null
              )
            }
          />

          <p className="starter-help">
            최대 파일 크기: 5MB
          </p>

          <button
            type="submit"
            className="starter-button"
            disabled={
              uploading ||
              !selectedFile
            }
          >
            {uploading
              ? "업로드 중..."
              : "파일 업로드"}
          </button>

        </form>

      </section>

      <section className="starter-panel">

        <h2>업로드한 파일</h2>

        {files.length === 0 && (
          <div className="starter-empty">
            업로드한 파일이 없습니다.
          </div>
        )}

        <div className="starter-list">

          {files.map((file) => (

            <div
              key={file.id}
              className="starter-list-item"
            >

              <h3>
                {file.originalName}
              </h3>

              <p>
                {(file.size / 1024).toFixed(1)} KB
              </p>

              <div className="starter-list-bottom">

                <small>
                  {new Date(
                    file.createdAt
                  ).toLocaleString("ko-KR")}
                </small>

                <div className="starter-actions">

                  <button
                    type="button"
                    className="starter-button secondary"
                    onClick={() =>
                      handleDownload(file)
                    }
                  >
                    다운로드
                  </button>

                  <button
                    type="button"
                    className="starter-button danger"
                    onClick={() =>
                      handleDelete(file)
                    }
                  >
                    삭제
                  </button>

                </div>

              </div>

            </div>

          ))}

        </div>

      </section>

    </div>
  );
}
'@

# ============================================================
# 공통 디자인
# ============================================================

Save-WebFile "$AppRelative/starter/starter.css" "PC와 모바일에서 사용할 반응형 공통 디자인" @'
.starter-root {
  --starter-primary: #2563eb;
  --starter-primary-dark: #1d4ed8;
  --starter-background: #f5f7fb;
  --starter-surface: #ffffff;
  --starter-text: #172033;
  --starter-muted: #64748b;
  --starter-border: #e2e8f0;

  min-height: 100vh;
  background: var(--starter-background);
  color: var(--starter-text);
  font-family:
    "Pretendard",
    "Malgun Gothic",
    Arial,
    sans-serif;
  line-height: 1.6;
}

.starter-root *,
.starter-root *::before,
.starter-root *::after {
  box-sizing: border-box;
}

.starter-root a {
  text-decoration: none;
  color: inherit;
}

.starter-root button,
.starter-root input,
.starter-root textarea,
.starter-root select {
  font: inherit;
}

.starter-root button {
  cursor: pointer;
}

.starter-header {
  background: #ffffff;
  border-bottom: 1px solid var(--starter-border);
}

.starter-header-inner {
  max-width: 1200px;
  min-height: 76px;
  margin: 0 auto;
  padding: 12px 24px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 24px;
}

.starter-logo {
  font-size: 20px;
  font-weight: 800;
  letter-spacing: -0.5px;
  color: var(--starter-primary) !important;
}

.starter-nav {
  display: flex;
  align-items: center;
  gap: 24px;
}

.starter-nav a {
  color: #475569;
  font-weight: 600;
}

.starter-nav a:hover {
  color: var(--starter-primary);
}

.starter-account {
  display: flex;
  align-items: center;
  gap: 10px;
}

.starter-user {
  font-size: 14px;
  font-weight: 600;
}

.starter-main {
  min-height: calc(100vh - 150px);
}

.starter-container {
  width: 100%;
  max-width: 1100px;
  margin: 0 auto;
  padding: 42px 24px 80px;
}

.starter-hero {
  padding: 70px 24px;
  text-align: center;
}

.starter-badge {
  display: inline-block;
  padding: 7px 15px;
  border-radius: 100px;
  background: #dbeafe;
  color: #1d4ed8;
  font-size: 12px;
  font-weight: 800;
  letter-spacing: 1px;
}

.starter-hero h1 {
  margin: 24px 0;
  font-size: clamp(32px, 5vw, 52px);
  line-height: 1.25;
  letter-spacing: -1.5px;
}

.starter-hero > p {
  max-width: 650px;
  margin: 0 auto;
  color: var(--starter-muted);
  font-size: 17px;
}

.starter-actions {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 10px;
}

.starter-hero .starter-actions {
  justify-content: center;
  margin-top: 30px;
}

.starter-button {
  display: inline-flex;
  justify-content: center;
  align-items: center;
  min-height: 40px;
  padding: 9px 17px;
  border: 1px solid transparent;
  border-radius: 9px;
  background: var(--starter-primary);
  color: #ffffff !important;
  font-size: 14px;
  font-weight: 700;
  transition: background 0.15s ease;
}

.starter-button:hover {
  background: var(--starter-primary-dark);
}

.starter-button.secondary {
  background: #ffffff;
  border-color: var(--starter-border);
  color: #334155 !important;
}

.starter-button.secondary:hover {
  background: #f1f5f9;
}

.starter-button.danger {
  background: #dc2626;
}

.starter-button.danger:hover {
  background: #b91c1c;
}

.starter-button.large {
  min-height: 48px;
  padding: 12px 25px;
}

.starter-button.full {
  width: 100%;
}

.starter-button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.starter-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 20px;
}

.starter-card {
  min-height: 230px;
  padding: 28px;
  background: var(--starter-surface);
  border: 1px solid var(--starter-border);
  border-radius: 16px;
  transition: transform 0.2s ease;
}

.starter-card:hover {
  transform: translateY(-3px);
}

.starter-card-icon {
  font-size: 32px;
  margin-bottom: 12px;
}

.starter-card h2 {
  margin: 0 0 12px;
  font-size: 20px;
}

.starter-card p {
  color: var(--starter-muted);
  font-size: 14px;
}

.starter-card span {
  display: inline-block;
  margin-top: 12px;
  color: var(--starter-primary);
  font-weight: 700;
}

.starter-welcome {
  max-width: 550px;
  margin: 30px auto 0;
  padding: 22px;
  background: #ffffff;
  border: 1px solid var(--starter-border);
  border-radius: 14px;
}

.starter-welcome h2 {
  margin: 0 0 8px;
}

.starter-welcome p {
  margin: 0;
  color: var(--starter-muted);
}

.starter-panel {
  margin-top: 24px;
  padding: 28px;
  background: #ffffff;
  border: 1px solid var(--starter-border);
  border-radius: 15px;
}

.starter-panel h2 {
  margin: 0 0 22px;
  font-size: 21px;
}

.starter-info-row {
  display: flex;
  justify-content: space-between;
  gap: 20px;
  padding: 12px 0;
  border-bottom: 1px solid var(--starter-border);
  overflow-wrap: anywhere;
}

.starter-info-row:last-child {
  border-bottom: 0;
}

.starter-page-heading {
  margin-bottom: 30px;
}

.starter-page-heading h1 {
  margin: 0 0 8px;
  font-size: 32px;
}

.starter-page-heading p {
  margin: 0;
  color: var(--starter-muted);
}

.starter-auth-page {
  min-height: 70vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 40px 20px;
}

.starter-auth-card {
  width: 100%;
  max-width: 440px;
  padding: 36px;
  background: #ffffff;
  border: 1px solid var(--starter-border);
  border-radius: 18px;
  box-shadow: 0 10px 35px rgba(0, 0, 0, 0.04);
}

.starter-auth-card h1 {
  margin: 0 0 10px;
  font-size: 30px;
}

.starter-auth-card > p {
  margin-bottom: 25px;
  color: var(--starter-muted);
}

.starter-root form label {
  display: block;
  margin: 15px 0 7px;
  font-weight: 700;
  font-size: 14px;
}

.starter-root input,
.starter-root textarea,
.starter-root select {
  width: 100%;
  padding: 12px;
  background: #ffffff;
  border: 1px solid #cbd5e1;
  border-radius: 8px;
  color: var(--starter-text);
  outline: none;
}

.starter-root input:focus,
.starter-root textarea:focus,
.starter-root select:focus {
  border-color: var(--starter-primary);
}

.starter-root textarea {
  resize: vertical;
}

.starter-root form > .starter-button {
  margin-top: 20px;
}

.starter-auth-bottom {
  margin-top: 24px;
  text-align: center;
  font-size: 14px;
}

.starter-auth-bottom a {
  margin-left: 8px;
  color: var(--starter-primary);
  font-weight: 700;
}

.starter-error {
  margin: 15px 0;
  padding: 13px 16px;
  background: #fef2f2;
  color: #b91c1c;
  border: 1px solid #fecaca;
  border-radius: 9px;
}

.starter-global-error {
  max-width: 1100px;
  margin: 15px auto;
  padding: 13px 16px;
  background: #fef2f2;
  color: #b91c1c;
  border-radius: 9px;
}

.starter-success {
  margin: 15px 0;
  padding: 13px 16px;
  background: #f0fdf4;
  color: #15803d;
  border: 1px solid #bbf7d0;
  border-radius: 9px;
}

.starter-search {
  display: flex;
  gap: 10px;
}

.starter-search input {
  flex: 1;
}

.starter-toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 20px;
  margin: 24px 0;
}

.starter-toolbar-controls {
  display: flex;
  gap: 10px;
}

.starter-toolbar-controls select {
  min-width: 120px;
}

.starter-list {
  display: flex;
  flex-direction: column;
  gap: 14px;
}

.starter-list-item {
  padding: 20px;
  background: #ffffff;
  border: 1px solid var(--starter-border);
  border-radius: 12px;
}

.starter-list-item h3 {
  margin: 0 0 10px;
  overflow-wrap: anywhere;
}

.starter-list-item p {
  color: var(--starter-muted);
}

.starter-note-content {
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}

.starter-list-bottom {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 15px;
  margin-top: 20px;
}

.starter-list-bottom small {
  color: var(--starter-muted);
}

.starter-pagination {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 20px;
  margin-top: 25px;
}

.starter-empty {
  padding: 45px 20px;
  text-align: center;
  color: var(--starter-muted);
}

.starter-help {
  color: var(--starter-muted);
  font-size: 13px;
}

.starter-footer {
  padding: 24px;
  text-align: center;
  color: var(--starter-muted);
  font-size: 13px;
  border-top: 1px solid var(--starter-border);
}

@media (max-width: 800px) {

  .starter-grid {
    grid-template-columns: 1fr;
  }

  .starter-header-inner {
    flex-wrap: wrap;
  }

  .starter-nav {
    order: 3;
    width: 100%;
    justify-content: center;
  }

  .starter-hero {
    padding: 40px 10px;
  }

  .starter-container {
    padding: 25px 16px 60px;
  }

  .starter-panel {
    padding: 20px;
  }

  .starter-toolbar {
    flex-direction: column;
    align-items: stretch;
  }

  .starter-list-bottom {
    flex-direction: column;
    align-items: flex-start;
  }

  .starter-auth-card {
    padding: 25px;
  }

  .starter-user {
    display: none;
  }
}

@media (max-width: 480px) {

  .starter-logo {
    font-size: 16px;
  }

  .starter-nav {
    gap: 15px;
    font-size: 14px;
  }

  .starter-button {
    padding: 8px 12px;
    font-size: 13px;
  }

  .starter-search {
    flex-direction: column;
  }

  .starter-toolbar-controls {
    flex-direction: column;
  }
}
'@

# ============================================================
# 6부 완료 안내
# ============================================================

Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host " 6부 프론트엔드 파일 생성 완료"
Write-Host "============================================" -ForegroundColor Green
Write-Host ""

Write-Host "프로젝트 경로: $Root"
Write-Host "웹 프로젝트: $WebRoot"
Write-Host "App Router: $AppRelative"

Write-Host ""
Write-Host "생성된 주요 기능:"
Write-Host " - 메인 대시보드"
Write-Host " - 회원가입"
Write-Host " - 로그인"
Write-Host " - JWT 인증 관리"
Write-Host " - Refresh Token 갱신"
Write-Host " - 게시글 CRUD"
Write-Host " - 검색, 정렬, 페이징"
Write-Host " - 파일 업로드 및 다운로드"
Write-Host " - 모바일 반응형 디자인"

Write-Host ""
Write-Host "기존 백엔드 파일은 변경하지 않았습니다." -ForegroundColor Cyan

Write-Host ""
Write-Host "다음 명령어로 실행하세요:"
Write-Host ""
Write-Host 'cd "$env:USERPROFILE\Desktop\secure-starter"'
Write-Host "npm install"
Write-Host "npm run dev -w @starter/web"

Write-Host ""
Write-Host "접속 주소:"
Write-Host "http://localhost:3000/starter"
Write-Host ""

