﻿# filepath: create-starter-part7.ps1 - 풀스택 Starter Kit 7부 공통 API 및 UI 생성

$ErrorActionPreference = "Stop"

# ============================================================
# 프로젝트 경로
# ============================================================

$Root = Join-Path $env:USERPROFILE "Desktop\secure-starter"

# 보안 검토가 끝난 프로젝트에 예전 생성 코드를 덮어쓰지 않습니다.
if (Test-Path -LiteralPath (Join-Path $Root "SECURITY-REVISION.json")) {
    throw "보안 수정이 적용된 V5입니다. 이전 부별 생성 스크립트 적용을 차단합니다."
}


$WebRoot = Join-Path $Root "apps\web"

# UTF-8 BOM 없는 인코딩
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)

# 생성 결과 집계
$script:CreatedCount = 0
$script:SkippedCount = 0

# ============================================================
# 기존 프로젝트 확인
# ============================================================

if (-not (Test-Path (Join-Path $Root "package.json"))) {
    throw "secure-starter 프로젝트가 없습니다."
}

if (-not (Test-Path (Join-Path $WebRoot "package.json"))) {
    throw "Next.js 프론트엔드 프로젝트가 없습니다."
}

if (-not (Test-Path (Join-Path $Root "apps\api\package.json"))) {
    throw "기존 백엔드 프로젝트가 없습니다."
}

# ============================================================
# 파일 생성 공통 함수
# ============================================================

function Save-Part7File {

    param(
        [string]$RelativePath,
        [string]$Description,
        [string]$Content
    )

    $FullPath = Join-Path $Root $RelativePath

    $Directory = Split-Path $FullPath -Parent

    # 기존 파일은 절대로 덮어쓰지 않습니다.
    if (Test-Path $FullPath) {

        Write-Host "[기존 파일 보호] $RelativePath" -ForegroundColor Yellow

        $script:SkippedCount++

        return
    }

    if (-not (Test-Path $Directory)) {

        New-Item `
            -ItemType Directory `
            -Path $Directory `
            -Force | Out-Null
    }

    $Extension = [System.IO.Path]::GetExtension($RelativePath)

    $Header = switch ($Extension) {

        ".ts" {
            "// filepath: $RelativePath - $Description`n"
        }

        ".tsx" {
            "// filepath: $RelativePath - $Description`n"
        }

        ".css" {
            "/* filepath: $RelativePath - $Description */`n"
        }

        ".md" {
            "<!-- filepath: $RelativePath - $Description -->`n"
        }

        default {
            "# filepath: $RelativePath - $Description`n"
        }
    }

    $FinalContent = $Header + $Content

    [System.IO.File]::WriteAllText(
        $FullPath,
        $FinalContent,
        $Utf8NoBom
    )

    $script:CreatedCount++

    Write-Host "[생성 완료] $RelativePath" -ForegroundColor Green
}

Write-Host ""
Write-Host "============================================"
Write-Host " 7부 풀스택 공통 시스템 생성 시작"
Write-Host "============================================"
Write-Host ""


# ============================================================
# 1. 공통 API 클라이언트
# ============================================================

Save-Part7File "apps/web/src/shared/api/client.ts" "웹과 모바일 연동을 고려한 공통 HTTP 클라이언트" @'
import type {
  RequestCredentials
} from "react";

// ============================================================
// API 기본 설정
// ============================================================

// 환경 변수에는 API 서버의 주소를 지정합니다.
// 기존 설정 이름과의 호환성을 위해 두 가지를 지원합니다.
const configuredUrl =
  process.env.NEXT_PUBLIC_API_BASE_URL ??
  process.env.NEXT_PUBLIC_API_URL ??
  "http://localhost:4000";

// URL을 검증하고 서버 Origin을 추출합니다.
const API_ORIGIN = new URL(configuredUrl).origin;

export const API_BASE_URL = `${API_ORIGIN}/api/v1`;

// ============================================================
// 공통 응답 타입
// ============================================================

export interface ApiSuccess<T> {
  success: true;
  data: T;
  message: string;
}

export interface ApiFailure {
  success: false;
  errorCode: string;
  message: string;
}

// ============================================================
// 공통 API 오류
// ============================================================

export class ApiClientError extends Error {

  constructor(
    public readonly status: number,
    public readonly errorCode: string,
    message: string
  ) {
    super(message);

    this.name = "ApiClientError";
  }
}

// ============================================================
// Access Token 메모리 저장소
// ============================================================

// Access Token을 localStorage에 저장하지 않습니다.
// 새로고침하면 메모리의 토큰은 사라집니다.
// 웹에서는 HttpOnly Refresh Cookie로 복구할 수 있습니다.

let accessToken: string | null = null;

export const tokenMemory = {

  get(): string | null {
    return accessToken;
  },

  set(token: string): void {
    accessToken = token;
  },

  clear(): void {
    accessToken = null;
  }
};

// ============================================================
// 요청 타입
// ============================================================

export type HttpMethod =
  | "GET"
  | "POST"
  | "PUT"
  | "PATCH"
  | "DELETE";

export type AuthMode =
  | "none"
  | "optional"
  | "required";

type QueryValue =
  | string
  | number
  | boolean
  | null
  | undefined;

export interface ApiRequestOptions {

  path: string;

  method?: HttpMethod;

  body?: unknown;

  query?: Record<string, QueryValue>;

  signal?: AbortSignal;

  timeoutMs?: number;

  auth?: AuthMode;

  // 일반 API는 /api/v1을 사용합니다.
  // health API처럼 루트 경로가 필요하면 root를 사용합니다.
  scope?: "api" | "root";
}

// ============================================================
// 클라이언트 확장 옵션
// ============================================================

// 모바일 앱에서는 아래 콜백을 사용하여
// Expo SecureStore 등의 보안 저장소와 연결할 수 있습니다.

export interface ApiClientOptions {

  getAccessToken?: () => string | null;

  refreshAccessToken?: () => Promise<string | null>;

  onAccessToken?: (token: string | null) => void;

  onUnauthorized?: () => void;

  credentials?: RequestCredentials;
}

// ============================================================
// 안전한 URL 생성
// ============================================================

function createUrl(
  options: ApiRequestOptions
): string {

  const path = options.path;

  // 외부 URL로 요청이 전환되는 것을 방지합니다.
  if (
    !path.startsWith("/") ||
    path.startsWith("//") ||
    path.includes("\\") ||
    path.includes("?") ||
    path.includes("#")
  ) {
    throw new ApiClientError(
      0,
      "INVALID_API_PATH",
      "API 요청 경로가 올바르지 않습니다."
    );
  }

  const base =
    options.scope === "root"
      ? API_ORIGIN
      : API_BASE_URL;

  const url = new URL(base + path);

  // 쿼리 문자열은 URLSearchParams로 안전하게 구성합니다.
  if (options.query) {

    for (const [key, value] of Object.entries(options.query)) {

      if (value === undefined || value === null) {
        continue;
      }

      url.searchParams.set(
        key,
        String(value)
      );
    }
  }

  return url.toString();
}

// ============================================================
// JSON 응답 검증
// ============================================================

function isRecord(
  value: unknown
): value is Record<string, unknown> {

  return (
    typeof value === "object" &&
    value !== null &&
    !Array.isArray(value)
  );
}

async function parseResponse<T>(
  response: Response
): Promise<ApiSuccess<T>> {

  const text = await response.text();

  let payload: unknown;

  try {

    payload = text
      ? JSON.parse(text)
      : null;

  } catch {

    throw new ApiClientError(
      response.status,
      "INVALID_RESPONSE",
      "서버 응답 형식이 올바르지 않습니다."
    );
  }

  if (!isRecord(payload)) {

    throw new ApiClientError(
      response.status,
      "INVALID_RESPONSE",
      "서버 응답 데이터가 올바르지 않습니다."
    );
  }

  if (
    !response.ok ||
    payload.success !== true
  ) {

    const errorCode =
      typeof payload.errorCode === "string"
        ? payload.errorCode
        : "API_REQUEST_FAILED";

    const message =
      typeof payload.message === "string"
        ? payload.message
        : "요청을 처리하지 못했습니다.";

    throw new ApiClientError(
      response.status,
      errorCode,
      message
    );
  }

  return payload as unknown as ApiSuccess<T>;
}

// ============================================================
// 웹 Refresh Token 갱신
// ============================================================

// Refresh Token은 JavaScript에서 직접 읽지 않습니다.
// 브라우저가 HttpOnly Cookie를 자동으로 전송합니다.

async function refreshWebSession(): Promise<string | null> {

  const response = await fetch(
    `${API_BASE_URL}/auth/web/refresh`,
    {
      method: "POST",

      credentials: "include",

      headers: {
        Accept: "application/json"
      },

      cache: "no-store"
    }
  );

  if (!response.ok) {
    return null;
  }

  const result = await parseResponse<{
    accessToken: string;
  }>(response);

  const token = result.data?.accessToken;

  return typeof token === "string"
    ? token
    : null;
}

// ============================================================
// 공통 API 클라이언트 생성
// ============================================================

export function createApiClient(
  clientOptions: ApiClientOptions = {}
) {

  // 여러 요청이 동시에 401을 받더라도
  // Refresh Token 갱신 요청은 하나만 실행합니다.
  let refreshPromise: Promise<string | null> | null = null;

  const readToken =
    clientOptions.getAccessToken ??
    tokenMemory.get;

  const refreshToken =
    clientOptions.refreshAccessToken ??
    refreshWebSession;

  // ==========================================================
  // 실제 HTTP 요청
  // ==========================================================

  async function send(
    options: ApiRequestOptions,
    token: string | null
  ): Promise<Response> {

    const timeoutMs = options.timeoutMs ?? 10000;

    if (
      !Number.isFinite(timeoutMs) ||
      timeoutMs < 100 ||
      timeoutMs > 120000
    ) {
      throw new ApiClientError(
        0,
        "INVALID_TIMEOUT",
        "요청 제한 시간이 올바르지 않습니다."
      );
    }

    const controller = new AbortController();

    let timedOut = false;

    // 외부에서 요청 취소를 전달할 수 있습니다.
    const abortFromParent = () => {
      controller.abort();
    };

    if (options.signal?.aborted) {
      controller.abort();
    } else {
      options.signal?.addEventListener(
        "abort",
        abortFromParent,
        { once: true }
      );
    }

    const timeoutId = setTimeout(() => {

      timedOut = true;

      controller.abort();

    }, timeoutMs);

    const headers: Record<string, string> = {
      Accept: "application/json"
    };

    if (
      token &&
      options.auth !== "none"
    ) {
      headers.Authorization = `Bearer ${token}`;
    }

    let body: string | undefined;

    if (options.body !== undefined) {

      body = JSON.stringify(options.body);

      headers["Content-Type"] =
        "application/json; charset=utf-8";
    }

    try {

      return await fetch(
        createUrl(options),
        {
          method: options.method ?? "GET",

          headers,

          body,

          credentials:
            clientOptions.credentials ?? "include",

          signal: controller.signal,

          cache: "no-store"
        }
      );

    } catch {

      if (options.signal?.aborted) {

        throw new ApiClientError(
          0,
          "REQUEST_ABORTED",
          "요청이 취소되었습니다."
        );
      }

      if (timedOut) {

        throw new ApiClientError(
          0,
          "REQUEST_TIMEOUT",
          "서버 응답 시간이 초과되었습니다."
        );
      }

      throw new ApiClientError(
        0,
        "NETWORK_ERROR",
        "서버에 연결할 수 없습니다."
      );

    } finally {

      clearTimeout(timeoutId);

      options.signal?.removeEventListener(
        "abort",
        abortFromParent
      );
    }
  }

  // ==========================================================
  // Refresh Token 동시 갱신 방지
  // ==========================================================

  async function getRefreshedToken(): Promise<string | null> {

    if (!refreshPromise) {

      refreshPromise = Promise.resolve()
        .then(() => refreshToken())
        .finally(() => {
          refreshPromise = null;
        });
    }

    return refreshPromise;
  }

  // ==========================================================
  // 외부에서 사용하는 API 요청 함수
  // ==========================================================

  async function request<T>(
    options: ApiRequestOptions
  ): Promise<ApiSuccess<T>> {

    const authMode = options.auth ?? "required";

    const initialToken =
      authMode === "none"
        ? null
        : readToken();

    let response = await send(
      options,
      initialToken
    );

    // 인증이 필요한 요청에서만 자동 갱신합니다.
    // 인증 API 자체에 대한 무한 갱신을 방지합니다.
    if (
      response.status === 401 &&
      authMode === "required" &&
      !options.path.startsWith("/auth/")
    ) {

      let renewedToken: string | null = null;

      try {

        renewedToken = await getRefreshedToken();

      } catch {

        renewedToken = null;
      }

      if (renewedToken) {

        tokenMemory.set(renewedToken);

        clientOptions.onAccessToken?.(
          renewedToken
        );

        // 원래 요청을 한 번만 재시도합니다.
        response = await send(
          options,
          renewedToken
        );

      } else {

        tokenMemory.clear();

        clientOptions.onAccessToken?.(null);

        clientOptions.onUnauthorized?.();
      }
    }

    return parseResponse<T>(response);
  }

  return {
    request
  };
}

// ============================================================
// 웹 기본 API 클라이언트
// ============================================================

export const apiClient = createApiClient();
'@


# ============================================================
# 2. 웹 인증 공통 서비스
# ============================================================

Save-Part7File "apps/web/src/shared/api/web-auth.ts" "회원가입, 로그인, 로그아웃과 사용자 조회를 위한 웹 인증 서비스" @'
import {
  apiClient,
  tokenMemory
} from "./client";

// ============================================================
// 인증 요청 타입
// ============================================================

export interface LoginInput {
  email: string;
  password: string;
}

export interface RegisterInput {
  email: string;
  password: string;
  name: string;
}

// ============================================================
// 회원 정보 타입
// ============================================================

export interface PublicUser {
  id: string;
  email: string;
  name: string;
  createdAt: string;
  updatedAt: string;
}

// ============================================================
// 인증 응답 타입
// ============================================================

interface AuthData {
  user: PublicUser;
  accessToken: string;
}

// ============================================================
// 웹 인증 서비스
// ============================================================

export const webAuth = {

  // 회원가입
  async register(
    input: RegisterInput
  ): Promise<PublicUser> {

    const response = await apiClient.request<AuthData>({
      path: "/auth/web/register",
      method: "POST",
      body: input,
      auth: "none"
    });

    tokenMemory.set(
      response.data.accessToken
    );

    return response.data.user;
  },

  // 로그인
  async login(
    input: LoginInput
  ): Promise<PublicUser> {

    const response = await apiClient.request<AuthData>({
      path: "/auth/web/login",
      method: "POST",
      body: input,
      auth: "none"
    });

    tokenMemory.set(
      response.data.accessToken
    );

    return response.data.user;
  },

  // 내 정보 조회
  async me(): Promise<PublicUser> {

    const response = await apiClient.request<PublicUser>({
      path: "/auth/me",
      method: "GET",
      auth: "required"
    });

    return response.data;
  },

  // 현재 브라우저 로그아웃
  async logout(): Promise<void> {

    try {

      await apiClient.request({
        path: "/auth/web/logout",
        method: "POST",
        auth: "none"
      });

    } finally {

      // 서버 요청 실패 여부와 관계없이
      // 브라우저 메모리의 Access Token을 제거합니다.
      tokenMemory.clear();
    }
  },

  // 모든 기기 로그아웃
  async logoutAll(): Promise<void> {

    try {

      await apiClient.request({
        path: "/auth/logout-all",
        method: "POST",
        auth: "required"
      });

    } finally {

      tokenMemory.clear();
    }
  }
};
'@


# ============================================================
# 3. 공통 UI 컴포넌트
# ============================================================

Save-Part7File "apps/web/src/shared/ui/index.tsx" "버튼, 입력창, 모달, 알림, 로딩 및 페이지네이션 공통 UI" @'
"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useId,
  useRef,
  useState
} from "react";

import type {
  ButtonHTMLAttributes,
  InputHTMLAttributes,
  ReactNode
} from "react";

// ============================================================
// 공통 버튼
// ============================================================

export interface ButtonProps
  extends ButtonHTMLAttributes<HTMLButtonElement> {

  variant?: "primary" | "secondary" | "danger";

  loading?: boolean;
}

export function Button({
  children,
  variant = "primary",
  loading = false,
  disabled,
  className = "",
  type = "button",
  ...props
}: ButtonProps) {

  return (
    <button
      {...props}
      type={type}
      disabled={disabled || loading}
      aria-busy={loading}
      className={`sk-button sk-button-${variant} ${className}`}
    >
      {loading ? (
        <>
          <span
            className="sk-spinner"
            aria-hidden="true"
          />
          처리 중...
        </>
      ) : children}
    </button>
  );
}

// ============================================================
// 공통 입력창
// ============================================================

export interface TextFieldProps
  extends InputHTMLAttributes<HTMLInputElement> {

  label: string;

  error?: string;

  hint?: string;
}

export function TextField({
  label,
  error,
  hint,
  id,
  className = "",
  ...props
}: TextFieldProps) {

  const generatedId = useId();

  const inputId = id ?? generatedId;

  const messageId = `${inputId}-message`;

  return (
    <div className={`sk-field ${className}`}>

      <label
        htmlFor={inputId}
        className="sk-label"
      >
        {label}
      </label>

      <input
        {...props}
        id={inputId}
        className="sk-input"
        aria-invalid={Boolean(error)}
        aria-describedby={
          error || hint
            ? messageId
            : undefined
        }
      />

      {error ? (
        <p
          id={messageId}
          className="sk-field-error"
          role="alert"
        >
          {error}
        </p>
      ) : hint ? (
        <p
          id={messageId}
          className="sk-field-hint"
        >
          {hint}
        </p>
      ) : null}

    </div>
  );
}

// ============================================================
// 공통 로딩 표시
// ============================================================

export function Loading({
  message = "불러오는 중입니다."
}: {
  message?: string;
}) {

  return (
    <div
      className="sk-loading"
      role="status"
      aria-live="polite"
    >
      <span
        className="sk-spinner"
        aria-hidden="true"
      />

      <span>{message}</span>
    </div>
  );
}

// ============================================================
// 공통 빈 데이터 표시
// ============================================================

export function EmptyState({
  title,
  description
}: {
  title: string;
  description?: string;
}) {

  return (
    <div className="sk-empty">

      <strong>{title}</strong>

      {description && (
        <p>{description}</p>
      )}

    </div>
  );
}

// ============================================================
// 공통 모달
// ============================================================

// 브라우저 기본 dialog 요소를 사용합니다.
// ESC 키, 배경 차단, 포커스 이동 기능을 활용합니다.

export function Modal({
  open,
  title,
  children,
  onClose
}: {
  open: boolean;
  title: string;
  children: ReactNode;
  onClose: () => void;
}) {

  const dialogRef = useRef<HTMLDialogElement>(null);

  const titleId = useId();

  useEffect(() => {

    const dialog = dialogRef.current;

    if (!dialog) {
      return;
    }

    if (open && !dialog.open) {
      dialog.showModal();
    }

    if (!open && dialog.open) {
      dialog.close();
    }

    return () => {

      if (dialog.open) {
        dialog.close();
      }
    };

  }, [open]);

  return (
    <dialog
      ref={dialogRef}
      className="sk-modal"
      aria-labelledby={titleId}
      onCancel={(event) => {
        event.preventDefault();
        onClose();
      }}
    >

      <div className="sk-modal-header">

        <h2 id={titleId}>
          {title}
        </h2>

        <button
          type="button"
          className="sk-modal-close"
          onClick={onClose}
          aria-label="모달 닫기"
        >
          ×
        </button>

      </div>

      <div className="sk-modal-body">
        {children}
      </div>

    </dialog>
  );
}

// ============================================================
// 공통 알림 메시지
// ============================================================

export type ToastVariant =
  | "success"
  | "error"
  | "info";

interface ToastItem {
  id: number;
  message: string;
  variant: ToastVariant;
}

interface ToastContextValue {

  notify: (
    message: string,
    variant?: ToastVariant
  ) => void;

  dismiss: (id: number) => void;
}

const ToastContext = createContext<ToastContextValue | null>(
  null
);

export function ToastProvider({
  children
}: {
  children: ReactNode;
}) {

  const [toasts, setToasts] = useState<ToastItem[]>([]);

  const nextId = useRef(0);

  const timers = useRef(
    new Map<number, ReturnType<typeof setTimeout>>()
  );

  const dismiss = useCallback((id: number) => {

    const timer = timers.current.get(id);

    if (timer) {
      clearTimeout(timer);
      timers.current.delete(id);
    }

    setToasts((current) =>
      current.filter((item) => item.id !== id)
    );

  }, []);

  const notify = useCallback((
    message: string,
    variant: ToastVariant = "info"
  ) => {

    nextId.current += 1;

    const id = nextId.current;

    setToasts((current) => [
      ...current,
      {
        id,
        message,
        variant
      }
    ]);

    const timer = setTimeout(() => {

      dismiss(id);

    }, 4000);

    timers.current.set(id, timer);

  }, [dismiss]);

  // 컴포넌트 종료 시 타이머를 정리합니다.
  useEffect(() => {

    const activeTimers = timers.current;

    return () => {

      for (const timer of activeTimers.values()) {
        clearTimeout(timer);
      }

      activeTimers.clear();
    };

  }, []);

  return (
    <ToastContext.Provider
      value={{
        notify,
        dismiss
      }}
    >

      {children}

      <div
        className="sk-toast-region"
        aria-live="polite"
        aria-label="알림 메시지"
      >

        {toasts.map((toast) => (

          <div
            key={toast.id}
            className={`sk-toast sk-toast-${toast.variant}`}
            role={
              toast.variant === "error"
                ? "alert"
                : "status"
            }
          >

            <span>{toast.message}</span>

            <button
              type="button"
              onClick={() => dismiss(toast.id)}
              aria-label="알림 닫기"
            >
              ×
            </button>

          </div>

        ))}

      </div>

    </ToastContext.Provider>
  );
}

// ============================================================
// 알림 사용 Hook
// ============================================================

export function useToast(): ToastContextValue {

  const context = useContext(ToastContext);

  if (!context) {

    throw new Error(
      "ToastProvider 내부에서 useToast를 사용해야 합니다."
    );
  }

  return context;
}

// ============================================================
// 공통 페이지네이션
// ============================================================

export interface PaginationProps {

  page: number;

  pageSize: number;

  total: number;

  onPageChange: (page: number) => void;
}

export function Pagination({
  page,
  pageSize,
  total,
  onPageChange
}: PaginationProps) {

  const safePageSize = Math.max(1, pageSize);

  const totalPages = Math.max(
    1,
    Math.ceil(total / safePageSize)
  );

  const currentPage = Math.min(
    Math.max(1, page),
    totalPages
  );

  return (
    <nav
      className="sk-pagination"
      aria-label="페이지 이동"
    >

      <Button
        variant="secondary"
        disabled={currentPage <= 1}
        onClick={() => {
          onPageChange(currentPage - 1);
        }}
      >
        이전
      </Button>

      <span aria-live="polite">
        {currentPage} / {totalPages}
      </span>

      <Button
        variant="secondary"
        disabled={currentPage >= totalPages}
        onClick={() => {
          onPageChange(currentPage + 1);
        }}
      >
        다음
      </Button>

    </nav>
  );
}
'@


# ============================================================
# 4. 공통 UI 스타일
# ============================================================

Save-Part7File "apps/web/src/shared/ui/ui.css" "재사용 가능한 공통 UI 디자인과 반응형 스타일" @'
/* ============================================================
   공통 UI 기본 스타일
   기존 프로젝트의 전역 스타일을 변경하지 않습니다.
   ============================================================ */

.sk-button {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;

  min-height: 42px;
  padding: 10px 16px;

  border: 1px solid transparent;
  border-radius: 8px;

  font: inherit;
  font-size: 14px;
  font-weight: 600;

  cursor: pointer;

  transition:
    background-color 0.15s ease,
    border-color 0.15s ease;
}

.sk-button-primary {
  background: #2563eb;
  color: #ffffff;
}

.sk-button-primary:hover:not(:disabled) {
  background: #1d4ed8;
}

.sk-button-secondary {
  background: #ffffff;
  color: #1e293b;
  border-color: #cbd5e1;
}

.sk-button-secondary:hover:not(:disabled) {
  background: #f1f5f9;
}

.sk-button-danger {
  background: #dc2626;
  color: #ffffff;
}

.sk-button-danger:hover:not(:disabled) {
  background: #b91c1c;
}

.sk-button:disabled {
  opacity: 0.55;
  cursor: not-allowed;
}

.sk-button:focus-visible,
.sk-input:focus-visible,
.sk-modal-close:focus-visible {
  outline: 3px solid #93c5fd;
  outline-offset: 2px;
}

/* ============================================================
   입력창
   ============================================================ */

.sk-field {
  display: flex;
  flex-direction: column;
  gap: 7px;
  width: 100%;
}

.sk-label {
  font-size: 14px;
  font-weight: 600;
  color: #334155;
}

.sk-input {
  width: 100%;
  min-height: 44px;
  padding: 10px 12px;

  border: 1px solid #cbd5e1;
  border-radius: 8px;

  background: #ffffff;
  color: #0f172a;

  font: inherit;
  font-size: 14px;

  box-sizing: border-box;
}

.sk-input:focus {
  border-color: #2563eb;
}

.sk-input[aria-invalid="true"] {
  border-color: #dc2626;
}

.sk-field-error {
  margin: 0;
  font-size: 12px;
  color: #dc2626;
}

.sk-field-hint {
  margin: 0;
  font-size: 12px;
  color: #64748b;
}

/* ============================================================
   로딩
   ============================================================ */

.sk-loading {
  display: flex;
  align-items: center;
  gap: 10px;

  padding: 16px;

  color: #475569;
  font-size: 14px;
}

.sk-spinner {
  display: inline-block;

  width: 16px;
  height: 16px;

  border: 2px solid currentColor;
  border-right-color: transparent;
  border-radius: 50%;

  animation: sk-spin 0.7s linear infinite;
}

@keyframes sk-spin {
  to {
    transform: rotate(360deg);
  }
}

/* ============================================================
   빈 데이터
   ============================================================ */

.sk-empty {
  padding: 30px 20px;

  border: 1px dashed #cbd5e1;
  border-radius: 10px;

  text-align: center;
  color: #475569;
}

.sk-empty strong {
  display: block;
  font-size: 16px;
}

.sk-empty p {
  margin: 8px 0 0;
  font-size: 13px;
}

/* ============================================================
   모달
   ============================================================ */

.sk-modal {
  width: min(460px, calc(100vw - 32px));
  max-height: calc(100vh - 48px);

  padding: 0;

  border: 1px solid #e2e8f0;
  border-radius: 14px;

  background: #ffffff;
  color: #0f172a;

  box-shadow: 0 20px 60px rgba(15, 23, 42, 0.2);
}

.sk-modal::backdrop {
  background: rgba(15, 23, 42, 0.6);
}

.sk-modal-header {
  display: flex;
  align-items: center;
  justify-content: space-between;

  padding: 18px 20px;

  border-bottom: 1px solid #e2e8f0;
}

.sk-modal-header h2 {
  margin: 0;
  font-size: 18px;
}

.sk-modal-close {
  border: 0;
  background: transparent;

  color: #64748b;
  font-size: 25px;

  cursor: pointer;
}

.sk-modal-body {
  padding: 20px;
  line-height: 1.6;
}

/* ============================================================
   알림 메시지
   ============================================================ */

.sk-toast-region {
  position: fixed;
  z-index: 9999;

  right: 20px;
  bottom: 20px;

  display: flex;
  flex-direction: column;
  gap: 10px;

  width: min(360px, calc(100vw - 40px));
}

.sk-toast {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;

  padding: 14px 16px;

  border: 1px solid;
  border-radius: 10px;

  font-size: 14px;

  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.08);
}

.sk-toast-success {
  background: #f0fdf4;
  border-color: #86efac;
  color: #166534;
}

.sk-toast-error {
  background: #fef2f2;
  border-color: #fca5a5;
  color: #991b1b;
}

.sk-toast-info {
  background: #eff6ff;
  border-color: #93c5fd;
  color: #1e40af;
}

.sk-toast button {
  border: 0;
  background: transparent;

  color: inherit;
  font-size: 20px;

  cursor: pointer;
}

/* ============================================================
   페이지네이션
   ============================================================ */

.sk-pagination {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 16px;

  padding: 16px 0;
}

.sk-pagination span {
  min-width: 70px;

  text-align: center;
  font-size: 14px;
  font-weight: 600;
}

/* ============================================================
   공통 기능 확인 화면
   ============================================================ */

.sk-toolkit {
  max-width: 1000px;
  margin: 0 auto;
  padding: 32px 20px 80px;

  color: #0f172a;
}

.sk-toolkit h1 {
  margin: 0 0 10px;
  font-size: 28px;
}

.sk-toolkit-description {
  margin-bottom: 30px;
  color: #64748b;
}

.sk-card {
  margin-bottom: 20px;
  padding: 24px;

  border: 1px solid #e2e8f0;
  border-radius: 12px;

  background: #ffffff;
}

.sk-card h2 {
  margin: 0 0 16px;
  font-size: 19px;
}

.sk-card p {
  line-height: 1.6;
}

.sk-row {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 10px;
}

.sk-status {
  padding: 12px 14px;
  border-radius: 8px;

  background: #f1f5f9;

  font-size: 14px;
  line-height: 1.7;
}

.sk-demo-list {
  padding-left: 22px;
  line-height: 2;
}

@media (max-width: 600px) {

  .sk-toolkit {
    padding: 20px 14px 60px;
  }

  .sk-card {
    padding: 18px;
  }

  .sk-toolkit h1 {
    font-size: 23px;
  }
}

@media (prefers-reduced-motion: reduce) {

  .sk-spinner {
    animation-duration: 2s;
  }
}
'@


# ============================================================
# 5. 공통 기능 확인 페이지
# ============================================================

Save-Part7File "apps/web/src/app/starter/toolkit/page.tsx" "공통 API 통신과 UI 컴포넌트 확인 화면" @'
"use client";

import {
  useCallback,
  useEffect,
  useState
} from "react";

import {
  apiClient,
  ApiClientError
} from "../../../shared/api/client";

import {
  Button,
  TextField,
  Loading,
  EmptyState,
  Modal,
  ToastProvider,
  useToast,
  Pagination
} from "../../../shared/ui";

import "../../../shared/ui/ui.css";

// ============================================================
// 헬스체크 응답 타입
// ============================================================

interface HealthData {
  status: string;
}

interface ReadyData {
  status: string;
  database: string;
  redis: string;
}

// ============================================================
// 페이지네이션 예제 데이터
// ============================================================

const demoItems = Array.from(
  { length: 23 },
  (_, index) => ({
    id: index + 1,
    title: `공통 목록 예제 ${index + 1}`
  })
);

// ============================================================
// 공통 기능 화면
// ============================================================

function ToolkitContent() {

  const { notify } = useToast();

  const [name, setName] = useState("");

  const [modalOpen, setModalOpen] = useState(false);

  const [page, setPage] = useState(1);

  const [loading, setLoading] = useState(true);

  const [health, setHealth] = useState<HealthData | null>(
    null
  );

  const [ready, setReady] = useState<ReadyData | null>(
    null
  );

  const [error, setError] = useState("");

  // ==========================================================
  // API 서버 상태 조회
  // ==========================================================

  const loadHealth = useCallback(async (
    signal?: AbortSignal
  ) => {

    setLoading(true);
    setError("");

    try {

      const [healthResponse, readyResponse] =
        await Promise.all([

          apiClient.request<HealthData>({
            path: "/health",
            scope: "root",
            auth: "none",
            signal,
            timeoutMs: 8000
          }),

          apiClient.request<ReadyData>({
            path: "/health/ready",
            scope: "root",
            auth: "none",
            signal,
            timeoutMs: 8000
          })

        ]);

      if (signal?.aborted) {
        return;
      }

      setHealth(healthResponse.data);

      setReady(readyResponse.data);

    } catch (caught) {

      if (signal?.aborted) {
        return;
      }

      setHealth(null);
      setReady(null);

      if (caught instanceof ApiClientError) {

        setError(
          `${caught.message} (${caught.errorCode})`
        );

      } else {

        setError(
          "서버 상태를 확인하지 못했습니다."
        );
      }

    } finally {

      if (!signal?.aborted) {
        setLoading(false);
      }
    }

  }, []);

  // 페이지 최초 진입 시 서버 상태를 조회합니다.
  useEffect(() => {

    const controller = new AbortController();

    void loadHealth(controller.signal);

    return () => {
      controller.abort();
    };

  }, [loadHealth]);

  // ==========================================================
  // 페이지네이션
  // ==========================================================

  const pageSize = 5;

  const visibleItems = demoItems.slice(
    (page - 1) * pageSize,
    page * pageSize
  );

  // ==========================================================
  // 알림 예제
  // ==========================================================

  function showGreeting() {

    const trimmedName = name.trim();

    if (!trimmedName) {

      notify(
        "이름을 입력해 주세요.",
        "error"
      );

      return;
    }

    notify(
      `${trimmedName}님, 공통 알림 기능이 정상적으로 동작합니다.`,
      "success"
    );
  }

  // ==========================================================
  // 화면
  // ==========================================================

  return (
    <main className="sk-toolkit">

      <h1>
        풀스택 공통 기능 관리
      </h1>

      <p className="sk-toolkit-description">
        7부에서 추가한 공통 API 및 UI 기능을 확인하는 화면입니다.
        기존 회원 정보나 게시글 데이터는 변경하지 않습니다.
      </p>

      {/* =====================================================
          API 서버 상태
          ===================================================== */}

      <section className="sk-card">

        <h2>API 서버 연결 상태</h2>

        {loading ? (

          <Loading message="서버 상태를 확인하고 있습니다." />

        ) : error ? (

          <div
            className="sk-status"
            role="alert"
          >
            {error}
          </div>

        ) : (

          <div className="sk-status">

            <div>
              API 서버: {health?.status ?? "확인 불가"}
            </div>

            <div>
              데이터베이스: {ready?.database ?? "확인 불가"}
            </div>

            <div>
              Redis: {ready?.redis ?? "확인 불가"}
            </div>

          </div>

        )}

        <div
          className="sk-row"
          style={{ marginTop: 16 }}
        >

          <Button
            loading={loading}
            onClick={() => {
              void loadHealth();
            }}
          >
            서버 상태 새로고침
          </Button>

        </div>

      </section>

      {/* =====================================================
          버튼
          ===================================================== */}

      <section className="sk-card">

        <h2>공통 버튼</h2>

        <div className="sk-row">

          <Button
            onClick={() => {
              notify(
                "기본 버튼을 눌렀습니다.",
                "success"
              );
            }}
          >
            기본 버튼
          </Button>

          <Button
            variant="secondary"
            onClick={() => {
              notify(
                "보조 버튼을 눌렀습니다.",
                "info"
              );
            }}
          >
            보조 버튼
          </Button>

          <Button
            variant="danger"
            onClick={() => {
              notify(
                "위험 작업 버튼 예제입니다.",
                "error"
              );
            }}
          >
            위험 버튼
          </Button>

          <Button disabled>
            비활성 버튼
          </Button>

        </div>

      </section>

      {/* =====================================================
          입력창
          ===================================================== */}

      <section className="sk-card">

        <h2>공통 입력창 및 알림</h2>

        <div style={{ maxWidth: 420 }}>

          <TextField
            label="이름"
            placeholder="이름을 입력해 주세요."
            value={name}
            maxLength={60}
            onChange={(event) => {
              setName(event.target.value);
            }}
            hint="입력한 값은 서버에 저장되지 않습니다."
          />

          <div style={{ marginTop: 16 }}>

            <Button onClick={showGreeting}>
              알림 표시
            </Button>

          </div>

        </div>

      </section>

      {/* =====================================================
          모달
          ===================================================== */}

      <section className="sk-card">

        <h2>공통 모달</h2>

        <Button
          onClick={() => {
            setModalOpen(true);
          }}
        >
          모달 열기
        </Button>

        <Modal
          open={modalOpen}
          title="공통 모달"
          onClose={() => {
            setModalOpen(false);
          }}
        >

          <p>
            이 모달은 다른 프로젝트에서도 재사용할 수 있습니다.
          </p>

          <p>
            ESC 키 또는 닫기 버튼으로 종료할 수 있습니다.
          </p>

          <Button
            onClick={() => {
              setModalOpen(false);
            }}
          >
            확인
          </Button>

        </Modal>

      </section>

      {/* =====================================================
          페이지네이션
          ===================================================== */}

      <section className="sk-card">

        <h2>공통 페이지네이션</h2>

        <ul className="sk-demo-list">

          {visibleItems.map((item) => (

            <li key={item.id}>
              {item.title}
            </li>

          ))}

        </ul>

        <Pagination
          page={page}
          pageSize={pageSize}
          total={demoItems.length}
          onPageChange={setPage}
        />

      </section>

      {/* =====================================================
          빈 데이터
          ===================================================== */}

      <section className="sk-card">

        <h2>빈 데이터 안내</h2>

        <EmptyState
          title="등록된 데이터가 없습니다."
          description="데이터가 없을 때 공통으로 표시하는 화면입니다."
        />

      </section>

    </main>
  );
}

// ============================================================
// 알림 Provider 연결
// ============================================================

export default function ToolkitPage() {

  return (
    <ToastProvider>
      <ToolkitContent />
    </ToastProvider>
  );
}
'@


# ============================================================
# 6. 공통 API 사용 설명서
# ============================================================

Save-Part7File "apps/web/src/shared/api/README.md" "공통 API와 인증 및 모바일 연동 사용 방법" @'
# 공통 API 사용 설명서

## 1. 개요

이 모듈은 웹 프론트엔드에서 백엔드 REST API를 호출하기 위한 공통 기능입니다.

기존 백엔드 API를 수정하지 않고 사용할 수 있도록 구성했습니다.

## 2. 공통 API 클라이언트

파일: client.ts

지원 기능:

- HTTP GET
- HTTP POST
- HTTP PUT
- HTTP PATCH
- HTTP DELETE
- JWT Access Token 전달
- 웹 Refresh Token 갱신
- 동시 토큰 갱신 요청 중복 방지
- 요청 타임아웃
- 요청 취소
- 공통 오류 처리
- 쿼리 문자열 생성

## 3. 인증 방식

웹에서는 Access Token을 JavaScript 메모리에 보관합니다.

Refresh Token은 기존 백엔드에서 발급한 HttpOnly Cookie를 사용합니다.

Access Token을 localStorage에 저장하지 않습니다.

새로고침 후 인증이 필요한 API에서 401 응답을 받으면
Refresh Token 갱신을 시도합니다.

다만 이 방식만으로 전체 로그인 상태 관리가 완성되는 것은 아닙니다.

실제 화면에서는 사용자 정보 상태, 인증 확인 중 화면,
로그아웃 후 이동 처리 등을 별도로 연결해야 합니다.

## 4. 기존 인증 코드와 연결

새로운 web-auth.ts는 기존 인증 API를 사용하는 독립적인 서비스입니다.

기존 로그인 화면을 자동으로 교체하지 않습니다.

기존 로그인 화면에서 받은 Access Token을
tokenMemory.set()으로 전달하면 공통 API에서 사용할 수 있습니다.

로그아웃할 때는 tokenMemory.clear()를 호출합니다.

기존 인증 Context와 새 공통 인증 모듈을 함께 사용할 경우
토큰 상태가 중복되지 않도록 한쪽을 기준으로 통합해야 합니다.

## 5. API 요청 경로

일반 API 요청은 /api/v1을 기준으로 합니다.

예를 들어 path에 /notes를 전달하면
/api/v1/notes로 요청합니다.

헬스체크처럼 루트 API를 호출할 때는
scope를 root로 지정합니다.

## 6. 모바일 앱 연동

모바일 앱은 같은 백엔드 API를 사용할 수 있습니다.

다만 모바일 앱에서는 웹의 HttpOnly Cookie 방식 대신
모바일 전용 Refresh Token API를 사용합니다.

모바일 앱에서는 Refresh Token을
Expo SecureStore 또는 운영체제 보안 저장소에 보관해야 합니다.

createApiClient()의 다음 옵션을 사용하여 연결할 수 있습니다.

- getAccessToken
- refreshAccessToken
- onAccessToken
- onUnauthorized
- credentials

모바일 앱에서는 credentials를 omit으로 설정하는 등
웹과 다른 인증 전송 방식을 구성할 수 있습니다.

모바일 앱의 로그인과 토큰 저장 기능 자체는
향후 모바일 프로젝트에서 별도로 구현해야 합니다.

## 7. 보안 주의사항

Access Token을 URL에 포함하지 마세요.

Refresh Token을 브라우저 localStorage에 저장하지 마세요.

운영 환경에서는 HTTPS를 사용하세요.

사용자에게 보여줄 수 있는 오류 메시지와
내부 서버 오류 정보를 구분하세요.

자동 토큰 갱신은 인증을 대체하지 않습니다.

백엔드에서 모든 요청의 인증과 권한을 다시 검사해야 합니다.

## 8. API 서버 주소

환경 변수 NEXT_PUBLIC_API_BASE_URL 또는
NEXT_PUBLIC_API_URL을 사용할 수 있습니다.

값은 API 서버의 주소로 설정합니다.

예시:

NEXT_PUBLIC_API_BASE_URL=http://localhost:4000

환경 변수를 설정하지 않으면 로컬 개발 주소를 사용합니다.

운영 환경에서는 반드시 실제 API 서버 주소를 설정하세요.
'@


# ============================================================
# 7. 생성 결과 출력
# ============================================================

Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host " 7부 공통 시스템 생성 작업 완료"
Write-Host "============================================" -ForegroundColor Green

Write-Host ""
Write-Host "생성한 파일: $script:CreatedCount" -ForegroundColor Green
Write-Host "기존 파일 보호: $script:SkippedCount" -ForegroundColor Yellow

Write-Host ""
Write-Host "기존 백엔드 변경 없음"
Write-Host "기존 데이터베이스 변경 없음"
Write-Host "기존 인증 코드 변경 없음"
Write-Host "기존 프론트엔드 화면 변경 없음"

Write-Host ""
Write-Host "공통 기능 확인 주소:"
Write-Host "http://localhost:3000/starter/toolkit"

Write-Host ""
Write-Host "다음 단계: Next.js 빌드 및 실행"
Write-Host ""

