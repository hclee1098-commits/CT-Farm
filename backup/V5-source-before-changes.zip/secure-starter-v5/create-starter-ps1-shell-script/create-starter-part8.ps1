﻿# filepath: create-starter-part8.ps1
# 8부 프론트엔드 공통 기능 및 보안 강화
#
# 기존 프로젝트 보호
# 기존 파일 덮어쓰기 금지
# 데이터베이스 변경 없음
# 새로운 소스 파일은 UTF-8 BOM 없이 저장

$ErrorActionPreference = "Stop"

# ============================================================
# 1. 프로젝트 경로
# ============================================================

$Root = Join-Path $PSScriptRoot "secure-starter"

# 보안 검토가 끝난 프로젝트에 예전 생성 코드를 덮어쓰지 않습니다.
if (Test-Path -LiteralPath (Join-Path $Root "SECURITY-REVISION.json")) {
    throw "보안 수정이 적용된 V5입니다. 이전 부별 생성 스크립트 적용을 차단합니다."
}


if (-not (Test-Path $Root)) {
    throw "secure-starter 프로젝트가 없습니다."
}

$WebRoot = Join-Path $Root "apps\web"

if (-not (Test-Path $WebRoot)) {
    throw "Next.js 프론트엔드 프로젝트가 없습니다."
}

# ============================================================
# 2. UTF-8 BOM 없는 인코딩
# ============================================================

$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)

# ============================================================
# 3. 파일 생성 함수
# ============================================================

function Save-Source {

    param(
        [string]$RelativePath,
        [string]$Description,
        [string]$Content
    )

    $FullPath = Join-Path $Root $RelativePath

    if (Test-Path $FullPath) {
        throw "기존 파일을 보호하기 위해 중단합니다: $RelativePath"
    }

    $Directory = Split-Path $FullPath -Parent

    if (-not (Test-Path $Directory)) {
        New-Item `
            -ItemType Directory `
            -Path $Directory `
            -Force | Out-Null
    }

    $Header = "// filepath: $RelativePath - $Description`n"

    [System.IO.File]::WriteAllText(
        $FullPath,
        $Header + $Content,
        $Utf8NoBom
    )

    Write-Host "[생성 완료] $RelativePath" -ForegroundColor Green
}

# ============================================================
# 4. 기존 파일 충돌 사전 검사
# ============================================================

$PlannedFiles = @(
    "apps/web/src/shared/api/resilient-request.ts"
    "apps/web/src/shared/ui/toast.tsx"
    "apps/web/src/shared/ui/confirm-dialog.tsx"
    "apps/web/src/shared/ui/async-state.tsx"
    "apps/web/src/shared/ui/error-boundary.tsx"
    "apps/web/src/shared/security/file-preflight.ts"
    "apps/web/src/app/starter/toolkit/part8/page.tsx"
)

foreach ($RelativePath in $PlannedFiles) {

    $FullPath = Join-Path $Root $RelativePath

    if (Test-Path $FullPath) {
        throw "기존 파일이 존재합니다. 아무 파일도 덮어쓰지 않습니다: $RelativePath"
    }
}

# 기존 API 클라이언트 존재 여부 확인
$ExistingClient = Join-Path $Root "apps/web/src/shared/api/client.ts"

if (-not (Test-Path $ExistingClient)) {
    throw "기존 API 클라이언트가 없습니다."
}

$ClientContent = [System.IO.File]::ReadAllText($ExistingClient)

if ($ClientContent -notmatch 'export\s+const\s+API_BASE_URL\b') {
    throw "기존 API_BASE_URL 내보내기를 확인할 수 없습니다."
}

Write-Host ""
Write-Host "============================================"
Write-Host " 8부 프론트엔드 공통 기능 생성 시작"
Write-Host "============================================"
Write-Host ""

# ============================================================
# 5. API 통신 안정성 강화
# ============================================================

Save-Source "apps/web/src/shared/api/resilient-request.ts" "요청 타임아웃과 안전한 API 오류 처리" @'
import {
  API_BASE_URL
} from "./client";

// ============================================================
// 공통 API 오류
// ============================================================

export class RequestError extends Error {

  constructor(
    public readonly status: number,
    public readonly code: string,
    message: string
  ) {
    super(message);

    this.name = "RequestError";
  }
}

// ============================================================
// API 요청 옵션
// ============================================================

export interface RequestOptions {

  method?: "GET" | "POST" | "PUT" | "PATCH" | "DELETE";

  body?: unknown;

  accessToken?: string;

  timeoutMs?: number;

  signal?: AbortSignal;

  headers?: HeadersInit;
}

// ============================================================
// 오류 응답 타입
// ============================================================

interface ErrorResponse {
  success?: boolean;
  errorCode?: string;
  message?: string;
}

// ============================================================
// 안전한 오류 메시지
// ============================================================

function getSafeErrorMessage(
  status: number,
  response: ErrorResponse | null
): string {

  if (status >= 500) {
    return "서버에서 문제가 발생했습니다. 잠시 후 다시 시도해 주세요.";
  }

  if (status === 401) {
    return "로그인이 필요하거나 인증이 만료되었습니다.";
  }

  if (status === 403) {
    return "이 작업을 수행할 권한이 없습니다.";
  }

  if (status === 404) {
    return "요청한 정보를 찾을 수 없습니다.";
  }

  if (status === 429) {
    return "요청이 너무 많습니다. 잠시 후 다시 시도해 주세요.";
  }

  if (
    typeof response?.message === "string" &&
    response.message.length > 0 &&
    response.message.length <= 300
  ) {
    return response.message;
  }

  return "요청을 처리하지 못했습니다.";
}

// ============================================================
// API 공통 요청
// ============================================================

// 기존 인증 클라이언트를 변경하지 않는 독립 요청 함수입니다.
// Access Token은 호출자가 메모리에서 전달해야 합니다.
// localStorage나 sessionStorage에 토큰을 저장하지 않습니다.

export async function resilientRequest<T>(
  path: string,
  options: RequestOptions = {}
): Promise<T> {

  // 외부 주소로 인증 헤더가 전송되는 실수를 방지합니다.
  if (
    !path.startsWith("/") ||
    path.startsWith("//") ||
    path.includes("\\")
  ) {
    throw new RequestError(
      400,
      "INVALID_API_PATH",
      "API 경로가 올바르지 않습니다."
    );
  }

  const base = new URL(API_BASE_URL + "/");

  const url = new URL(path.slice(1), base);

  // API 기본 경로 밖으로 이동하는 요청을 차단합니다.
  if (
    url.origin !== base.origin ||
    !url.pathname.startsWith(base.pathname)
  ) {
    throw new RequestError(
      400,
      "INVALID_API_PATH",
      "허용되지 않은 API 경로입니다."
    );
  }

  const controller = new AbortController();

  const timeoutMs = options.timeoutMs ?? 15000;

  if (
    !Number.isFinite(timeoutMs) ||
    timeoutMs < 1 ||
    timeoutMs > 120000
  ) {
    throw new RequestError(
      400,
      "INVALID_TIMEOUT",
      "요청 제한 시간이 올바르지 않습니다."
    );
  }

  let timedOut = false;

  const timeout = setTimeout(() => {
    timedOut = true;
    controller.abort();
  }, timeoutMs);

  const abortFromCaller = () => {
    controller.abort();
  };

  if (options.signal?.aborted) {
    controller.abort();
  }

  options.signal?.addEventListener(
    "abort",
    abortFromCaller,
    { once: true }
  );

  try {

    const headers = new Headers(options.headers);

    headers.set("Accept", "application/json");

    if (options.accessToken) {
      headers.set(
        "Authorization",
        `Bearer ${options.accessToken}`
      );
    }

    let body: string | undefined;

    if (options.body !== undefined) {

      headers.set(
        "Content-Type",
        "application/json"
      );

      body = JSON.stringify(options.body);
    }

    const response = await fetch(
      url.toString(),
      {
        method: options.method ?? "GET",
        headers,
        body,
        credentials: "include",
        signal: controller.signal,
        cache: "no-store"
      }
    );

    let result: unknown = null;

    const contentType =
      response.headers.get("content-type") ?? "";

    if (contentType.includes("application/json")) {

      try {
        result = await response.json();
      }
      catch {
        throw new RequestError(
          response.status,
          "INVALID_RESPONSE",
          "서버 응답을 처리할 수 없습니다."
        );
      }
    }

    if (!response.ok) {

      const errorResponse =
        result !== null &&
        typeof result === "object"
          ? result as ErrorResponse
          : null;

      throw new RequestError(
        response.status,
        errorResponse?.errorCode ?? "API_ERROR",
        getSafeErrorMessage(
          response.status,
          errorResponse
        )
      );
    }

    if (
      result === null ||
      typeof result !== "object" ||
      !("success" in result) ||
      result.success !== true ||
      !("data" in result)
    ) {
      throw new RequestError(
        response.status,
        "INVALID_RESPONSE",
        "서버 응답 형식이 올바르지 않습니다."
      );
    }

    return result.data as T;

  }
  catch (error) {

    if (error instanceof RequestError) {
      throw error;
    }

    if (timedOut) {
      throw new RequestError(
        0,
        "REQUEST_TIMEOUT",
        "서버 응답 시간이 초과되었습니다."
      );
    }

    if (controller.signal.aborted) {
      throw new RequestError(
        0,
        "REQUEST_CANCELLED",
        "요청이 취소되었습니다."
      );
    }

    throw new RequestError(
      0,
      "NETWORK_ERROR",
      "네트워크 연결을 확인해 주세요."
    );

  }
  finally {

    clearTimeout(timeout);

    options.signal?.removeEventListener(
      "abort",
      abortFromCaller
    );
  }
}
'@

# ============================================================
# 6. 공통 알림 시스템
# ============================================================

Save-Source "apps/web/src/shared/ui/toast.tsx" "성공 오류 안내 메시지를 표시하는 공통 알림 시스템" @'
"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState
} from "react";

import type {
  ReactNode
} from "react";

// ============================================================
// 알림 타입
// ============================================================

export type ToastType =
  | "success"
  | "error"
  | "info";

interface ToastItem {
  id: number;
  type: ToastType;
  message: string;
}

type Notify = (
  message: string,
  type?: ToastType
) => void;

const ToastContext = createContext<Notify | null>(null);

// ============================================================
// 알림 제공자
// ============================================================

export function ToastProvider({
  children
}: {
  children: ReactNode;
}) {

  const [items, setItems] = useState<ToastItem[]>([]);

  const nextId = useRef(0);

  const timers = useRef<
    ReturnType<typeof setTimeout>[]
  >([]);

  useEffect(() => {

    return () => {

      for (const timer of timers.current) {
        clearTimeout(timer);
      }

    };

  }, []);

  const notify = useCallback<Notify>(
    (message, type = "info") => {

      const id = ++nextId.current;

      setItems((current) => [
        ...current.slice(-3),
        {
          id,
          type,
          message
        }
      ]);

      const timer = setTimeout(() => {

        setItems((current) =>
          current.filter((item) => item.id !== id)
        );

      }, 4000);

      timers.current.push(timer);
    },
    []
  );

  return (
    <ToastContext.Provider value={notify}>

      {children}

      <div
        aria-live="polite"
        aria-atomic="false"
        style={{
          position: "fixed",
          top: 20,
          right: 20,
          zIndex: 9999,
          display: "grid",
          gap: 10,
          width: "min(360px, calc(100vw - 40px))"
        }}
      >

        {items.map((item) => {

          const color =
            item.type === "success"
              ? "#166534"
              : item.type === "error"
                ? "#991b1b"
                : "#1e40af";

          return (
            <div
              key={item.id}
              role={
                item.type === "error"
                  ? "alert"
                  : "status"
              }
              style={{
                padding: "14px 18px",
                borderRadius: 10,
                color: "#ffffff",
                backgroundColor: color,
                boxShadow: "0 8px 24px #0002",
                overflowWrap: "anywhere"
              }}
            >
              {item.message}
            </div>
          );

        })}

      </div>

    </ToastContext.Provider>
  );
}

// ============================================================
// 알림 호출 Hook
// ============================================================

export function useToast(): Notify {

  const context = useContext(ToastContext);

  if (!context) {
    throw new Error(
      "ToastProvider 내부에서 useToast를 사용해야 합니다."
    );
  }

  return context;
}
'@

# ============================================================
# 7. 공통 확인창
# ============================================================

Save-Source "apps/web/src/shared/ui/confirm-dialog.tsx" "중요한 작업 전 사용자 확인을 받는 공통 대화상자" @'
"use client";

import {
  useEffect,
  useRef
} from "react";

// ============================================================
// 확인창 속성
// ============================================================

interface ConfirmDialogProps {

  open: boolean;

  title: string;

  description: string;

  confirmText?: string;

  cancelText?: string;

  danger?: boolean;

  onConfirm: () => void;

  onCancel: () => void;
}

// ============================================================
// 공통 확인창
// ============================================================

export function ConfirmDialog({
  open,
  title,
  description,
  confirmText = "확인",
  cancelText = "취소",
  danger = false,
  onConfirm,
  onCancel
}: ConfirmDialogProps) {

  const dialogRef = useRef<HTMLDialogElement>(null);

  useEffect(() => {

    const dialog = dialogRef.current;

    if (!dialog) {
      return;
    }

    if (open && !dialog.open) {
      dialog.showModal();
    }

    if (!open && dialog.open) {
      dialog.close();
    }

  }, [open]);

  return (
    <dialog
      ref={dialogRef}
      aria-labelledby="confirm-dialog-title"
      aria-describedby="confirm-dialog-description"
      onCancel={(event) => {
        event.preventDefault();
        onCancel();
      }}
      style={{
        border: "1px solid #e5e7eb",
        borderRadius: 14,
        padding: 24,
        width: "min(420px, calc(100vw - 40px))",
        maxWidth: "100%",
        color: "#111827",
        background: "#ffffff",
        boxShadow: "0 20px 60px #0003"
      }}
    >

      <h2
        id="confirm-dialog-title"
        style={{
          marginTop: 0,
          fontSize: 20
        }}
      >
        {title}
      </h2>

      <p
        id="confirm-dialog-description"
        style={{
          lineHeight: 1.6,
          color: "#4b5563"
        }}
      >
        {description}
      </p>

      <div
        style={{
          display: "flex",
          justifyContent: "flex-end",
          gap: 10,
          marginTop: 24
        }}
      >

        <button
          type="button"
          onClick={onCancel}
          style={{
            padding: "10px 16px",
            border: "1px solid #d1d5db",
            borderRadius: 8,
            background: "#ffffff",
            color: "#111827",
            cursor: "pointer"
          }}
        >
          {cancelText}
        </button>

        <button
          type="button"
          onClick={onConfirm}
          style={{
            padding: "10px 16px",
            border: 0,
            borderRadius: 8,
            background: danger
              ? "#dc2626"
              : "#2563eb",
            color: "#ffffff",
            cursor: "pointer"
          }}
        >
          {confirmText}
        </button>

      </div>

    </dialog>
  );
}
'@

# ============================================================
# 8. 로딩 / 빈 데이터 / 오류 UI
# ============================================================

Save-Source "apps/web/src/shared/ui/async-state.tsx" "비동기 화면의 로딩 오류 빈 데이터 상태 표시" @'
"use client";

// ============================================================
// 공통 로딩 표시
// ============================================================

export function LoadingState({
  message = "데이터를 불러오는 중입니다."
}: {
  message?: string;
}) {

  return (
    <div
      role="status"
      aria-live="polite"
      style={{
        padding: 30,
        textAlign: "center",
        color: "#4b5563"
      }}
    >
      <span aria-hidden="true">⏳ </span>
      {message}
    </div>
  );
}

// ============================================================
// 빈 데이터 표시
// ============================================================

export function EmptyState({
  message = "표시할 데이터가 없습니다."
}: {
  message?: string;
}) {

  return (
    <div
      style={{
        padding: 30,
        textAlign: "center",
        color: "#6b7280",
        border: "1px dashed #d1d5db",
        borderRadius: 12
      }}
    >
      {message}
    </div>
  );
}

// ============================================================
// 오류 표시
// ============================================================

export function ErrorState({
  message = "문제가 발생했습니다.",
  onRetry
}: {
  message?: string;
  onRetry?: () => void;
}) {

  return (
    <div
      role="alert"
      style={{
        padding: 24,
        border: "1px solid #fecaca",
        borderRadius: 12,
        background: "#fef2f2",
        color: "#991b1b"
      }}
    >

      <p>{message}</p>

      {onRetry && (
        <button
          type="button"
          onClick={onRetry}
          style={{
            padding: "8px 14px",
            borderRadius: 8,
            border: "1px solid #fca5a5",
            background: "#ffffff",
            color: "#991b1b",
            cursor: "pointer"
          }}
        >
          다시 시도
        </button>
      )}

    </div>
  );
}
'@

# ============================================================
# 9. React 오류 격리
# ============================================================

Save-Source "apps/web/src/shared/ui/error-boundary.tsx" "화면 오류가 발생해도 전체 애플리케이션이 중단되지 않도록 격리" @'
"use client";

import {
  Component
} from "react";

import type {
  ReactNode
} from "react";

// ============================================================
// 속성 및 상태
// ============================================================

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
}

// ============================================================
// 오류 격리 컴포넌트
// ============================================================

export class ErrorBoundary extends Component<
  Props,
  State
> {

  constructor(props: Props) {
    super(props);

    this.state = {
      hasError: false
    };
  }

  static getDerivedStateFromError(): State {

    return {
      hasError: true
    };
  }

  reset = () => {

    this.setState({
      hasError: false
    });
  };

  render() {

    if (this.state.hasError) {

      return (
        <div
          role="alert"
          style={{
            padding: 24,
            borderRadius: 12,
            background: "#fef2f2",
            border: "1px solid #fecaca",
            color: "#991b1b"
          }}
        >

          <h2>화면을 표시하지 못했습니다.</h2>

          <p>
            일시적인 문제가 발생했습니다.
          </p>

          <button
            type="button"
            onClick={this.reset}
          >
            다시 시도
          </button>

        </div>
      );
    }

    return this.props.children;
  }
}
'@

# ============================================================
# 10. 파일 사전 검증
# ============================================================

Save-Source "apps/web/src/shared/security/file-preflight.ts" "업로드 전 파일 크기 확장자 MIME 타입을 검사" @'
// ============================================================
// 파일 업로드 사전 검증
// ============================================================

// 이 검사는 사용자 편의를 위한 클라이언트 검증입니다.
// 서버 측 파일 내용 검사와 접근 권한 검사를 대체하지 않습니다.

// ============================================================
// 허용 파일
// ============================================================

const allowedTypes: Record<string, string[]> = {

  png: [
    "image/png"
  ],

  jpg: [
    "image/jpeg"
  ],

  jpeg: [
    "image/jpeg"
  ],

  webp: [
    "image/webp"
  ],

  pdf: [
    "application/pdf"
  ]
};

// ============================================================
// 최대 파일 크기
// ============================================================

export const MAX_UPLOAD_SIZE = 5 * 1024 * 1024;

// ============================================================
// 검증 결과
// ============================================================

export interface FileValidationResult {

  valid: boolean;

  message: string;
}

// ============================================================
// 파일 검증
// ============================================================

export function validateUploadFile(
  file: File | null | undefined
): FileValidationResult {

  if (!file) {
    return {
      valid: false,
      message: "파일을 선택해 주세요."
    };
  }

  if (file.size === 0) {
    return {
      valid: false,
      message: "빈 파일은 업로드할 수 없습니다."
    };
  }

  if (file.size > MAX_UPLOAD_SIZE) {
    return {
      valid: false,
      message: "파일 크기는 최대 5MB까지 허용됩니다."
    };
  }

  const extension = file.name
    .split(".")
    .pop()
    ?.toLowerCase();

  if (
    !extension ||
    !Object.prototype.hasOwnProperty.call(
      allowedTypes,
      extension
    )
  ) {
    return {
      valid: false,
      message: "허용되지 않은 파일 확장자입니다."
    };
  }

  const expectedTypes = allowedTypes[extension];

  if (
    !expectedTypes ||
    !expectedTypes.includes(file.type)
  ) {
    return {
      valid: false,
      message: "파일 형식이 확장자와 일치하지 않습니다."
    };
  }

  return {
    valid: true,
    message: "파일 사전 검증을 통과했습니다."
  };
}
'@

# ============================================================
# 11. 공통 기능 확인 화면
# ============================================================

Save-Source "apps/web/src/app/starter/toolkit/part8/page.tsx" "8부 공통 알림 확인창 파일 검증 및 상태 UI 확인 화면" @'
"use client";

import {
  useState
} from "react";

import {
  ToastProvider,
  useToast
} from "../../../../shared/ui/toast";

import {
  ConfirmDialog
} from "../../../../shared/ui/confirm-dialog";

import {
  LoadingState,
  EmptyState,
  ErrorState
} from "../../../../shared/ui/async-state";

import {
  ErrorBoundary
} from "../../../../shared/ui/error-boundary";

import {
  validateUploadFile
} from "../../../../shared/security/file-preflight";

// ============================================================
// 공통 기능 화면
// ============================================================

function ToolkitContent() {

  const toast = useToast();

  const [confirmOpen, setConfirmOpen] = useState(false);

  const [showLoading, setShowLoading] = useState(false);

  const [showError, setShowError] = useState(false);

  return (
    <main
      style={{
        maxWidth: 900,
        margin: "0 auto",
        padding: "40px 20px",
        fontFamily: "Arial, sans-serif"
      }}
    >

      <h1>8부 프론트엔드 공통 기능</h1>

      <p style={{ color: "#6b7280" }}>
        공통 UI와 파일 사전 검증 기능을 확인하는 화면입니다.
      </p>

      <section style={sectionStyle}>

        <h2>1. 공통 알림 시스템</h2>

        <div style={rowStyle}>

          <button
            style={buttonStyle}
            onClick={() =>
              toast("작업이 완료되었습니다.", "success")
            }
          >
            성공 알림
          </button>

          <button
            style={buttonStyle}
            onClick={() =>
              toast("작업 중 오류가 발생했습니다.", "error")
            }
          >
            오류 알림
          </button>

          <button
            style={buttonStyle}
            onClick={() =>
              toast("안내 메시지입니다.", "info")
            }
          >
            안내 알림
          </button>

        </div>

      </section>

      <section style={sectionStyle}>

        <h2>2. 공통 확인창</h2>

        <button
          style={buttonStyle}
          onClick={() => setConfirmOpen(true)}
        >
          확인창 열기
        </button>

        <ConfirmDialog
          open={confirmOpen}
          title="작업 확인"
          description="정말 이 작업을 진행하시겠습니까?"
          confirmText="진행"
          cancelText="취소"
          danger
          onConfirm={() => {

            setConfirmOpen(false);

            toast(
              "확인 버튼을 눌렀습니다.",
              "success"
            );

          }}
          onCancel={() => setConfirmOpen(false)}
        />

      </section>

      <section style={sectionStyle}>

        <h2>3. 로딩 상태</h2>

        <button
          style={buttonStyle}
          onClick={() =>
            setShowLoading((value) => !value)
          }
        >
          로딩 표시 전환
        </button>

        {showLoading && <LoadingState />}

      </section>

      <section style={sectionStyle}>

        <h2>4. 빈 데이터 상태</h2>

        <EmptyState message="등록된 게시글이 없습니다." />

      </section>

      <section style={sectionStyle}>

        <h2>5. 오류 상태</h2>

        <button
          style={buttonStyle}
          onClick={() => setShowError(true)}
        >
          오류 화면 표시
        </button>

        {showError && (
          <ErrorState
            message="데이터를 불러오지 못했습니다."
            onRetry={() => {

              setShowError(false);

              toast(
                "다시 시도했습니다.",
                "info"
              );

            }}
          />
        )}

      </section>

      <section style={sectionStyle}>

        <h2>6. 파일 업로드 사전 검증</h2>

        <p style={{ color: "#6b7280" }}>
          PNG, JPG, WEBP, PDF 파일을 최대 5MB까지
          사전 검증합니다.
        </p>

        <input
          type="file"
          accept=".png,.jpg,.jpeg,.webp,.pdf"
          onChange={(event) => {

            const file =
              event.currentTarget.files?.[0];

            const result = validateUploadFile(file);

            toast(
              result.message,
              result.valid ? "success" : "error"
            );

            event.currentTarget.value = "";
          }}
        />

      </section>

      <section style={sectionStyle}>

        <h2>7. 화면 오류 격리</h2>

        <p>
          Error Boundary가 하위 컴포넌트의 렌더링 오류를
          격리할 수 있도록 구성되어 있습니다.
        </p>

        <ErrorBoundary>
          <p>정상적으로 렌더링된 컴포넌트입니다.</p>
        </ErrorBoundary>

      </section>

      <section style={sectionStyle}>

        <h2>8. API 통신 공통 기능</h2>

        <p>
          요청 타임아웃, 취소 처리, 오류 응답 표준화,
          인증 헤더 전달 기능이 추가되었습니다.
        </p>

        <p style={{ color: "#6b7280" }}>
          기존 인증 클라이언트와의 통합은 별도로 진행합니다.
        </p>

      </section>

    </main>
  );
}

// ============================================================
// 공통 스타일
// ============================================================

const sectionStyle = {
  padding: 24,
  marginTop: 20,
  border: "1px solid #e5e7eb",
  borderRadius: 12,
  backgroundColor: "#ffffff",
  color: "#111827"
};

const rowStyle = {
  display: "flex",
  flexWrap: "wrap" as const,
  gap: 10
};

const buttonStyle = {
  padding: "10px 16px",
  backgroundColor: "#2563eb",
  color: "#ffffff",
  border: "none",
  borderRadius: 8,
  cursor: "pointer"
};

// ============================================================
// 페이지
// ============================================================

export default function Part8Page() {

  return (
    <ToastProvider>
      <ToolkitContent />
    </ToastProvider>
  );
}
'@

# ============================================================
# 12. 생성 완료
# ============================================================

Write-Host ""
Write-Host "============================================"
Write-Host " 8부 프론트엔드 공통 기능 생성 완료"
Write-Host "============================================"
Write-Host ""

Write-Host "생성 파일: $($PlannedFiles.Count)개" -ForegroundColor Green
Write-Host "기존 파일 변경: 없음" -ForegroundColor Green
Write-Host "데이터베이스 변경: 없음" -ForegroundColor Green
Write-Host "파일 인코딩: UTF-8 BOM 없음" -ForegroundColor Green

Write-Host ""
Write-Host "다음 단계:"
Write-Host "1. 프론트엔드 빌드"
Write-Host "2. 프론트엔드 서버 실행"
Write-Host "3. /starter/toolkit/part8 화면 접속"
Write-Host ""

