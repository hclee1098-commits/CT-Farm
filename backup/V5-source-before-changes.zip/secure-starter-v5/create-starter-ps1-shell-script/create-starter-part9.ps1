﻿# filepath: create-starter-part9.ps1 - 9부 프론트엔드 인증 공통 기능 생성

$ErrorActionPreference = "Stop"

# ============================================================
# 1. 프로젝트 경로
# ============================================================

$Root = Join-Path $env:USERPROFILE "Desktop\secure-starter"

# 보안 검토가 끝난 프로젝트에 예전 생성 코드를 덮어쓰지 않습니다.
if (Test-Path -LiteralPath (Join-Path $Root "SECURITY-REVISION.json")) {
    throw "보안 수정이 적용된 V5입니다. 이전 부별 생성 스크립트 적용을 차단합니다."
}


$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)

Write-Host ""
Write-Host "============================================"
Write-Host " 9부 프론트엔드 공통 인증 기능 생성"
Write-Host "============================================"
Write-Host ""

# ============================================================
# 2. 기존 프로젝트 확인
# ============================================================

$RequiredFiles = @(
    "package.json"
    "apps/web/package.json"
    "apps/web/src/shared/ui/toast.tsx"
    "apps/web/src/shared/api/client.ts"
)

foreach ($RelativePath in $RequiredFiles) {

    $FullPath = Join-Path $Root $RelativePath

    if (-not (Test-Path -LiteralPath $FullPath)) {
        throw "필수 파일이 없습니다: $RelativePath"
    }
}

Write-Host "[확인] 기존 프로젝트 정상" -ForegroundColor Green

# ============================================================
# 3. 생성 대상 파일
# ============================================================

$TargetFiles = @(
    "apps/web/src/shared/auth/auth-client.ts"
    "apps/web/src/shared/auth/auth-provider.tsx"
    "apps/web/src/shared/auth/auth-guard.tsx"
    "apps/web/src/app/starter/toolkit/part9/layout.tsx"
    "apps/web/src/app/starter/toolkit/part9/page.tsx"
    "apps/web/src/app/starter/toolkit/part9/private/page.tsx"
)

# 기존 파일이 있으면 작업을 시작하지 않습니다.

foreach ($RelativePath in $TargetFiles) {

    $FullPath = Join-Path $Root $RelativePath

    if (Test-Path -LiteralPath $FullPath) {
        throw "기존 파일 보호를 위해 중단합니다: $RelativePath"
    }
}

Write-Host "[확인] 기존 파일 충돌 없음" -ForegroundColor Green

# ============================================================
# 4. 파일 생성 공통 함수
# ============================================================

$CreatedFiles = New-Object System.Collections.Generic.List[string]

function Save-Source {

    param(
        [string]$RelativePath,
        [string]$Description,
        [string]$Content
    )

    $FullPath = Join-Path $Root $RelativePath

    $Directory = Split-Path $FullPath -Parent

    if (-not (Test-Path -LiteralPath $Directory)) {

        New-Item `
            -ItemType Directory `
            -Path $Directory `
            -Force | Out-Null
    }

    if (Test-Path -LiteralPath $FullPath) {
        throw "기존 파일을 덮어쓸 수 없습니다: $RelativePath"
    }

    $Header = "// filepath: $RelativePath - $Description`n"

    $Body = $Content.Replace("`r`n", "`n")
    $Body = $Body.Replace("`r", "`n")

    $FinalContent = $Header + $Body.TrimEnd("`n") + "`n"

    # 파일이 이미 존재하면 생성하지 않습니다.
    $Stream = New-Object System.IO.FileStream(
        $FullPath,
        [System.IO.FileMode]::CreateNew,
        [System.IO.FileAccess]::Write,
        [System.IO.FileShare]::None
    )

    $CreatedFiles.Add($FullPath)

    try {

        $Bytes = $Utf8NoBom.GetBytes($FinalContent)

        $Stream.Write(
            $Bytes,
            0,
            $Bytes.Length
        )

    }
    finally {

        $Stream.Dispose()
    }

    Write-Host "[생성 완료] $RelativePath" -ForegroundColor Green
}

# ============================================================
# 5. 파일 생성 시작
# ============================================================

try {

# ============================================================
# 인증 API 클라이언트
# ============================================================

Save-Source "apps/web/src/shared/auth/auth-client.ts" "JWT 인증과 Refresh Token 갱신 및 인증 API 호출" @'
"use client";

// ============================================================
// API 서버 주소
// ============================================================

const configuredUrl =
  process.env.NEXT_PUBLIC_API_BASE_URL ??
  process.env.NEXT_PUBLIC_API_URL ??
  "http://localhost:4000";

const API_ORIGIN = new URL(configuredUrl).origin;

const API_BASE_URL = `${API_ORIGIN}/api/v1`;

// ============================================================
// 인증 API 경로
// ============================================================

// 백엔드 라우트와 일치해야 합니다.

const AUTH_PATHS = {
  login: "/auth/web/login",
  refresh: "/auth/web/refresh",
  logout: "/auth/web/logout"
} as const;

// ============================================================
// 인증 사용자 타입
// ============================================================

export interface AuthUser {
  id: string;
  email: string;
  name: string;
}

// ============================================================
// 인증 응답
// ============================================================

export interface AuthResult {
  accessToken: string;
  user?: AuthUser;
}

// ============================================================
// API 공통 응답
// ============================================================

interface ApiEnvelope<T> {
  success: boolean;
  data?: T;
  message?: string;
  errorCode?: string;
}

// ============================================================
// 인증 오류
// ============================================================

export class AuthRequestError extends Error {

  constructor(
    public readonly status: number,
    public readonly errorCode: string,
    message: string
  ) {
    super(message);

    this.name = "AuthRequestError";
  }
}

// ============================================================
// Access Token 메모리 저장
// ============================================================

// localStorage와 sessionStorage를 사용하지 않습니다.

let accessToken: string | null = null;

// 로그아웃 이후 이전 비동기 요청이
// 인증 상태를 되살리지 못하도록 세대를 관리합니다.

let sessionGeneration = 0;

// Refresh 요청 중복 방지

let refreshPromise: Promise<AuthResult | null> | null = null;

export function getAccessToken(): string | null {
  return accessToken;
}

function setAccessToken(token: string): void {

  sessionGeneration++;

  accessToken = token;
}

export function clearAccessToken(): void {

  sessionGeneration++;

  accessToken = null;
}

// ============================================================
// API 응답 오류 메시지
// ============================================================

function getErrorMessage(
  payload: unknown,
  fallback: string
): string {

  if (
    payload !== null &&
    typeof payload === "object" &&
    "message" in payload &&
    typeof payload.message === "string"
  ) {
    return payload.message;
  }

  return fallback;
}

// ============================================================
// JSON POST 요청
// ============================================================

async function postJson<T>(
  path: string,
  body?: unknown
): Promise<T> {

  const headers = new Headers();

  if (body !== undefined) {
    headers.set(
      "Content-Type",
      "application/json"
    );
  }

  const response = await fetch(
    `${API_BASE_URL}${path}`,
    {
      method: "POST",
      credentials: "include",
      cache: "no-store",
      headers,
      body:
        body === undefined
          ? undefined
          : JSON.stringify(body)
    }
  );

  const payload = await response
    .json()
    .catch(() => null) as ApiEnvelope<T> | null;

  if (
    !response.ok ||
    !payload ||
    payload.success !== true
  ) {

    throw new AuthRequestError(
      response.status,
      payload?.errorCode ?? "API_ERROR",
      getErrorMessage(
        payload,
        "요청을 처리하지 못했습니다."
      )
    );
  }

  return payload.data as T;
}

// ============================================================
// 인증 응답 검증
// ============================================================

function validateAuthResult(
  result: AuthResult
): AuthResult {

  if (
    !result ||
    typeof result.accessToken !== "string" ||
    result.accessToken.length === 0
  ) {

    throw new AuthRequestError(
      500,
      "INVALID_AUTH_RESPONSE",
      "서버 인증 응답이 올바르지 않습니다."
    );
  }

  return result;
}

// ============================================================
// 로그인
// ============================================================

export async function loginRequest(
  email: string,
  password: string
): Promise<AuthResult> {

  const result = validateAuthResult(
    await postJson<AuthResult>(
      AUTH_PATHS.login,
      {
        email,
        password
      }
    )
  );

  setAccessToken(result.accessToken);

  return result;
}

// ============================================================
// Refresh Token으로 인증 갱신
// ============================================================

export async function refreshSession():
  Promise<AuthResult | null> {

  // 이미 갱신 중이면 같은 Promise를 사용합니다.

  if (refreshPromise) {
    return refreshPromise;
  }

  const generation = sessionGeneration;

  const task = (async (): Promise<AuthResult | null> => {

    try {

      const result = validateAuthResult(
        await postJson<AuthResult>(
          AUTH_PATHS.refresh
        )
      );

      // 요청 중 로그아웃하거나 새로 로그인했다면
      // 오래된 갱신 결과를 무시합니다.

      if (generation !== sessionGeneration) {
        return null;
      }

      accessToken = result.accessToken;

      return result;

    }
    catch {

      if (generation === sessionGeneration) {
        accessToken = null;
      }

      return null;
    }

  })();

  refreshPromise = task;

  try {

    return await task;

  }
  finally {

    if (refreshPromise === task) {
      refreshPromise = null;
    }
  }
}

// ============================================================
// 로그아웃
// ============================================================

export async function logoutRequest(): Promise<void> {

  const headers = new Headers();

  if (accessToken) {

    headers.set(
      "Authorization",
      `Bearer ${accessToken}`
    );
  }

  const response = await fetch(
    `${API_BASE_URL}${AUTH_PATHS.logout}`,
    {
      method: "POST",
      credentials: "include",
      cache: "no-store",
      headers
    }
  );

  // 서버 로그아웃 실패 시 로컬 상태만 지우지 않습니다.
  // Refresh Cookie가 유효한 상태로 남을 수 있기 때문입니다.

  if (!response.ok) {

    throw new AuthRequestError(
      response.status,
      "LOGOUT_FAILED",
      "서버 로그아웃에 실패했습니다. 다시 시도해 주세요."
    );
  }

  clearAccessToken();
}

// ============================================================
// 인증 만료 이벤트
// ============================================================

export const AUTH_EXPIRED_EVENT = "starter:auth-expired";

function notifyAuthExpired(): void {

  if (typeof window !== "undefined") {

    window.dispatchEvent(
      new Event(AUTH_EXPIRED_EVENT)
    );
  }
}

// ============================================================
// 인증 API 요청
// ============================================================

// 안전한 GET/HEAD 요청만 자동으로 한 번 재시도합니다.
// POST/PATCH/PUT/DELETE는 중복 실행 위험을 줄이기 위해
// 인증 갱신 후에도 자동 재전송하지 않습니다.

export async function authorizedFetch(
  path: string,
  options: RequestInit = {}
): Promise<Response> {

  // API 서버 이외의 주소로 토큰이 전달되지 않도록
  // 상대 경로만 허용합니다.

  if (
    !path.startsWith("/") ||
    path.startsWith("//") ||
    path.includes("\\")
  ) {

    throw new Error(
      "API 요청 경로가 올바르지 않습니다."
    );
  }

  const method = (
    options.method ?? "GET"
  ).toUpperCase();

  const canRetry =
    method === "GET" ||
    method === "HEAD";

  const requestUrl = new URL(
    `${API_BASE_URL}${path}`
  );

  if (
    requestUrl.origin !== API_ORIGIN ||
    !requestUrl.pathname.startsWith("/api/v1/")
  ) {

    throw new Error(
      "허용되지 않은 API 요청 경로입니다."
    );
  }

  // 토큰이 없다면 Refresh Cookie로 복구를 시도합니다.

  if (!accessToken) {

    const refreshed = await refreshSession();

    if (!refreshed) {

      notifyAuthExpired();

      throw new AuthRequestError(
        401,
        "UNAUTHORIZED",
        "로그인이 필요합니다."
      );
    }
  }

  const sendRequest = async (): Promise<Response> => {

    const headers = new Headers(options.headers);

    if (accessToken) {

      headers.set(
        "Authorization",
        `Bearer ${accessToken}`
      );
    }

    return fetch(
      requestUrl.toString(),
      {
        ...options,
        method,
        headers,
        credentials: "include",
        cache: "no-store"
      }
    );
  };

  let response = await sendRequest();

  if (response.status !== 401) {
    return response;
  }

  // 만료된 Access Token 갱신

  const refreshed = await refreshSession();

  if (!refreshed) {

    clearAccessToken();

    notifyAuthExpired();

    throw new AuthRequestError(
      401,
      "SESSION_EXPIRED",
      "로그인 세션이 만료되었습니다."
    );
  }

  // 변경 요청은 자동 재전송하지 않습니다.

  if (!canRetry) {

    throw new AuthRequestError(
      401,
      "RETRY_REQUIRED",
      "인증이 갱신되었습니다. 요청을 다시 실행해 주세요."
    );
  }

  // GET/HEAD 요청만 한 번 재시도합니다.

  response = await sendRequest();

  return response;
}
'@


# ============================================================
# 인증 상태 Provider
# ============================================================

Save-Source "apps/web/src/shared/auth/auth-provider.tsx" "로그인 상태와 세션 갱신 및 탭 간 로그아웃 동기화" @'
"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState
} from "react";

import type {
  ReactNode
} from "react";

import {
  AUTH_EXPIRED_EVENT,
  clearAccessToken,
  loginRequest,
  logoutRequest,
  refreshSession
} from "./auth-client";

import type {
  AuthUser
} from "./auth-client";

// ============================================================
// 인증 상태
// ============================================================

export type AuthStatus =
  | "checking"
  | "authenticated"
  | "guest";

// ============================================================
// Context 타입
// ============================================================

interface AuthContextValue {

  status: AuthStatus;

  user: AuthUser | null;

  login: (
    email: string,
    password: string
  ) => Promise<void>;

  logout: () => Promise<void>;

  refresh: () => Promise<boolean>;
}

// ============================================================
// Context
// ============================================================

const AuthContext =
  createContext<AuthContextValue | null>(null);

// ============================================================
// 브라우저 탭 동기화 채널
// ============================================================

const AUTH_CHANNEL = "starter-auth-events";

// ============================================================
// 인증 Provider
// ============================================================

export function AuthProvider({
  children
}: {
  children: ReactNode;
}) {

  const [status, setStatus] =
    useState<AuthStatus>("checking");

  const [user, setUser] =
    useState<AuthUser | null>(null);

  // ==========================================================
  // 인증 상태 초기화
  // ==========================================================

  useEffect(() => {

    let active = true;

    const initialize = async () => {

      const result = await refreshSession();

      if (!active) {
        return;
      }

      if (result) {

        setUser(result.user ?? null);

        setStatus("authenticated");

      }
      else {

        setUser(null);

        setStatus("guest");
      }
    };

    void initialize();

    // ========================================================
    // 인증 만료 처리
    // ========================================================

    const handleExpired = () => {

      setUser(null);

      setStatus("guest");
    };

    window.addEventListener(
      AUTH_EXPIRED_EVENT,
      handleExpired
    );

    // ========================================================
    // 다른 탭의 로그아웃 처리
    // ========================================================

    const channel =
      typeof BroadcastChannel !== "undefined"
        ? new BroadcastChannel(AUTH_CHANNEL)
        : null;

    if (channel) {

      channel.onmessage = (event) => {

        if (event.data === "logout") {

          clearAccessToken();

          setUser(null);

          setStatus("guest");
        }
      };
    }

    return () => {

      active = false;

      window.removeEventListener(
        AUTH_EXPIRED_EVENT,
        handleExpired
      );

      channel?.close();
    };

  }, []);

  // ==========================================================
  // 로그인
  // ==========================================================

  const login = useCallback(
    async (
      email: string,
      password: string
    ) => {

      const result = await loginRequest(
        email,
        password
      );

      setUser(result.user ?? null);

      setStatus("authenticated");
    },
    []
  );

  // ==========================================================
  // 로그아웃
  // ==========================================================

  const logout = useCallback(
    async () => {

      await logoutRequest();

      setUser(null);

      setStatus("guest");

      // 다른 브라우저 탭에 로그아웃을 알립니다.

      if (typeof BroadcastChannel !== "undefined") {

        const channel =
          new BroadcastChannel(AUTH_CHANNEL);

        channel.postMessage("logout");

        channel.close();
      }
    },
    []
  );

  // ==========================================================
  // 수동 인증 갱신
  // ==========================================================

  const refresh = useCallback(
    async (): Promise<boolean> => {

      const result = await refreshSession();

      if (!result) {

        setUser(null);

        setStatus("guest");

        return false;
      }

      setUser(result.user ?? null);

      setStatus("authenticated");

      return true;
    },
    []
  );

  // ==========================================================
  // Context 값
  // ==========================================================

  const value = useMemo<AuthContextValue>(
    () => ({
      status,
      user,
      login,
      logout,
      refresh
    }),
    [
      status,
      user,
      login,
      logout,
      refresh
    ]
  );

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

// ============================================================
// 인증 상태 Hook
// ============================================================

export function useAuth(): AuthContextValue {

  const context = useContext(AuthContext);

  if (!context) {

    throw new Error(
      "AuthProvider 내부에서 useAuth를 사용해야 합니다."
    );
  }

  return context;
}
'@


# ============================================================
# 인증 접근 제어
# ============================================================

Save-Source "apps/web/src/shared/auth/auth-guard.tsx" "인증되지 않은 사용자의 보호 페이지 접근 제한" @'
"use client";

import Link from "next/link";

import type {
  ReactNode
} from "react";

import {
  useAuth
} from "./auth-provider";

// ============================================================
// 보호 페이지
// ============================================================

export function AuthGuard({
  children
}: {
  children: ReactNode;
}) {

  const {
    status
  } = useAuth();

  // ==========================================================
  // 인증 확인 중
  // ==========================================================

  if (status === "checking") {

    return (
      <main
        style={{
          padding: 32,
          maxWidth: 900,
          margin: "0 auto"
        }}
      >
        <h1>인증 상태 확인</h1>

        <p role="status">
          로그인 상태를 확인하고 있습니다.
        </p>
      </main>
    );
  }

  // ==========================================================
  // 비로그인 사용자
  // ==========================================================

  if (status === "guest") {

    return (
      <main
        style={{
          padding: 32,
          maxWidth: 900,
          margin: "0 auto"
        }}
      >
        <h1>로그인이 필요합니다.</h1>

        <p>
          이 페이지는 인증된 사용자만
          이용할 수 있습니다.
        </p>

        <Link
          href="/starter/toolkit/part9"
        >
          로그인 화면으로 이동
        </Link>
      </main>
    );
  }

  // ==========================================================
  // 인증된 사용자
  // ==========================================================

  return <>{children}</>;
}
'@


# ============================================================
# 9부 레이아웃
# ============================================================

Save-Source "apps/web/src/app/starter/toolkit/part9/layout.tsx" "9부 인증 Provider와 8부 Toast Provider 연결" @'
import type {
  ReactNode
} from "react";

import {
  AuthProvider
} from "../../../../shared/auth/auth-provider";

import {
  ToastProvider
} from "../../../../shared/ui/toast";

// ============================================================
// 9부 공통 레이아웃
// ============================================================

// 기존 프로젝트 전체의 레이아웃을 수정하지 않습니다.
// 9부 경로 내부에만 인증 상태 관리 기능을 적용합니다.

export default function Part9Layout({
  children
}: {
  children: ReactNode;
}) {

  return (
    <AuthProvider>
      <ToastProvider>
        {children}
      </ToastProvider>
    </AuthProvider>
  );
}
'@


# ============================================================
# 9부 인증 관리 페이지
# ============================================================

Save-Source "apps/web/src/app/starter/toolkit/part9/page.tsx" "로그인 로그아웃 인증 갱신 및 보호 페이지 진입 화면" @'
"use client";

import {
  useState
} from "react";

import type {
  FormEvent
} from "react";

import Link from "next/link";

import {
  useAuth
} from "../../../../shared/auth/auth-provider";

import {
  useToast
} from "../../../../shared/ui/toast";

// ============================================================
// 9부 인증 관리 화면
// ============================================================

export default function Part9Page() {

  const {
    status,
    user,
    login,
    logout,
    refresh
  } = useAuth();

  const notify = useToast();

  const [email, setEmail] = useState("");

  const [password, setPassword] = useState("");

  const [busy, setBusy] = useState(false);

  // ==========================================================
  // 로그인
  // ==========================================================

  const handleLogin = async (
    event: FormEvent<HTMLFormElement>
  ) => {

    event.preventDefault();

    if (busy) {
      return;
    }

    setBusy(true);

    try {

      await login(
        email.trim(),
        password
      );

      setPassword("");

      notify(
        "로그인에 성공했습니다.",
        "success"
      );

    }
    catch (error) {

      notify(
        error instanceof Error
          ? error.message
          : "로그인에 실패했습니다.",
        "error"
      );

    }
    finally {

      setBusy(false);
    }
  };

  // ==========================================================
  // 로그아웃
  // ==========================================================

  const handleLogout = async () => {

    if (busy) {
      return;
    }

    const confirmed = window.confirm(
      "로그아웃하시겠습니까?"
    );

    if (!confirmed) {
      return;
    }

    setBusy(true);

    try {

      await logout();

      notify(
        "로그아웃되었습니다.",
        "success"
      );

    }
    catch (error) {

      notify(
        error instanceof Error
          ? error.message
          : "로그아웃에 실패했습니다.",
        "error"
      );

    }
    finally {

      setBusy(false);
    }
  };

  // ==========================================================
  // 인증 갱신
  // ==========================================================

  const handleRefresh = async () => {

    if (busy) {
      return;
    }

    setBusy(true);

    try {

      const result = await refresh();

      if (result) {

        notify(
          "인증 상태가 갱신되었습니다.",
          "success"
        );

      }
      else {

        notify(
          "유효한 로그인 세션이 없습니다.",
          "error"
        );
      }

    }
    catch {

      notify(
        "인증 갱신에 실패했습니다.",
        "error"
      );

    }
    finally {

      setBusy(false);
    }
  };

  // ==========================================================
  // 화면
  // ==========================================================

  return (
    <main
      style={{
        maxWidth: 900,
        margin: "0 auto",
        padding: 32
      }}
    >

      <h1>
        9부 - 공통 인증 관리
      </h1>

      <p>
        JWT 인증, 자동 갱신, 접근 권한,
        브라우저 탭 동기화 기능을 관리합니다.
      </p>

      <hr />

      <section
        style={{
          marginTop: 24,
          marginBottom: 24
        }}
      >

        <h2>현재 인증 상태</h2>

        <p role="status">

          {status === "checking"
            ? "인증 상태 확인 중"
            : status === "authenticated"
              ? "로그인 상태"
              : "로그아웃 상태"}

        </p>

        {user && (
          <div>

            <p>
              회원 이름: {user.name}
            </p>

            <p>
              이메일: {user.email}
            </p>

          </div>
        )}

      </section>

      <hr />

      {status === "guest" && (

        <section
          style={{
            marginTop: 24
          }}
        >

          <h2>로그인</h2>

          <form
            onSubmit={handleLogin}
            style={{
              display: "grid",
              gap: 12,
              maxWidth: 420
            }}
          >

            <label htmlFor="part9-email">
              이메일
            </label>

            <input
              id="part9-email"
              type="email"
              autoComplete="username"
              required
              value={email}
              onChange={(event) =>
                setEmail(event.target.value)
              }
              style={{
                padding: 12
              }}
            />

            <label htmlFor="part9-password">
              비밀번호
            </label>

            <input
              id="part9-password"
              type="password"
              autoComplete="current-password"
              required
              value={password}
              onChange={(event) =>
                setPassword(event.target.value)
              }
              style={{
                padding: 12
              }}
            />

            <button
              type="submit"
              disabled={busy}
              style={{
                padding: 12,
                cursor: "pointer"
              }}
            >
              {busy ? "처리 중..." : "로그인"}
            </button>

          </form>

          <p>
            계정이 없다면{" "}
            <Link href="/starter/register">
              회원가입
            </Link>
          </p>

        </section>
      )}

      {status === "authenticated" && (

        <section
          style={{
            marginTop: 24
          }}
        >

          <h2>인증 관리</h2>

          <div
            style={{
              display: "flex",
              flexWrap: "wrap",
              gap: 12
            }}
          >

            <button
              type="button"
              onClick={handleRefresh}
              disabled={busy}
              style={{
                padding: 12
              }}
            >
              인증 갱신
            </button>

            <button
              type="button"
              onClick={handleLogout}
              disabled={busy}
              style={{
                padding: 12
              }}
            >
              로그아웃
            </button>

          </div>

          <div
            style={{
              marginTop: 24
            }}
          >

            <h3>보호된 페이지</h3>

            <Link
              href="/starter/toolkit/part9/private"
            >
              인증된 게시글 조회 페이지
            </Link>

          </div>

        </section>
      )}

      <hr
        style={{
          marginTop: 32
        }}
      />

      <section>

        <h2>적용된 보안 정책</h2>

        <ul>

          <li>
            Access Token 메모리 저장
          </li>

          <li>
            Refresh 요청 중복 방지
          </li>

          <li>
            JWT 자동 첨부
          </li>

          <li>
            인증 만료 감지
          </li>

          <li>
            GET 요청의 제한적 자동 재시도
          </li>

          <li>
            브라우저 탭 간 로그아웃 동기화
          </li>

          <li>
            인증되지 않은 사용자의 페이지 접근 제한
          </li>

        </ul>

      </section>

      <p
        style={{
          marginTop: 32
        }}
      >

        <Link href="/starter/toolkit">
          공통 기능 화면으로 돌아가기
        </Link>

      </p>

    </main>
  );
}
'@


# ============================================================
# 보호된 게시글 조회 페이지
# ============================================================

Save-Source "apps/web/src/app/starter/toolkit/part9/private/page.tsx" "JWT 인증을 거쳐 게시글을 조회하는 보호 페이지" @'
"use client";

import {
  useEffect,
  useState
} from "react";

import Link from "next/link";

import {
  AuthGuard
} from "../../../../../shared/auth/auth-guard";

import {
  useAuth
} from "../../../../../shared/auth/auth-provider";

import {
  authorizedFetch
} from "../../../../../shared/auth/auth-client";

// ============================================================
// 게시글 타입
// ============================================================

interface Note {
  id: string;
  title: string;
  content: string;
}

interface NotesResponse {
  success: boolean;
  data?: {
    items: Note[];
  };
  message?: string;
}

// ============================================================
// 인증된 게시글 화면
// ============================================================

function PrivateNotesContent() {

  const {
    status
  } = useAuth();

  const [notes, setNotes] = useState<Note[]>([]);

  const [loading, setLoading] = useState(true);

  const [error, setError] = useState<string | null>(null);

  // ==========================================================
  // 게시글 조회
  // ==========================================================

  useEffect(() => {

    if (status !== "authenticated") {
      return;
    }

    const controller = new AbortController();

    const loadNotes = async () => {

      setLoading(true);

      setError(null);

      try {

        const response = await authorizedFetch(
          "/notes?page=1&limit=5",
          {
            method: "GET",
            signal: controller.signal
          }
        );

        if (!response.ok) {

          throw new Error(
            `게시글 조회 실패: HTTP ${response.status}`
          );
        }

        const result =
          await response.json() as NotesResponse;

        if (
          result.success !== true ||
          !Array.isArray(result.data?.items)
        ) {

          throw new Error(
            "게시글 응답 형식이 올바르지 않습니다."
          );
        }

        if (!controller.signal.aborted) {

          setNotes(result.data.items);
        }

      }
      catch (caught) {

        if (!controller.signal.aborted) {

          setError(
            caught instanceof Error
              ? caught.message
              : "게시글을 조회하지 못했습니다."
          );
        }

      }
      finally {

        if (!controller.signal.aborted) {

          setLoading(false);
        }
      }
    };

    void loadNotes();

    return () => {

      controller.abort();
    };

  }, [status]);

  // ==========================================================
  // 화면
  // ==========================================================

  return (
    <main
      style={{
        maxWidth: 900,
        margin: "0 auto",
        padding: 32
      }}
    >

      <h1>
        인증된 게시글 조회
      </h1>

      <p>
        JWT 인증을 통과한 사용자만
        게시글을 조회할 수 있습니다.
      </p>

      {loading && (
        <p role="status">
          게시글을 불러오는 중입니다.
        </p>
      )}

      {error && (
        <p role="alert">
          {error}
        </p>
      )}

      {!loading && !error && notes.length === 0 && (
        <p>
          등록된 게시글이 없습니다.
        </p>
      )}

      {!loading && !error && notes.length > 0 && (

        <ul
          style={{
            display: "grid",
            gap: 16,
            padding: 0,
            listStyle: "none"
          }}
        >

          {notes.map((note) => (

            <li
              key={note.id}
              style={{
                padding: 20,
                border: "1px solid #ddd",
                borderRadius: 8
              }}
            >

              <h2>
                {note.title}
              </h2>

              <p>
                {note.content}
              </p>

            </li>
          ))}

        </ul>
      )}

      <p
        style={{
          marginTop: 32
        }}
      >

        <Link href="/starter/toolkit/part9">
          인증 관리 화면으로 돌아가기
        </Link>

      </p>

    </main>
  );
}

// ============================================================
// 접근 제어 적용
// ============================================================

export default function PrivatePage() {

  return (
    <AuthGuard>
      <PrivateNotesContent />
    </AuthGuard>
  );
}
'@


# ============================================================
# 6. 생성 결과 확인
# ============================================================

Write-Host ""
Write-Host "============================================"
Write-Host " 9부 파일 생성 결과"
Write-Host "============================================"
Write-Host ""

$Verified = 0

foreach ($RelativePath in $TargetFiles) {

    $FullPath = Join-Path $Root $RelativePath

    if (Test-Path -LiteralPath $FullPath) {

        $Verified++

        Write-Host "[정상] $RelativePath" -ForegroundColor Green
    }
    else {

        Write-Host "[실패] $RelativePath" -ForegroundColor Red
    }
}

if ($Verified -ne $TargetFiles.Count) {

    throw "일부 파일이 생성되지 않았습니다."
}

Write-Host ""
Write-Host "============================================"
Write-Host " 9부 프론트엔드 파일 생성 완료"
Write-Host "============================================" -ForegroundColor Green
Write-Host ""

Write-Host "생성된 파일: $Verified / $($TargetFiles.Count)"
Write-Host "인코딩: UTF-8 BOM 없음"
Write-Host "기존 프로젝트 파일: 변경 없음"
Write-Host "데이터베이스: 변경 없음"
Write-Host ""

}
catch {

    # ========================================================
    # 생성 도중 실패하면 이번 실행에서 만든 파일만 정리
    # ========================================================

    Write-Host ""
    Write-Host "[오류] 파일 생성 도중 문제가 발생했습니다." -ForegroundColor Red

    foreach ($CreatedFile in $CreatedFiles) {

        if (Test-Path -LiteralPath $CreatedFile) {

            Remove-Item `
                -LiteralPath $CreatedFile `
                -Force
        }
    }

    Write-Host "이번 실행에서 생성한 파일을 정리했습니다." -ForegroundColor Yellow

    throw
}

