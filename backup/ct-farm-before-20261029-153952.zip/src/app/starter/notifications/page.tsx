"use client";
import { useState } from "react";
import { useAuth } from "../_lib/auth";
type Notice = { id: string; title: string; message: string; readAt: string | null };
export default function NotificationsPage() {
  const { user, request } = useAuth(); const [items, setItems] = useState<Notice[]>([]); const [error, setError] = useState(""); const [busy, setBusy] = useState(false);
  async function load() { setBusy(true); setError(""); try { setItems(await request("/notifications")); } catch (e) { setError(e instanceof Error ? e.message : "조회 실패"); } finally { setBusy(false); } }
  return <section className="starter-card"><h1>알림</h1><p role="alert">{error}</p><button disabled={!user || busy} onClick={load}>알림 새로고침</button>{!items.length && <p>표시할 알림이 없습니다.</p>}<ul>{items.map(item => <li key={item.id}><h2>{item.title}</h2><p>{item.message}</p><button disabled={!!item.readAt || busy} onClick={async () => { setBusy(true); try { await request(`/notifications/${item.id}/read`, { method: "PATCH" }); setItems(items.map(old => old.id === item.id ? { ...old, readAt: new Date().toISOString() } : old)); } catch (e) { setError(e instanceof Error ? e.message : "처리 실패"); } finally { setBusy(false); } }}>{item.readAt ? "읽음" : "읽음 처리"}</button></li>)}</ul></section>;
}
