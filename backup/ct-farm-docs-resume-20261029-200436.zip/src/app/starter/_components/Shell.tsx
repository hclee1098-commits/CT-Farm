// filepath: apps/web/src/app/starter/_components/Shell.tsx - 상단 메뉴와 로그인 상태 및 공통 화면 구성
"use client";

import Link from "next/link";

import {
  useRouter
} from "next/navigation";

import type {
  ReactNode
} from "react";

import {
  useState
} from "react";

import {
  useAuth
} from "../_lib/auth";

export function StarterShell({
  children
}: {
  children: ReactNode;
}) {

  const router = useRouter();

  const {
    user,
    loading,
    logout
  } = useAuth();

  const [error, setError] = useState("");

  async function handleLogout() {

    setError("");

    try {

      await logout();

      router.push("/starter/login");

    }
    catch {

      setError(
        "로그아웃 요청을 완료하지 못했습니다. 서버 연결을 확인해 주세요."
      );

    }
  }

  return (
    <div className="starter-root">

      <header className="starter-header">

        <div className="starter-header-inner">

          <Link
            href="/starter"
            className="starter-logo"
          >
            {/* SVG 원본을 사용해 작은 화면에서도 브랜드를 선명하게 표시합니다. */}
            <img src="/brand/logo-light.svg" alt="CT-Farm" width={164} height={35} />
          </Link>

          <nav className="starter-nav">

            <Link href="/starter">
              홈
            </Link>
            <a href="/docs-center/index.html">도움말 · 문서</a>

            {user && (
              <>
                <Link href="/starter/farms">내 농장 · 영농일지</Link>
                <Link href="/starter/notes">
                  게시글
                </Link>

                <Link href="/starter/account">계정 보안</Link>
                <Link href="/starter/notifications">알림</Link>
                {user.role === "ADMIN" && <Link href="/starter/admin">관리자</Link>}
                <Link href="/starter/files">
                  파일 관리
                </Link>
              </>
            )}

          </nav>

          <div className="starter-account">

            {!loading && !user && (
              <>
                <Link
                  href="/starter/login"
                  className="starter-button secondary"
                >
                  로그인
                </Link>

                <Link
                  href="/starter/register"
                  className="starter-button"
                >
                  회원가입
                </Link>
              </>
            )}

            {!loading && user && (
              <>
                <span className="starter-user">
                  {user.name}님
                </span>

                <button
                  type="button"
                  className="starter-button secondary"
                  onClick={handleLogout}
                >
                  로그아웃
                </button>
              </>
            )}

          </div>

        </div>

      </header>

      {error && (
        <div className="starter-global-error">
          {error}
        </div>
      )}

      <main className="starter-main">
        {children}
      </main>

      <footer className="starter-footer">
        CT-Farm · 농장과 영농일지 관리
      </footer>

    </div>
  );
}

