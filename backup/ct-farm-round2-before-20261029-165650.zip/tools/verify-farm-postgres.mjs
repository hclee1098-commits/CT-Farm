// 기존 DB는 먼저 암호화 백업하고, 별도 DB에 복원해 추가 마이그레이션을 검증합니다.
import { execFile, spawn } from 'node:child_process';
import { promisify } from 'node:util';
import { promises as fs } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomBytes, createHash } from 'node:crypto';
import dotenv from 'dotenv';
import { encryptBackup, decryptBackup } from './backup.mjs';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const rawExec = promisify(execFile);
const exec = async (...args) => {
  try { return await rawExec(...args); }
  catch { throw new Error('DB 검증 하위 명령이 실패했습니다. 연결 문자열과 비밀키는 출력하지 않습니다.'); }
};
const environment = { ...dotenv.parse(await fs.readFile(path.join(root, '.env'))), ...dotenv.parse(await fs.readFile(path.join(root, 'apps/api/.env'))), ...process.env };
const project = environment.COMPOSE_PROJECT_NAME;
if (!/^[a-z][a-z0-9_-]{2,63}$/.test(project ?? '')) throw new Error('프로젝트 식별자 확인 필요');
const sourceUrl = new URL(environment.DATABASE_URL);
if (!['localhost', '127.0.0.1'].includes(sourceUrl.hostname)) throw new Error('로컬 DB만 검증합니다.');
const database = 'ct_farm_verify_' + randomBytes(6).toString('hex');
const args = ['compose', 'exec', '-T', 'postgres'];
async function docker(tail, input) {
  return new Promise((resolve, reject) => {
    const child = spawn('docker', [...args, ...tail], { cwd: root, env: environment, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true });
    const output = [], errors = [];
    child.stdout.on('data', b => output.push(b)); child.stderr.on('data', b => errors.push(b));
    child.on('error', reject); child.on('close', code => code === 0 ? resolve(Buffer.concat(output)) : reject(new Error(`Docker DB 검사 실패 (${code}); 비밀정보 보호를 위해 원문은 출력하지 않습니다.`)));
    child.stdin.end(input);
  });
}
const stamp = Date.now();
const dump = await docker(['sh', '-c', 'pg_dump -U "$POSTGRES_USER" -d "$POSTGRES_DB" --format=custom --no-owner --no-privileges']);
await fs.mkdir(path.join(root, '.starter-state'), { recursive: true });
const keyPath = path.join(root, '.starter-state/ct-farm-backup.key');
let key;
try { key = await fs.readFile(keyPath); } catch (e) {
  if (e.code !== 'ENOENT') throw e;
  key = randomBytes(32); await fs.writeFile(keyPath, key, { flag: 'wx', mode: 0o600 });
}
if (key.length !== 32) throw new Error('백업 키 형식 오류');
const encrypted = encryptBackup({ version: 1, project, createdAt: new Date().toISOString(), database: { name: 'database.dump', data: dump.toString('base64'), sha256: createHash('sha256').update(dump).digest('hex') }, files: [] }, key);
const backup = path.join(root, `backup/ct-farm-postgres-${stamp}.ssbk`);
await fs.writeFile(backup, encrypted, { flag: 'wx', mode: 0o600 });
const restoredDump = Buffer.from(decryptBackup(await fs.readFile(backup), key).database.data, 'base64');
await docker(['sh', '-c', 'createdb -U "$POSTGRES_USER" "$1"', 'ct-farm', database]);
await docker(['sh', '-c', 'pg_restore -U "$POSTGRES_USER" -d "$1" --single-transaction --exit-on-error --no-owner --no-privileges', 'ct-farm', database], restoredDump);
const isolatedUrl = new URL(sourceUrl); isolatedUrl.pathname = '/' + database;
const prisma = path.join(root, 'node_modules/prisma/build/index.js');
const schema = path.join(root, 'apps/api/prisma/schema.prisma');
const childEnv = { ...environment, DATABASE_URL: isolatedUrl.toString() };
// PostgreSQL 자체가 계산한 사용자 테이블별 데이터 지문. 기존 행의 변경을 검출합니다.
const fingerprint = `DO $$ DECLARE r record; v text; BEGIN CREATE TEMP TABLE ct_farm_fingerprints(name text, digest text); FOR r IN SELECT tablename FROM pg_tables WHERE schemaname='public' AND tablename <> '_prisma_migrations' LOOP EXECUTE format('SELECT md5(coalesce(string_agg(row_to_json(t)::text, chr(10) ORDER BY row_to_json(t)::text), '''')) FROM %I t', r.tablename) INTO v; INSERT INTO ct_farm_fingerprints VALUES(r.tablename,v); END LOOP; END $$; SELECT name || ':' || digest FROM ct_farm_fingerprints ORDER BY name;`;
const print = async dbName => (await docker(['sh', '-c', 'psql -X -q -A -t -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d "$1"', 'ct-farm', dbName], fingerprint)).toString().trim().split('\n').filter(Boolean);
const before = await print(database);
await exec(process.execPath, [prisma, 'migrate', 'deploy', '--schema', schema], { cwd: root, env: childEnv, timeout: 60000 });
await exec(process.execPath, [prisma, 'migrate', 'diff', '--from-url', isolatedUrl.toString(), '--to-schema-datamodel', schema, '--exit-code'], { cwd: root, env: childEnv, timeout: 60000 });
const after = await print(database);
if (!before.every(line => after.includes(line))) throw new Error('기존 행 지문 변경: 적용 중단');
const report = { at: new Date().toISOString(), backup: path.relative(root, backup), restoreDatabase: database, nativePostgres: true, isolatedRestore: true, migrationDeploy: true, schemaDiff: false, preservedTables: before.length, appliedToExisting: false };
if(process.argv.includes('--test-operations')){
  const tested=await exec(process.execPath,['--import','tsx',path.join(root,'tools/test-farm.mts')],{cwd:root,env:{...childEnv,FARM_TEST_DATABASE_URL:isolatedUrl.toString()},timeout:60000});
  console.log(tested.stdout);report.operationsIntegration=true;
}
if (process.argv.includes('--apply-existing')) {
  // 원본 지문이 백업 당시와 같을 때만 기존 DB에 추가 마이그레이션을 적용합니다.
  const sourceBefore = await print(decodeURIComponent(sourceUrl.pathname.slice(1)));
  if (sourceBefore.join('\n') !== before.join('\n')) throw new Error('백업 후 원본 데이터가 변경됨: 적용 중단');
  await exec(process.execPath, [prisma, 'migrate', 'deploy', '--schema', schema], { cwd: root, env: environment, timeout: 60000 });
  const sourceAfter = await print(decodeURIComponent(sourceUrl.pathname.slice(1)));
  if (!sourceBefore.every(line => sourceAfter.includes(line))) throw new Error('원본 DB의 기존 행 지문 불일치');
  report.appliedToExisting = true;
}
await fs.writeFile(path.join(root, 'verification/ct-farm-postgres.json'), JSON.stringify(report, null, 2));
console.log(JSON.stringify(report));
console.log('암호화 키는 .starter-state/ct-farm-backup.key에 별도 보관됩니다. 격리 복원 DB와 기존 볼륨은 삭제하지 않았습니다.');
