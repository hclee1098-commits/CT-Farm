"use client";
import Link from 'next/link';
import {useCallback,useEffect,useState} from 'react';
import {useAuth} from '../_lib/auth';
type Dashboard={farmCount:number;farms:{id:string;name:string;crop:string;stage:string}[];entries:{id:string;farmId:string;title:string;workDate:string}[];records:{id:string;farmId:string;kind:string;data:Record<string,string>}[];sensors:{id:string;farmId:string;name:string;simulated:boolean;readings:{value:number;measuredAt:string}[]}[];notifications:{id:string;title:string}[];photos:{id:string;fileId:string;diaryId:string}[];limits:{farms:number;records:number;sensors:number}};
const stages:Record<string,string>={PREPARING:'재배 준비',SOWING:'씨뿌리기·옮겨심기',GROWING:'자라는 중',HARVESTING:'수확 중',RESTING:'쉬는 밭'};
function PrivatePhoto({fileId}:{fileId:string}){const {authorizedFetch}=useAuth();const [url,setUrl]=useState('');useEffect(()=>{let active=true,objectUrl='';authorizedFetch(`/files/${fileId}/thumbnail`).then(async r=>{if(!r.ok)return;const b=await r.blob();if(!active)return;objectUrl=URL.createObjectURL(b);setUrl(objectUrl);}).catch(()=>{});return()=>{active=false;if(objectUrl)URL.revokeObjectURL(objectUrl);};},[authorizedFetch,fileId]);return url?<img src={url} alt="최근 영농일지에 등록한 사진" width={140} height={100}/>:<span>사진을 불러올 수 없습니다. 파일 관리에서 확인해 주세요.</span>;}
export function FarmDashboard(){
 const {user,request}=useAuth();const [data,setData]=useState<Dashboard|null>(null),[error,setError]=useState(''),[busy,setBusy]=useState(false);
 const load=useCallback(async()=>{setBusy(true);setError('');try{setData(await request<Dashboard>('/workspace/dashboard'));}catch{setError('농장 정보를 불러오지 못했습니다. 연결을 확인하고 다시 눌러 주세요.');}finally{setBusy(false);}},[request]);useEffect(()=>{void load();},[load]);
 const today=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
 const tasks=(data?.records||[]).filter(r=>r.kind==='TASK'&&r.data.status==='TODO').sort((a,b)=>a.data.dueDate.localeCompare(b.data.dueDate));
 const todo=tasks.filter(t=>t.data.dueDate<=today);const next=tasks.filter(t=>t.data.dueDate>today).slice(0,5);
 return <div className="starter-container farmer-dashboard" aria-busy={busy}><h1>오늘의 농장</h1><p>{user?.name}님, 반갑습니다. 오늘 {today}</p><p>내 농장의 실제 기록을 모았어요.</p>
 <div className="farmer-shortcuts"><Link href="/starter/diary">＋ 영농일지 쓰기</Link><Link href="/starter/schedule">오늘 할 일 보기</Link><Link href="/starter/farms">내 농장 관리</Link></div>
 {error&&<p role="alert">{error}</p>}<button type="button" disabled={busy} onClick={()=>void load()}>{busy?'불러오는 중…':'새로고침'}</button>
 {!data&&!error&&<p role="status">농장 기록을 불러오고 있습니다.</p>}
 {data&&<div className="farmer-grid"><section className="starter-card"><h2>주의할 알림</h2>{data.notifications.length?data.notifications.map(n=><p key={n.id}><Link href="/starter/notifications">{n.title}</Link></p>):<p>아직 읽지 않은 알림이 없습니다.</p>}</section>
 <section className="starter-card"><h2>오늘까지 해야 할 일 {todo.length}개</h2>{todo.length?todo.map(t=><p key={t.id}><Link href={`/starter/farms/${t.farmId}`}>{t.data.title}</Link> · {t.data.dueDate<today?'기한 지남': '오늘'}</p>):<p>등록된 할 일이 없습니다. 일정에서 새 작업을 적어 보세요.</p>}</section>
 <section className="starter-card"><h2>내 농장 {data.farmCount}곳</h2>{data.farms.length?data.farms.map(f=><p key={f.id}><Link href={`/starter/farms/${f.id}`}>{f.name}</Link> · {f.crop||'작물 미등록'} · {stages[f.stage]||f.stage}</p>):<p>농장이 없습니다. 내 농장에서 첫 농장을 등록해 주세요.</p>}<Link href="/starter/members">함께 보는 농장 · 초대 관리</Link></section>
 <section className="starter-card"><h2>다가오는 농작업</h2>{next.length?next.map(t=><p key={t.id}>{t.data.dueDate} · <Link href={`/starter/farms/${t.farmId}`}>{t.data.title}</Link></p>):<p>예정된 일정이 없습니다.</p>}</section>
 <section className="starter-card"><h2>최근 영농일지</h2>{data.entries.length?data.entries.map(e=><p key={e.id}>{e.workDate} · <Link href={`/starter/farms/${e.farmId}`}>{e.title}</Link></p>):<p>일지를 쓰면 여기에 모아서 보여 드립니다.</p>}</section>
 <section className="starter-card"><h2>센서 측정 상태</h2>{data.sensors.length?data.sensors.map(s=><p key={s.id}><Link href={`/starter/farms/${s.farmId}`}>{s.name}</Link> {s.simulated?'(시험 센서)':''} · {s.readings[0]?`${s.readings[0].value} / ${new Date(s.readings[0].measuredAt).toLocaleString('ko-KR')}`:'아직 측정값이 없습니다'}</p>):<p>등록된 센서가 없습니다. 측정값을 임의로 만들지 않습니다.</p>}</section>
 <section className="starter-card"><h2>재배 중인 작물</h2>{data.records.filter(r=>r.kind==='CROP').length?data.records.filter(r=>r.kind==='CROP').slice(0,10).map(c=><p key={c.id}>{c.data.name} · {c.data.variety} · {stages[c.data.stage]||c.data.stage}</p>):<p>작물의 심은 날과 수확 예정일을 농장 상세에서 등록해 주세요.</p>}</section>
 <section className="starter-card"><h2>최근 사진</h2><div className="farmer-photos">{data.photos.map(p=><PrivatePhoto key={p.id} fileId={p.fileId}/>)}</div>{!data.photos.length&&<p>영농일지에 사진을 등록하면 여기에 보입니다.</p>}</section></div>}
 {data&&<p>표시 한도: 최근 농장 {data.limits.farms}곳·작업/작물 {data.limits.records}건·센서 {data.limits.sensors}개. 전체 기록은 각 농장에서 확인하세요. 공유 농장은 별도 읽기 전용 화면입니다.</p>}</div>;
}
