import {FieldWorkbench} from '../_components/FieldWorkbench';
export default function DiaryPage(){return <FieldWorkbench mode="diary"/>;}
