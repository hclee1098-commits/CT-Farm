"use client";
import Link from 'next/link';
import {useAuth} from '../_lib/auth';
export default function MorePage(){const {user}=useAuth();return <div className="starter-container farmer-form"><h1>더보기</h1><p>필요한 기능을 골라 주세요.</p><div className="farmer-shortcuts">{[['/starter/account','내 정보 · 계정 보안'],['/starter/members','함께 보는 농장 · 구성원 초대'],['/starter/farms','센서 · 농사 상담 · 판매 · 주문'],['/starter/files','사진 · 파일 관리'],['/starter/notes','게시글'],['/docs-center/index.html','사용 설명서'],['/starter/admin','플랫폼 관리자']].filter(([url])=>url!=='/starter/admin'||user?.role==='ADMIN').map(([url,label])=><Link key={url} href={url}>{label}</Link>)}</div><p>센서·AI·판매는 해당 농장 상세에서 이용합니다. 관리자 권한은 서버에서 별도로 검사합니다.</p></div>;}
