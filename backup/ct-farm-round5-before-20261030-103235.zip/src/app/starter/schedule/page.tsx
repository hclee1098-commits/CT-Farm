import {FieldWorkbench} from '../_components/FieldWorkbench';
export default function SchedulePage(){return <FieldWorkbench mode="schedule"/>;}
