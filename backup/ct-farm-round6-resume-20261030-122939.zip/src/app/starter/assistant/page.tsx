"use client";
import {useEffect,useRef,useState} from 'react';
import Link from 'next/link';
import {useAuth} from '../_lib/auth';
import {getErrorMessage} from '../_lib/api';
import {DiaryPhotos} from '../farms/DiaryPhotos';
type Session={id:string;version:number;draft:{phase:string;question:string;action?:string;farmId?:string;resultId?:string}};
type Pending={version:number;requestId:string;text:string};
// 브라우저별 접두사 구현을 좁은 인터페이스로 격리합니다. 원본 오디오는 보관하지 않습니다.
type Recognition={lang:string;continuous:boolean;interimResults:boolean;start():void;abort():void;onresult:((e:{results:ArrayLike<ArrayLike<{transcript:string}>>})=>void)|null;onerror:((e:{error:string})=>void)|null;onend:(()=>void)|null};
export default function VoiceAssistant(){
 const {user,request}=useAuth();const [session,setSession]=useState<Session|null>(null),[text,setText]=useState(''),[heard,setHeard]=useState(''),[error,setError]=useState(''),[busy,setBusy]=useState(false),[listening,setListening]=useState(false),[consent,setConsent]=useState(false),[farms,setFarms]=useState<{id:string;name:string}[]>([]);
 const mic=useRef<Recognition|null>(null),pending=useRef<Pending|null>(null),inFlight=useRef(false),timer=useRef<ReturnType<typeof setTimeout>|null>(null);
 const storageKey=user?`ctfarm.field.v1:${encodeURIComponent(user.id)}:voice`:'';
 function speak(message:string){if(!('speechSynthesis'in window))return;window.speechSynthesis.cancel();const utterance=new SpeechSynthesisUtterance(message);utterance.lang='ko-KR';utterance.rate=.9;window.speechSynthesis.speak(utterance);}
 useEffect(()=>{let active=true;setSession(null);pending.current=null;setHeard('');setError('');if(!user)return;
  void request<{items:{id:string;name:string}[]}>('/farms?page=1').then(p=>{if(active)setFarms(p.items);}).catch(()=>{});
  try{const saved=JSON.parse(sessionStorage.getItem(storageKey)||'null');if(saved&&saved.expires>Date.now()&&/^[a-f0-9-]{36}$/.test(saved.id))void request<Session>(`/voice/sessions/${saved.id}`).then(s=>{if(active){setSession(s);pending.current=saved.pending??null;}}).catch(()=>{if(active)setError('前の');if(active)setError('前の会話');if(active)setError('이전 대화를 불러오지 못했습니다. 연결을 확인한 뒤 새로 시작해 주세요.');});}catch{}
  return()=>{active=false;mic.current?.abort();if(timer.current)clearTimeout(timer.current);window.speechSynthesis?.cancel();};
 },[user?.id,request,storageKey]);
 function remember(s:Session,p:Pending|null){try{if(['SAVED','CANCELLED'].includes(s.draft.phase))sessionStorage.removeItem(storageKey);else sessionStorage.setItem(storageKey,JSON.stringify({id:s.id,pending:p,expires:Date.now()+1800000}));}catch{setError('이 탭에 대화 재시도 정보를 보관하지 못했습니다. 화면을 닫기 전 결과를 확인해 주세요.');}}
 async function start(){if(inFlight.current)return;inFlight.current=true;setBusy(true);setError('');try{const s=await request<Session>('/voice/sessions',{method:'POST',body:'{}'});pending.current=null;setSession(s);remember(s,null);speak(s.draft.question);}catch(e){setError(getErrorMessage(e));}finally{inFlight.current=false;setBusy(false);}}
 async function send(value:string,retry=false){if(!session||inFlight.current||!value.trim())return;inFlight.current=true;setBusy(true);setError('');setHeard(value);
  if(!retry)pending.current={version:session.version,requestId:crypto.randomUUID(),text:value};const p=pending.current;if(!p){inFlight.current=false;setBusy(false);return;}remember(session,p);
  try{const s=await request<Session>(`/voice/sessions/${session.id}/turn`,{method:'POST',body:JSON.stringify(p)});pending.current=null;setSession(s);remember(s,null);setText('');speak(s.draft.question);}catch(e){setError(getErrorMessage(e)+' 대화와 재시도 요청을 남겼어요. 같은 요청 다시 보내기를 눌러 주세요.');}finally{inFlight.current=false;setBusy(false);}
 }
 function listen(){if(!consent){setError('음성 처리 안내에 동의한 뒤 말하기를 눌러 주세요.');return;}if(!window.isSecureContext){setError('마이크는 HTTPS 또는 이 기기의 localhost에서 사용해 주세요.');return;}if(window.speechSynthesis?.speaking){setError('안내 음성이 끝난 뒤 눌러 주세요. 안내 멈추기도 사용할 수 있어요.');return;}
  const Constructor=(window as unknown as {SpeechRecognition?:new()=>Recognition;webkitSpeechRecognition?:new()=>Recognition}).SpeechRecognition||(window as unknown as {webkitSpeechRecognition?:new()=>Recognition}).webkitSpeechRecognition;
  if(!Constructor){setError('이 브라우저는 음성 인식을 지원하지 않아요. 아래 큰 버튼이나 글 입력을 사용해 주세요.');return;}
  const r=new Constructor();mic.current=r;r.lang='ko-KR';r.continuous=false;r.interimResults=false;setListening(true);setError('');
  r.onresult=e=>{const result=e.results[0]?.[0]?.transcript;if(result)void send(result);};r.onerror=e=>setError(e.error==='not-allowed'?'마이크 사용이 거부됐어요. 브라우저 권한을 확인해 주세요.':e.error==='no-speech'?'말소리를 듣지 못했어요. 다시 눌러 주세요.':'음성 인식 연결을 완료하지 못했어요. 다시 눌러 주세요.');r.onend=()=>{setListening(false);if(timer.current)clearTimeout(timer.current);};timer.current=setTimeout(()=>{r.abort();setListening(false);},15000);try{r.start();}catch{r.abort();setListening(false);setError('마이크를 시작하지 못했어요. 다시 눌러 주세요.');}
 }
 if(!user)return <p><Link href="/starter/login">농장 비서를 쓰려면 로그인해 주세요.</Link></p>;
 return <div className="starter-container farmer-form"><h1>말로 하는 농장 비서</h1><p>오늘 한 일이나 물주기 일정을 말씀해 주세요. 저장 전 한 번 더 확인합니다.</p><p>브라우저가 음성을 외부 인식 서비스로 보낼 수 있습니다. CT-Farm은 원본 오디오를 녹음 파일로 저장하지 않습니다. 한국어 지원·처리 정책은 브라우저에 따라 다릅니다.</p><label><input type="checkbox" checked={consent} onChange={e=>setConsent(e.target.checked)}/>음성 처리 안내를 확인했습니다</label>
 {!session?<button onClick={()=>void start()} disabled={busy}>농장 비서 시작</button>:<><p role="status" aria-live="polite" style={{fontSize:'1.5rem'}}>{session.draft.question}</p><p>상태: {session.draft.phase==='SAVED'?'저장됨':session.draft.phase==='CONFIRM'?'저장 확인 필요':session.draft.phase==='CANCELLED'?'취소됨':'대화 중'}</p><p>들은 말: {heard||'아직 없습니다'}</p>{!['SAVED','CANCELLED'].includes(session.draft.phase)&&<><button onClick={listen} disabled={busy||listening||!consent} style={{minHeight:80,fontSize:'1.5rem'}}>{listening?'듣고 있어요…':'🎤 말하기'}</button><button onClick={()=>{mic.current?.abort();setListening(false);window.speechSynthesis?.cancel();}}>듣기·안내 멈추기</button><div>{(session.draft.phase==='CONFIRM'?['응','아니','취소']:['오늘 농약 쳤어','오늘 물 줬어','내일 물 주라고 알려줘','이름을 모르겠네','취소']).map(t=><button disabled={busy} key={t} onClick={()=>void send(t)}>{t}</button>)}</div>{farms.map(f=><button disabled={busy} key={f.id} onClick={()=>void send(f.name)}>{f.name}</button>)}<details><summary>말하기가 어려울 때 글로 답하기</summary><label>답변<input value={text} onChange={e=>setText(e.target.value)} maxLength={1000}/></label><button disabled={busy} onClick={()=>void send(text)}>답 보내기</button></details>{pending.current&&<button disabled={busy} onClick={()=>void send(pending.current!.text,true)}>같은 요청 다시 보내기</button>}</>}{['SAVED','CANCELLED'].includes(session.draft.phase)&&<button onClick={()=>void start()} disabled={busy}>새 작업 말하기</button>}{session.draft.phase==='SAVED'&&session.draft.action!=='SCHEDULE'&&session.draft.farmId&&session.draft.resultId&&<section><h2>사진으로 보완하기</h2><p>제품명은 사진만으로 자동 확정하지 않습니다.</p><DiaryPhotos farmId={session.draft.farmId} diaryId={session.draft.resultId}/></section>}{session.draft.farmId&&<Link href={`/starter/farms/${session.draft.farmId}`}>농장에서 저장한 내용 확인</Link>}</>}{error&&<p role="alert">{error}</p>}</div>;
}
