import {Router} from 'express';
import {randomUUID} from 'node:crypto';
import {z} from 'zod';
import {prisma} from '../../infrastructure/prisma';
import {redis,connectRedis} from '../../infrastructure/redis';
import {requireAuth} from '../../common/auth.middleware';
import {validate,asyncHandler,uuidSchema} from '../../common/validate';
import {AppError} from '../../common/app-error';
import {success} from '../../common/response';
import {lockFarm,audit} from './operations.service';
import {farmCreateOnce} from './farm-idempotency';
import {voiceTurn,voicePayload,koreanDate,type VoiceDraft} from './voice-dialogue';
export const voiceRouter=Router();voiceRouter.use(requireAuth);
type Session={id:string;version:number;today:string;draft:VoiceDraft;lastRequestId?:string};
const key=(user:string,id:string)=>`voice:v1:${user}:${id}`;
voiceRouter.post('/sessions',validate('body',z.object({}).strict()),asyncHandler(async(req,res)=>{await connectRedis();const session:Session={id:randomUUID(),version:0,today:koreanDate(),draft:{phase:'ASK',question:'무슨 작업을 하셨거나 알려 드릴까요?'}};await redis.set(key(req.userId!,session.id),JSON.stringify(session),{EX:1800});success(res,session,'대화를 시작합니다.',201);}));
voiceRouter.post('/sessions/:id/turn',validate('params',uuidSchema),validate('body',z.object({version:z.number().int().min(0),requestId:z.string().uuid(),text:z.string().trim().min(1).max(1000)}).strict()),asyncHandler(async(req,res)=>{
 await connectRedis();const sessionKey=key(req.userId!,req.params.id!),lease=randomUUID(),lock=sessionKey+':lock';
 if(!await redis.set(lock,lease,{NX:true,PX:60000}))throw new AppError(409,'VOICE_BUSY','앞선 말을 처리 중입니다. 잠시 후 다시 눌러 주세요.');
 try{
 const raw=await redis.get(sessionKey);if(!raw)throw new AppError(404,'VOICE_EXPIRED','대화가 만료되었습니다. 새로 시작해 주세요.');const session=JSON.parse(raw) as Session;
 if(session.lastRequestId===req.body.requestId){success(res,session);return;}
 if(session.version!==req.body.version)throw new AppError(409,'VOICE_VERSION','대화가 변경되었습니다. 새로 불러와 주세요.');
 const farms=await prisma.farm.findMany({where:{ownerId:req.userId!,deletedAt:null},select:{id:true,name:true,crop:true},take:500});
 session.draft=voiceTurn(session.draft,req.body.text,farms,session.today);
 if(session.draft.phase==='CONFIRMED'){
  const farm=farms.find(f=>f.id===session.draft.farmId);if(!farm)throw new AppError(404,'FARM_NOT_FOUND','접근할 수 없는 농장입니다.');const payload=voicePayload(session.draft,farm);
  const saved=await prisma.$transaction(async tx=>{await lockFarm(tx,req.userId!,farm.id);return farmCreateOnce(tx,`voice:${req.userId}`,session.id,payload,async()=>{
   if('kind' in payload){const item=await tx.farmRecord.create({data:{farmId:farm.id,kind:payload.kind,data:payload.data}});await audit(tx,req.userId!,'FARM_RECORD_CREATE',item.id);return {id:item.id};}
   const item=await tx.farmDiary.create({data:{farmId:farm.id,...payload}});await audit(tx,req.userId!,'DIARY_CREATE',item.id);return {id:item.id};
  });});session.draft={...session.draft,phase:'SAVED',resultId:(saved as {id:string}).id,question:session.draft.productUnknown?'저장했어요. 농약 이름·사용량·단위는 미확인으로 남겼어요.':'저장했어요.'};
 }
 session.version++;session.lastRequestId=req.body.requestId;
 const updated=await redis.eval('if redis.call("GET",KEYS[2])==ARGV[2] then redis.call("SET",KEYS[1],ARGV[1],"EX",1800); return 1 else return 0 end',{keys:[sessionKey,lock],arguments:[JSON.stringify(session),lease]});if(updated!==1)throw new AppError(409,'VOICE_RETRY','저장 결과 확인을 위해 같은 요청으로 다시 시도해 주세요.');success(res,session);
 }finally{await redis.eval('if redis.call("GET",KEYS[1])==ARGV[1] then return redis.call("DEL",KEYS[1]) else return 0 end',{keys:[lock],arguments:[lease]});}
}));
voiceRouter.get('/sessions/:id',validate('params',uuidSchema),asyncHandler(async(req,res)=>{await connectRedis();const raw=await redis.get(key(req.userId!,req.params.id!));if(!raw)throw new AppError(404,'VOICE_EXPIRED','대화가 만료되었습니다.');success(res,JSON.parse(raw));}));
