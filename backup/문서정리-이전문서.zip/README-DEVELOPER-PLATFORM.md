# 개발 플랫폼 확장본 안내

이 결과물은 전체 요구사항 완료본이 아닙니다. 실제 구현·검증 범위와 남은 작업을 [최종 검증 보고서](docs/testing/current-results.md)에 명시했습니다.

기존 서비스 설치는 [기존 안내](README-START-HERE.md), 추가한 로컬 개발자 플랫폼은 [실행 안내](docs/installation/developer-platform.md)를 따르세요. 기존 README/V6 보고서의 과거 성공 기록과 이번 결과를 구분하세요.

- `npm ci --ignore-scripts` → `npm run db:generate`
- 별도 `DEV_PORTAL_TOKEN` 설정 → `npm run dev:portal` → http://127.0.0.1:4310
- `npm run dev:api:observed`, `npm run dev:web:observed`로 선택형 로그 수집
- `npm run docs:index`, `npm run docs:check`, `npm run test:portal`, `npm run test:smtp`

개발 도구는 tools/에 분리했습니다. 임의 명령/SQL/원문 파일 읽기 기능은 제공하지 않습니다. 실제 .env, 비밀키, 운영 데이터는 포함하지 않습니다.
