# SECURE STARTER V6 · 6.0.0-rc.1

V5 텍스트 소스에서 복원하고 인증·MFA·관리자·데이터 복구·운영 도구를 확장한 검증 후보 버전입니다. 요청한 모든 기능이 완성된 운영 정식판은 아닙니다. 현재 완료/미구현/미검증은 [V6 보고서](docs/V6-REPORT.md)를 먼저 확인하세요.

## 시작

Windows PowerShell 5.1에서 프로젝트 루트로 이동합니다. Node.js 22 이상, Docker Desktop과 Compose가 필요합니다. 이 배포에는 EXE 바이너리가 없습니다. 첨부가 텍스트 소스이므로 기존 C# 소스와 빌드 스크립트를 제공합니다.

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\tools\build-launchers.ps1
.\SETUP.exe
.\STARTER.exe
.\STOP.exe
```

실행 파일을 만들기 전에도 같은 기능을 직접 실행할 수 있습니다.

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\SECURE-LIFECYCLE.ps1 -Action SETUP
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\SECURE-LIFECYCLE.ps1 -Action STARTER
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\SECURE-LIFECYCLE.ps1 -Action STOP
```

스크립트는 프로젝트 ID, Compose 라벨, PID 시작 시각·실행 경로를 확인하고 볼륨을 보존합니다. Windows에서 실제 설치·실행·종료를 검증한 것은 아닙니다. CT-Farm에 복사하거나 실행하지 말고 새 독립 폴더에서 시작하세요. 폴더 복제 시 기존 `.starter-state`, `.env`, 런타임 기록을 복사하지 않습니다. 기존 V5 프로젝트를 업그레이드할 때는 반대로 기존 ID와 데이터 볼륨을 그대로 유지해야 합니다.

## 기존 V5 업그레이드

1. 해당 프로젝트를 정상 종료하고 DB·업로드·환경설정·식별자를 별도로 백업합니다. 다른 프로젝트는 종료하지 않습니다.
2. 원본과 V6 소스를 비교해 병합합니다. 사용자 `.env`, `.starter-state`, 업로드를 덮어쓰지 않습니다. ZIP의 `backup/V5-source-before-changes.zip`은 제공받은 소스의 수정 전 복사본이며 사용자의 실제 DB 백업이 아닙니다.
3. `npm ci --ignore-scripts`, `npm run db:generate`, `npm run db:deploy`, `npm run build`를 실행합니다. API DB 환경설정은 `apps/api/.env`에 둡니다. V6 SQL은 추가형이며 사용자/노트/파일을 삭제하지 않습니다.
4. 기존 `.env`에 MFA 키가 없으면, 기존에 MFA 데이터를 사용하지 않은 V5 설치인지 확인한 뒤 `MFA_ENCRYPTION_KEY`를 32바이트 난수의 64자리 HEX로 추가합니다. 운영 중인 V6 키를 재생성하면 기존 MFA 비밀키를 복호화하지 못합니다. 키는 DB 백업과 함께 안전하게 별도 보관합니다.
5. 로그인·CRUD·파일 다운로드·휴지통 복구를 확인합니다. 문제가 생겨도 DB 초기화나 볼륨 삭제를 하지 않습니다. 롤백은 이전 앱 이미지/소스로 되돌리되 추가된 열과 데이터를 유지합니다.

## 최초 관리자

일반 회원가입 → `/starter/account`에서 MFA 등록 → 복구 코드 보관 → API 폴더에서 다음을 실행합니다. 첫 관리자가 이미 있으면 CLI는 거부합니다.

```powershell
Set-Location .\apps\api
$env:BOOTSTRAP_ADMIN_EMAIL = '등록한_회원_이메일'
npm run admin:bootstrap
Remove-Item Env:\BOOTSTRAP_ADMIN_EMAIL
```

MFA로 다시 로그인하면 `/starter/admin`을 사용할 수 있습니다. 각 관리자 API 요청에는 새로운 6자리 TOTP가 필요합니다. 관리자는 MFA를 해제하거나 자기 역할/정지 상태를 바꿀 수 없습니다. 추가 관리자는 이미 MFA가 등록된 활성 회원에 대해서만 지정합니다.

## 검증

```powershell
npm ci --ignore-scripts
npm run verify
npm run test:smoke
```

`npm run verify`는 소스 인코딩·잠금파일, Prisma 생성, 단위/HTTP 테스트, PGlite SQL 마이그레이션/복원, 백업 암호화, API/WEB 빌드와 npm audit을 수행합니다. Docker/Windows/외부 이메일 테스트까지 통과한 것으로 간주하지 않습니다.

실제 Redis와 Prisma 연결을 사용하는 추가 테스트는 별도 Redis 실행 파일 경로가 필요합니다. 테스트는 임시 포트/디렉터리와 WASM PostgreSQL을 사용합니다. 기존 DB URL이나 Redis에 연결하지 않습니다.

```powershell
$env:REDIS_SERVER_BIN = '테스트용_redis-server.exe_절대경로'
npm run test:platform
npm run test:mail
```

Windows용 Redis 실행 파일은 이 소스에 포함하지 않습니다. Linux에서는 별도 설치한 `redis-server` 경로를 지정할 수 있습니다. WASM PostgreSQL은 네이티브 PostgreSQL의 동시성과 장애 동작을 완전히 재현하지 않습니다.

메일은 `MailTransport` 인터페이스와 메모리 테스트 구현만 제공합니다. 실제 서비스를 연결하려면 서버 시작 전에 `configureMailTransport()`에 구현체를 등록하세요. 기본값은 발송이 아닌 503 오류입니다.

[API 규칙](docs/API.md) · [운영 배포](docs/OPERATIONS.md) · [보안 검토](docs/SECURITY.md) · [Windows 확인표](docs/WINDOWS.md)
