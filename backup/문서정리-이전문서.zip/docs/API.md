# API 공통 규칙

기본 경로: `/api/v1`. 성공은 `{success:true,data,message}`, 실패는 `{success:false,errorCode,message}`입니다. 요청 식별자는 `X-Request-ID` 응답 헤더를 확인합니다. 오류 본문에 내부 오류 원문을 반환하지 않습니다.

`docs/openapi.json`은 경로 목록과 주요 요청 형식을 제공합니다. 모든 DTO를 완전히 모델링한 계약 문서는 아니며, 파일 다운로드/썸네일 응답은 바이너리입니다. 웹 인증 POST는 허용 Origin이 필요하고 Refresh Token은 HttpOnly 쿠키로만 전달합니다. 모바일 API는 JSON Refresh Token을 사용합니다.

- 게시글 생성: `POST /notes`, JSON `{title,content}`. 선택적으로 `Idempotency-Key`에 16~128자 영숫자/밑줄/하이픈을 전송합니다. 같은 사용자·키·본문은 동일 자원 응답을 반환하고 다른 본문은 409입니다. 키는 자동 만료하지 않습니다.
- 게시글 PUT/PATCH: 선택 필드 `version`을 전달하면 낙관적 잠금을 적용합니다. 충돌 시 409, 최신 데이터 재조회 후 사용자의 의도를 확인하세요. 기존 클라이언트 호환을 위해 생략도 허용합니다.
- `DELETE /notes/:id`와 `DELETE /files/:id`는 V6에서 휴지통 이동입니다. `/notes/trash`, `/files/trash`로 조회하고 `POST /notes/:id/restore`, `POST /files/:id/restore`로 복구합니다. 파일 삭제 응답 데이터는 `{count:1}`입니다. 영구 삭제는 자동 수행하지 않습니다.
- 파일 업로드는 `POST /files` multipart 필드 `file`, 다중 업로드는 `POST /files/batch` 필드 `files` 최대 5개입니다. 파일당 5MiB, 배치 최대 25MiB를 메모리에 사용하므로 동시 접속 수에 맞는 인프라 제한이 필요합니다. 배치는 207 응답이며 파일별 독립 성공/실패를 확인해야 합니다.
- 업로드한 이미지는 최대 40MP 입력, 최대 4096×4096 보존 비율로 재인코딩하고 EXIF를 제거합니다. PDF는 기존 시그니처 검사만 적용하며 악성코드 검사 기능은 없습니다. SHA-256은 재인코딩된 실제 저장 파일 기준입니다. 중복 검사는 사용자별이며 동시에 들어온 중복 업로드에 대한 DB 유일성 보장은 없습니다.
- `GET /files/:id/thumbnail`: 소유권 검사 후 320×320 범위 WebP 썸네일 생성. 공개 URL은 발급하지 않습니다.
- MFA 등록: 비밀번호 재인증 후 `/account/mfa/setup`, 10분 내 `/account/mfa/enable`에 `{code}` 전송. 등록 시 모든 세션이 폐기됩니다. 반환된 복구 코드는 한 번만 표시됩니다.
- 로그인 JSON에 선택적으로 `mfaCode`를 추가합니다. 6자리 TOTP 또는 32자리 HEX 복구 코드입니다. 복구 코드는 1회용입니다. 관리자는 로그인 후에도 각 관리자 API 요청에 새 `X-MFA-Code`가 필요하며 관리자 재인증에는 복구 코드를 사용할 수 없습니다.
- `/account/password/change`: `{password,newPassword,mfaCode?}`. `/account/withdraw`: `{password,mfaCode?}`. 탈퇴는 논리적 잠금이며 데이터/이메일을 자동 삭제하거나 재사용하지 않습니다.
- `/account/sessions/:id` DELETE는 해당 Refresh Token과 모든 Access Token을 폐기합니다. 다른 기기는 Refresh Token으로 새 Access Token을 발급받을 수 있습니다. V5 JWT에 세션 ID가 없기 때문에 생기는 의도된 호환성 정책입니다.
- 메일 인터페이스: `/account/email/request`에 `{email,kind:'VERIFY'|'RESET'}`, `/account/email/verify`에 `{token}`, `/account/password/reset`에 `{token,newPassword}`. 메일 전송 어댑터 미설정 시 503입니다. Mock이 실제 발송으로 표시되지 않습니다. MFA는 비밀번호 재설정으로 해제되지 않습니다.

이메일 변경·30일 내 계정 복구 API는 제공하며 해당 UI, 범용 역할/권한 편집, 전체 개인정보 대용량 내보내기는 미구현입니다. 내보내기는 범주별 최대 1000개 제한을 명시합니다. 관리자/보안 이력은 최근 100개, 휴지통도 최근 100개이며 범용 커서 페이지네이션은 후속 구현 대상입니다.
