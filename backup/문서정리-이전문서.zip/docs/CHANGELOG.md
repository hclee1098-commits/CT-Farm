# V5 → V6 변경 내역

버전 6.0.0-rc.1. 완료 판정과 미구현/미검증은 V6-REPORT.md를 확인하세요.

## 주요 변경

- 기존 인증을 유지하며 Refresh Token 재사용 전체 세션 폐기, 계정별 잠금, 인증 중 계정 버전 경합 검사를 추가했습니다.
- 암호화된 TOTP MFA, 1회용 복구 코드, 관리자 재인증과 최초 관리자 CLI를 추가했습니다.
- 이메일 인증/변경/재설정, 프로필/알림 설정, 세션 관리, 탈퇴/복구 API 및 메일 Mock을 추가했습니다.
- USER/ADMIN 권한, 계정 정지/해제, 감사 이력/알림, 관리자·계정·알림 화면을 추가했습니다.
- 노트/파일 삭제는 휴지통 이동으로 변경했고 복구 API를 추가했습니다. 노트 수정은 version을 전달하면 충돌을 검사합니다.
- 파일 SHA-256, 중복 확인, 이미지 디코딩/EXIF 제거/크기 제한/썸네일, 배치 업로드, 읽기 전용 정합성 검사를 추가했습니다.
- 노트 생성에 선택적 Idempotency-Key, 부분 OpenAPI 문서, 재사용 UI 보강을 추가했습니다.
- 암호화 백업/격리 복원 CLI, 운영 Docker/Caddy/마이그레이션 이미지, CI 소스 검증을 추가했습니다.
- 원본 런처 구조를 유지하고 신규 설치 MFA 키 생성을 추가했습니다. PS1은 BOM/CRLF로 저장했습니다.
- 기존 테스트 설정을 복원하고 MFA·권한·이미지·업로드 실패·SQL/Prisma/Redis/메일 통합 테스트를 추가했습니다.

## 호환성 영향

- 파일 DELETE는 영구 삭제가 아닌 휴지통 이동이며 응답 데이터는 count입니다.
- MFA 등록/변경 및 비밀번호/이메일 변경은 다시 로그인이 필요합니다.
- 현재 기기 로그아웃/세션 폐기는 다른 기기의 Access Token도 무효화할 수 있습니다. 다른 기기의 유효 Refresh Token은 유지됩니다.
- 재사용 토큰 감지 시 모든 기기가 다시 로그인해야 합니다.
- Compose ID가 없는 수동 실행은 실패합니다. 기존 SETUP 식별자를 유지해야 합니다.
- 신규 API/필드는 추가형이며 기존 노트 수정에 version은 필수가 아닙니다.

## 파일별 목록

| 상태 | 경로 |
|---|---|
| 추가 | `.dockerignore` |
| 추가 | `.github/workflows/verify.yml` |
| 수정 | `.gitignore` |
| 수정 | `README-START-HERE.md` |
| 추가 | `README.md` |
| 수정 | `SECURE STARTER 사용설명서.md` |
| 수정 | `SECURE-LIFECYCLE.ps1` |
| 수정 | `SECURE-TEST.ps1` |
| 수정 | `SECURITY-REVISION.json` |
| 수정 | `apps/api/.env.example` |
| 수정 | `apps/api/package.json` |
| 추가 | `apps/api/prisma/migrations/20261028180000_v6_security/migration.sql` |
| 수정 | `apps/api/prisma/schema.prisma` |
| 수정 | `apps/api/src/bootstrap/app.http.test.ts` |
| 수정 | `apps/api/src/bootstrap/app.ts` |
| 수정 | `apps/api/src/common/auth.middleware.ts` |
| 수정 | `apps/api/src/config/env.schema.ts` |
| 수정 | `apps/api/src/infrastructure/logger.ts` |
| 수정 | `apps/api/src/infrastructure/rate-limit.ts` |
| 수정 | `apps/api/src/modules/auth/auth.dto.ts` |
| 수정 | `apps/api/src/modules/auth/auth.repository.ts` |
| 수정 | `apps/api/src/modules/auth/auth.service.ts` |
| 수정 | `apps/api/src/modules/auth/auth.session-version.test.ts` |
| 추가 | `apps/api/src/modules/auth/mfa.test.ts` |
| 추가 | `apps/api/src/modules/auth/mfa.ts` |
| 수정 | `apps/api/src/modules/files/files.controller.ts` |
| 수정 | `apps/api/src/modules/files/files.repository.ts` |
| 수정 | `apps/api/src/modules/files/files.service.ts` |
| 추가 | `apps/api/src/modules/files/files.upload.test.ts` |
| 추가 | `apps/api/src/modules/files/image.processing.test.ts` |
| 추가 | `apps/api/src/modules/files/image.processing.ts` |
| 수정 | `apps/api/src/modules/notes/notes.controller.ts` |
| 수정 | `apps/api/src/modules/notes/notes.dto.ts` |
| 추가 | `apps/api/src/modules/notes/notes.idempotency.ts` |
| 수정 | `apps/api/src/modules/notes/notes.repository.ts` |
| 추가 | `apps/api/src/modules/platform/account.service.ts` |
| 추가 | `apps/api/src/modules/platform/admin.controller.ts` |
| 추가 | `apps/api/src/modules/platform/mail.ts` |
| 추가 | `apps/api/src/modules/platform/platform.controller.ts` |
| 추가 | `apps/api/vitest.config.mts` |
| 수정 | `apps/web/next.config.ts` |
| 수정 | `apps/web/package.json` |
| 수정 | `apps/web/src/app/starter/_components/Shell.tsx` |
| 추가 | `apps/web/src/app/starter/account/page.tsx` |
| 추가 | `apps/web/src/app/starter/admin/page.tsx` |
| 수정 | `apps/web/src/app/starter/login/page.tsx` |
| 추가 | `apps/web/src/app/starter/notifications/page.tsx` |
| 수정 | `apps/web/src/shared/auth/auth-client.ts` |
| 수정 | `apps/web/src/shared/auth/auth-provider.tsx` |
| 수정 | `apps/web/src/shared/ui/index.tsx` |
| 수정 | `apps/web/src/shared/ui/ui.css` |
| 추가 | `apps/web/src/shared/ui/ui.test.tsx` |
| 추가 | `apps/web/vitest.config.mts` |
| 추가 | `compose.production.yaml` |
| 수정 | `compose.yaml` |
| 수정 | `create-starter-ps1-shell-script/create-starter-part10.ps1` |
| 수정 | `create-starter-ps1-shell-script/create-starter-part11.ps1` |
| 수정 | `create-starter-ps1-shell-script/create-starter-part2.ps1` |
| 수정 | `create-starter-ps1-shell-script/create-starter-part3.ps1` |
| 수정 | `create-starter-ps1-shell-script/create-starter-part4.ps1` |
| 수정 | `create-starter-ps1-shell-script/create-starter-part5.ps1` |
| 수정 | `create-starter-ps1-shell-script/create-starter-part6.ps1` |
| 수정 | `create-starter-ps1-shell-script/create-starter-part7.ps1` |
| 수정 | `create-starter-ps1-shell-script/create-starter-part8.ps1` |
| 수정 | `create-starter-ps1-shell-script/create-starter-part9.ps1` |
| 수정 | `create-starter-ps1-shell-script/create-starter.ps1` |
| 수정 | `create-starter-ps1-shell-script/repair-starter-part8.ps1` |
| 추가 | `deploy/Caddyfile` |
| 추가 | `deploy/Dockerfile.api` |
| 추가 | `deploy/Dockerfile.migrate` |
| 추가 | `deploy/Dockerfile.web` |
| 추가 | `deploy/production.env.example` |
| 추가 | `docs/API.md` |
| 추가 | `docs/OPERATIONS.md` |
| 추가 | `docs/SECURITY.md` |
| 추가 | `docs/V6-REPORT.md` |
| 추가 | `docs/WINDOWS.md` |
| 추가 | `docs/openapi.json` |
| 수정 | `package-lock.json` |
| 수정 | `package.json` |
| 추가 | `tools/backup.mjs` |
| 추가 | `tools/bootstrap-admin.ts` |
| 수정 | `tools/build-launchers.ps1` |
| 추가 | `tools/check-files.ts` |
| 추가 | `tools/license-inventory.mjs` |
| 수정 | `tools/smoke-web.mjs` |
| 추가 | `tools/test-backup.mjs` |
| 추가 | `tools/test-mail.mts` |
| 추가 | `tools/test-migrations.mjs` |
| 추가 | `tools/test-platform.mjs` |
| 수정 | `tools/verify-powershell.ps1` |
| 수정 | `tools/verify-starter.ps1` |
| 수정 | `검증결과.md` |
