# 운영 배포·백업·복원

## 운영 배포

`compose.production.yaml`은 개발 Compose와 별도입니다. PostgreSQL/Redis 포트를 호스트에 공개하지 않고 Caddy가 HTTPS를 종료합니다. API/WEB은 비관리자 사용자, 읽기 전용 루트, 권한 제거 옵션을 사용합니다. DB/캐시 이미지는 초기화에 필요한 권한을 유지하며 외부 공유 볼륨을 사용하지 않습니다.

이 환경에는 Docker가 없어 이미지 빌드·Compose 실행·TLS 발급은 검증하지 못했습니다. 운영에 올리기 전에 격리 서버에서 확인해야 합니다. 이미지는 릴리스 전에 신뢰할 수 있는 digest로 고정하고 검사하세요. 현재 태그는 digest 고정이 아닙니다.

1. `deploy/production.env.example`을 비공개 `deploy/production.env`로 복사하고 모든 예시 값을 교체합니다. `COMPOSE_PROJECT_NAME`은 프로젝트마다 달라야 합니다. PostgreSQL URL의 비밀번호는 URL 인코딩합니다.
2. 도메인 DNS와 80/443 포트, 방화벽을 설정합니다. 이 프로젝트 외의 Compose ID를 사용하지 않습니다.
3. 다음 명령은 환경을 준비한 사람이 해당 프로젝트 폴더에서 직접 수행합니다.

```powershell
docker compose --env-file deploy/production.env -f compose.production.yaml config --quiet
docker compose --env-file deploy/production.env -f compose.production.yaml up -d postgres redis
docker compose --env-file deploy/production.env -f compose.production.yaml --profile tools run --rm migrate
docker compose --env-file deploy/production.env -f compose.production.yaml up -d --build api web proxy
```

4. `/health/live`, `/health/ready`, 웹 로그인, 관리자 MFA, 파일 접근을 확인합니다. 프록시에는 `X-Forwarded-For`를 신뢰할 수 있는 위치가 한 개일 때만 `TRUST_PROXY_HOPS=1`을 사용합니다. API를 직접 외부에 노출하지 않습니다.
5. 종료는 동일 env/Compose 파일로 `stop`만 수행합니다. 볼륨 삭제·전역 prune·다른 프로젝트 종료를 수행하지 않습니다.
6. 롤백은 이전에 보관한 API/WEB 이미지로 전환하고 DB의 추가 열은 보존합니다. 이미지를 덮어쓰기 전에 배포 단위별 이미지 ID/digest를 따로 기록해야 합니다. 자동 롤백 컨트롤러는 없습니다.

## 암호화 백업

`tools/backup.mjs`는 pg_dump custom archive와 업로드를 AES-256-GCM으로 암호화합니다. 개별 SHA-256, 프로젝트 ID, 아카이브 형식을 확인합니다. 인증정보는 명령행 인수나 로그에 출력하지 않습니다. PostgreSQL 도구는 DB와 같은 메이저 버전의 pg_dump/pg_restore/psql을 별도 설치합니다.

- API/작업자를 정상 정지해 파일과 DB 변경을 멈춘 뒤 실행합니다. `BACKUP_QUIESCED=1`은 운영자의 확인 표시이며 도구가 다른 서비스를 자동 종료하는 기능이 아닙니다.
- 기존 환경파일은 Node 22의 `--env-file`로 읽을 수 있습니다. `BACKUP_KEY`는 환경파일에 넣지 않고 별도 비밀 관리 수단으로 주입합니다. DB 백업과 암호화키를 한 위치에 보관하지 않습니다.
- 이 도구는 소규모 스타터용으로 원본 총 128MiB/파일 최대 10000개를 제한하며 전체를 메모리에서 처리합니다. 더 큰 데이터는 스트리밍 백업 모듈로 교체해야 합니다. 로컬 플랫 파일 저장소만 지원합니다.

```powershell
# 프로젝트 루트 기준. 비밀값은 실제 환경에서 별도 주입합니다.
$env:BACKUP_PROJECT = '현재_실제_Compose_ID'
$env:BACKUP_DIR = '백업_저장_절대경로'
$env:UPLOAD_DIR = '업로드_절대경로'
$env:BACKUP_QUIESCED = '1'
node --env-file=apps/api/.env tools/backup.mjs create
node tools/backup.mjs list
node tools/backup.mjs verify '백업파일_절대경로'
```

자동화할 때는 위 백업 명령을 Windows 작업 스케줄러나 운영 스케줄러에서 실행하고 종료 코드가 0이 아니면 알림 어댑터를 호출해야 합니다. 자동 일정 등록·보관기간 삭제·외부 실패 알림은 아직 구현하지 않았습니다. 기본 도구는 기존 백업을 덮어쓰거나 삭제하지 않습니다.

## 격리 복원

운영 DB 직접 복원 기능은 제공하지 않습니다. 운영 상태를 덮어쓰는 작업은 별도 검토가 필요합니다. 다음 절차로 비어 있는 새 테스트 DB와 존재하지 않는 업로드 디렉터리에만 복원합니다.

1. 별도 테스트 인스턴스에 `starter_restore_<12자리 HEX>` 형식의 새 빈 DB를 준비합니다. 기존 DB를 삭제해서 만들지 않습니다.
2. `RESTORE_DATABASE_URL`, `RESTORE_UPLOAD_DIR`, `BACKUP_PROJECT`, `BACKUP_KEY`를 지정합니다.
3. `node tools/backup.mjs restore-isolated '백업파일'`을 실행합니다. 대상에 기존 테이블/시퀀스가 있거나 업로드 경로가 존재하면 거부합니다. pg_restore는 단일 트랜잭션으로 수행합니다.
4. 프로젝트에 맞게 행 수·참조 무결성·MFA 키·로그인·파일 해시와 다운로드를 확인합니다. 도구의 `SELECT 1` 성공만으로 복원 완료 판정을 하지 않습니다.
5. 파일 쓰기 단계에 실패하면 DB 복원은 완료돼 있을 수 있습니다. 실패한 격리 환경을 그대로 보관하여 조사하고, 다른 새 빈 테스트 DB/경로로 재시도합니다. 자동 삭제나 운영 덮어쓰기를 수행하지 않습니다.

검증한 것은 암호화/변조 방지 단위 테스트와 WASM PostgreSQL 스냅샷 복원입니다. pg_dump/pg_restore를 이용한 네이티브 백업·복원은 미검증입니다.

## 관측과 정합성

API는 구조화된 로그, 요청 UUID, liveness/readiness, DB/Redis 상태, 정상 종료를 제공합니다. 관리자 대시보드는 사용자 수·파일 용량·최근 감사 이벤트·메모리·업타임을 조회합니다. 백업 상태와 작업 큐 항목은 실제 측정값 대신 미설정 상태를 명시합니다. 외부 로그 수집/보관 정책·장애 알림 연동은 운영자가 구성해야 합니다.

API 폴더에서 `npm run files:check`를 실행하면 DB와 파일의 누락·변조·레거시 해시 누락·고아 개수를 읽기 전용으로 검사합니다. 파일을 자동 삭제하거나 레거시 행의 해시를 덮어쓰지 않습니다. 휴지통은 자동 영구 삭제하지 않으므로 용량 관리와 법적 보존 정책을 서비스별로 설정해야 합니다.
