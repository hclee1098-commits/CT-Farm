# SECURE STARTER 통합 문서센터

이 문서는 입력 V6 rc1과 이번 개발 플랫폼 확장을 구분합니다. **전체 요구사항 완료본이 아닙니다.** 최종 검증 상태는 [이번 결과](testing/current-results.md)를 확인하세요. 기존 V6-REPORT 및 verification 기록은 첨부본의 과거 결과입니다.

- [개발 플랫폼 설치와 실행](installation/developer-platform.md)
- [시스템 구조와 보안 경계](architecture/developer-platform.md)
- [주요 실행 흐름과 코드 연결](workflows/code-flows.md)
- [이메일 운영](operations/email.md)
- [파일 색인](files/generated-index.md)
- [보안 변경과 남은 위험](security/platform-review.md)
- [기존 API 문서](API.md), [OpenAPI](openapi.json)
- [기존 Windows 안내](WINDOWS.md), [기존 운영 안내](OPERATIONS.md)

`npm run analyze`는 허용된 파일의 메타데이터를 재생성합니다. `npm run docs:index`는 색인과 스냅샷을 갱신하며, `npm run docs:check`는 스냅샷의 파일 해시/경로/정적 참조와 문서 링크를 검증합니다. 의미상의 설명과 코드 동작 일치는 수동 리뷰가 필요합니다.
