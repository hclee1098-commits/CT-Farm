# V6 보안 검토

## 보호 대상과 위협

보호 대상은 비밀번호 해시, 인증 세션, MFA 비밀키, 사용자별 게시글/파일, 관리자 권한, DB/업로드/백업, 프로젝트 소유권입니다. 공격자는 비인증 사용자, 다른 일반 회원, 탈취한 Refresh Token/Access Token 사용자, 악성 업로드 제공자, 허용되지 않은 웹 출처, 잘못된 프로젝트 ID를 사용하는 로컬 운영자를 가정합니다. 호스트 관리자 권한 탈취와 Docker 엔진 자체 침해는 이 앱만으로 방어하지 못합니다.

| 경로/위험 | 구현과 검증 | 남은 한계 |
|---|---|---|
| JWT 위조·만료·전체 로그아웃 우회 | HS256/issuer/audience/exp/iat/정수 버전 검사, DB 버전 확인 | V5 JWT 형식 호환을 위해 세션별 Access Token ID 없음 |
| Refresh Token 탈취·재사용 | 원문 미저장, SHA-256, 회원 행 잠금 후 원자적 회전, 재사용 시 전체 버전 증가와 세션 폐기 | 정상 클라이언트의 중복 갱신도 강제 로그아웃할 수 있음. 여러 탭의 갱신 조정 개선 필요 |
| 비밀번호 변경과 로그인 경합 | 로그인 당시 버전을 세션 생성 잠금 안에서 다시 비교 | 네이티브 PostgreSQL 병렬 부하 검증은 별도 |
| 비밀번호 대입 | bcrypt 12, 유효하지 않은 계정도 더미 해시 비교, Redis IP 제한, 계정별 5회 실패 시 15분 잠금 | 원격 분산 공격/알림 연동은 별도 검토 |
| MFA 탈취·재사용 | TOTP, 허용 시간 범위 ±1구간, 조건부 갱신으로 OTP 재사용 차단, 복구 코드 해시 1회 소비, AES-GCM 및 사용자 AAD, 10분 등록 기한 | 키 회전 자동화와 분실 시 운영 복구 절차 미구현 |
| 관리자 권한 상승 | 서버 role 검사, DB 역할 CHECK, 각 API에 새 TOTP 요구, 자기 역할/정지 변경 거부, MFA 없는 계정 승격 금지, 최초 관리자 CLI 직렬 잠금 | 사용자 정의 역할/권한 정책 편집은 미구현 |
| 수평 접근 | 노트/파일/세션/알림 DB 조건에 현재 사용자 ID 결합 | 새 서비스 고유 API에도 같은 원칙을 적용해야 함 |
| CSRF·CORS | 웹 쿠키 인증 POST Origin 검증, SameSite Strict·HttpOnly·운영 Secure/__Host 쿠키 | 모바일 토큰은 호출 앱에서 안전하게 보관해야 함 |
| XSS·출력 | React 기본 이스케이프, API/WEB 보안 헤더, 다운로드 접근 통제 | 웹 CSP는 기존 object/base/frame 차단 수준으로 엄격한 script nonce 정책은 미구현 |
| SQL/NoSQL 입력 | 엄격한 Zod DTO, 허용 필드 정렬, Prisma 조건식, 매개변수화한 raw SQL | NoSQL 저장소/임의 URL 요청 기능 자체가 없음 |
| 파일 위장·경로 탐색 | 허용 MIME/확장자/시그니처, 이미지 전체 디코딩, 40MP 제한, 재인코딩·EXIF 제거, UUID 키·심볼릭 링크 검사 | PDF 악성코드 검사 없음. 이미지도 모든 악성 파일 위험을 제거한다고 보장하지 않음 |
| 파일/DB 불일치 | 저장 후 DB 실패 시 정리, 기존 삭제 저널 복구 유지, V6 삭제는 휴지통, 읽기 전용 해시 정합성 도구 | 배치 업로드는 파일별 독립 처리. 중복 업로드 경합·완전한 저장소 할당량은 미구현 |
| 로그 비밀정보 | 요청 본문/쿠키/쿼리 미기록, 오류 상세 생략, 민감 필드 마스킹 | 외부 수집기의 보관기간·권한 설정은 별도 |
| 백업 탈취·변조 | AES-256-GCM, 개별 SHA-256, 프로젝트 ID, 경로/크기/중복 검사 | 네이티브 pg_dump/pg_restore 운영 검증, 자동 보관/실패 알림 미구현 |
| 프로젝트 오조작 | Compose 고유 ID 필수, 기존 라벨/프로세스 시작시각/경로 검사 유지, 볼륨 보존 | Windows 두 프로젝트 동시 실행은 실기 검증 필요 |

## 개인정보·보존

세션에 상세 기기 지문·IP 원문을 추가하지 않습니다. 로그인/민감 작업 이력에는 사용자 ID·행동 코드·시각만 저장합니다. 탈퇴 시 계정 접근을 막고 데이터는 보존하며 비밀번호와 MFA로 30일 내 복구할 수 있습니다. 30일 경과 후 데이터의 자동 파기는 하지 않습니다. 실제 서비스의 보존/파기/다운로드 범위 정책을 확정해야 합니다. 기본 내보내기는 각 범주 최대 1000개이며 파일 내용 대신 메타데이터만 포함합니다.

## 의존성과 공급망

제공받은 잠금 파일을 유지하며 PGlite/PGlite socket 테스트 도구 및 Sharp를 목적에 맞게 추가했습니다. 설치는 lifecycle script를 끈 `npm ci --ignore-scripts`로 재현하고 Prisma 생성은 명시적으로 실행합니다. lockfile의 integrity 정보와 `npm audit` 결과를 첨부합니다. 취약점 데이터베이스의 조회 시점에 한정된 결과이며 알려지지 않은 취약점이 없다는 뜻은 아닙니다.

원본의 `deepmerge-ts:8.0.2` override는 유지했습니다. Prisma 설정 패키지는 7.1.5를 선언하므로 npm의 표준 SBOM 명령이 이를 invalid로 판단했습니다. 그래서 완전한 CycloneDX SBOM을 제공하지 못하며 설치된 패키지의 라이선스 메타데이터 목록을 대체 제공합니다. 실제 빌드·Prisma 생성·migrate deploy·schema diff는 통과 여부를 별도로 기록합니다. override의 업스트림 호환성·라이선스 원문·운영 이미지 취약점은 추가 검토 대상입니다.

## 설계 참고

- [RFC 9700 §4.14 Refresh Token 보안](https://www.rfc-editor.org/rfc/rfc9700.html#section-4.14)
- [OWASP MFA Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Multifactor_Authentication_Cheat_Sheet.html)
- [OWASP 비밀번호 재설정](https://cheatsheetseries.owasp.org/cheatsheets/Forgot_Password_Cheat_Sheet.html)

이 문서는 침투 테스트 인증서 또는 운영 보안 승인서가 아닙니다. 실행한 테스트와 수행하지 못한 검증은 V6 보고서에서 구분합니다.
