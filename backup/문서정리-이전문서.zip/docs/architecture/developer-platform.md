# 실제 코드 기반 시스템 구조

수동 작성 다이어그램입니다. 정적 import 탐색은 포털에서 별도로 생성합니다.

```mermaid
flowchart TD
  B[일반 사용자 브라우저] --> W[Next.js WEB]
  B --> A[Express API]
  A --> P[Prisma / PostgreSQL]
  A --> R[Redis 요청 제한·세션 잠금]
  A --> F[로컬 파일 저장소]
  A --> M[선택형 SMTP]
  D[로컬 개발자] --> L[독립 Node 포털]
  L --> S[허용된 분석 메타데이터]
  L --> E[고정 경로의 안전 이벤트]
```

포털 서버에는 DB 접속 기능, 원격 URL fetch, shell, SQL, 임의 파일 읽기 API가 없습니다. Dockerfile.api는 apps/api만, Dockerfile.web는 apps/web만 복사합니다. `tools/dev-portal`과 `analysis`는 해당 운영 이미지 COPY 대상에 포함되지 않습니다. 실제 Docker 이미지의 내용 검증은 Docker 부재로 미검증입니다.

포털 그래프는 TypeScript 정적 import 중 최대 36개를 표시합니다. 검색/확대/스크롤/키보드 노드 선택을 제공합니다. 설정 기반 실행, C#→PowerShell, DB 외래키, Redis 키 관계와 함수 호출 순서 전체를 자동으로 복원하지 않습니다. 요청된 16종 전용 아키텍처 맵과 22종 프로세스의 전체 조건 분기 시각화는 미완성입니다.
