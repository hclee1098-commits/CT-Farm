# 자동 파일 색인

AST/정규식 정적 분석입니다. 사용되지 않음/삭제 가능을 확정하지 않습니다. 포털에서 함수·Props·참조와 줄 번호를 확인하세요.

| 파일 | 역할 | 정적 참조 수 | 삭제 분류 |
|---|---|---:|---|
| [.dockerignore](../../.dockerignore) | 소스/설정 파일 | 0 | B: 추가 검증 필요 |
| [.editorconfig](../../.editorconfig) | 소스/설정 파일 | 0 | B: 추가 검증 필요 |
| [.env.example](../../.env.example) | 소스/설정 파일 | 0 | C: 보존 |
| [.github/workflows/verify.yml](../../.github/workflows/verify.yml) | 소스/설정 파일 | 0 | B: 추가 검증 필요 |
| [.gitignore](../../.gitignore) | 소스/설정 파일 | 0 | B: 추가 검증 필요 |
| [README-DEVELOPER-PLATFORM.md](../../README-DEVELOPER-PLATFORM.md) | 문서 파일 | 0 | B: 추가 검증 필요 |
| [README-START-HERE.md](../../README-START-HERE.md) | 문서 파일 | 0 | B: 추가 검증 필요 |
| [README.md](../../README.md) | 문서 파일 | 0 | B: 추가 검증 필요 |
| [SECURE STARTER 사용설명서.md](../../SECURE%20STARTER%20사용설명서.md) | 문서 파일 | 0 | B: 추가 검증 필요 |
| [SECURE-LIFECYCLE.ps1](../../SECURE-LIFECYCLE.ps1) | Windows 설치·실행 자동화 파일 | 0 | C: 보존 |
| [SECURE-TEST.ps1](../../SECURE-TEST.ps1) | Windows 설치·실행 자동화 파일 | 0 | B: 추가 검증 필요 |
| [SECURITY-REVISION.json](../../SECURITY-REVISION.json) | 설정 또는 구조화 데이터 파일 | 0 | B: 추가 검증 필요 |
| [apps/api/.env.example](../../apps/api/.env.example) | 소스/설정 파일 | 0 | C: 보존 |
| [apps/api/package.json](../../apps/api/package.json) | 설정 또는 구조화 데이터 파일 | 0 | B: 추가 검증 필요 |
| [apps/api/prisma/migrations/20261026153448_init/migration.sql](../../apps/api/prisma/migrations/20261026153448_init/migration.sql) | DB 마이그레이션 파일 | 0 | C: 보존 |
| [apps/api/prisma/migrations/20261028180000_v6_security/migration.sql](../../apps/api/prisma/migrations/20261028180000_v6_security/migration.sql) | DB 마이그레이션 파일 | 0 | C: 보존 |
| [apps/api/prisma/migrations/migration_lock.toml](../../apps/api/prisma/migrations/migration_lock.toml) | 소스/설정 파일 | 0 | C: 보존 |
| [apps/api/prisma/schema.prisma](../../apps/api/prisma/schema.prisma) | 데이터 모델 파일 | 0 | B: 추가 검증 필요 |
| [apps/api/src/bootstrap/README.md](../../apps/api/src/bootstrap/README.md) | 문서 파일 | 0 | B: 추가 검증 필요 |
| [apps/api/src/bootstrap/app.http.test.ts](../../apps/api/src/bootstrap/app.http.test.ts) | 테스트 파일 | 0 | B: 추가 검증 필요 |
| [apps/api/src/bootstrap/app.ts](../../apps/api/src/bootstrap/app.ts) | 소스/설정 파일 | 3 | B: 추가 검증 필요 |
| [apps/api/src/bootstrap/error-handler.ts](../../apps/api/src/bootstrap/error-handler.ts) | 소스/설정 파일 | 2 | B: 추가 검증 필요 |
| [apps/api/src/bootstrap/health.ts](../../apps/api/src/bootstrap/health.ts) | 소스/설정 파일 | 1 | B: 추가 검증 필요 |
| [apps/api/src/bootstrap/observability/readiness.ts](../../apps/api/src/bootstrap/observability/readiness.ts) | 소스/설정 파일 | 0 | B: 추가 검증 필요 |
| [apps/api/src/bootstrap/observability/request-context.ts](../../apps/api/src/bootstrap/observability/request-context.ts) | 소스/설정 파일 | 1 | B: 추가 검증 필요 |
| [apps/api/src/bootstrap/runtime.config.ts](../../apps/api/src/bootstrap/runtime.config.ts) | 소스/설정 파일 | 2 | B: 추가 검증 필요 |
| [apps/api/src/bootstrap/server.ts](../../apps/api/src/bootstrap/server.ts) | 소스/설정 파일 | 0 | B: 추가 검증 필요 |
| [apps/api/src/common/app-error.ts](../../apps/api/src/common/app-error.ts) | 소스/설정 파일 | 20 | B: 추가 검증 필요 |
| [apps/api/src/common/auth.middleware.ts](../../apps/api/src/common/auth.middleware.ts) | 소스/설정 파일 | 7 | B: 추가 검증 필요 |
| [apps/api/src/common/errors.ts](../../apps/api/src/common/errors.ts) | 소스/설정 파일 | 0 | B: 추가 검증 필요 |
| [apps/api/src/common/pagination.ts](../../apps/api/src/common/pagination.ts) | 소스/설정 파일 | 4 | B: 추가 검증 필요 |
| [apps/api/src/common/response.ts](../../apps/api/src/common/response.ts) | 소스/설정 파일 | 7 | B: 추가 검증 필요 |
| [apps/api/src/common/validate.ts](../../apps/api/src/common/validate.ts) | 소스/설정 파일 | 8 | B: 추가 검증 필요 |
| [apps/api/src/config/env.schema.test.ts](../../apps/api/src/config/env.schema.test.ts) | 테스트 파일 | 0 | B: 추가 검증 필요 |
| [apps/api/src/config/env.schema.ts](../../apps/api/src/config/env.schema.ts) | 소스/설정 파일 | 2 | B: 추가 검증 필요 |
| [apps/api/src/config/env.ts](../../apps/api/src/config/env.ts) | 소스/설정 파일 | 11 | B: 추가 검증 필요 |
| [apps/api/src/infrastructure/logger.ts](../../apps/api/src/infrastructure/logger.ts) | 소스/설정 파일 | 6 | B: 추가 검증 필요 |
| [apps/api/src/infrastructure/prisma.ts](../../apps/api/src/infrastructure/prisma.ts) | 소스/설정 파일 | 18 | B: 추가 검증 필요 |
| [apps/api/src/infrastructure/rate-limit.ts](../../apps/api/src/infrastructure/rate-limit.ts) | 소스/설정 파일 | 3 | B: 추가 검증 필요 |
| [apps/api/src/infrastructure/redis.ts](../../apps/api/src/infrastructure/redis.ts) | 소스/설정 파일 | 9 | B: 추가 검증 필요 |
| [apps/api/src/modules/auth/README.md](../../apps/api/src/modules/auth/README.md) | 문서 파일 | 0 | B: 추가 검증 필요 |
| [apps/api/src/modules/auth/auth.controller.ts](../../apps/api/src/modules/auth/auth.controller.ts) | HTTP 요청 검증 및 응답 파일 | 1 | B: 추가 검증 필요 |
| [apps/api/src/modules/auth/auth.dto.test.ts](../../apps/api/src/modules/auth/auth.dto.test.ts) | 테스트 파일 | 0 | B: 추가 검증 필요 |
| [apps/api/src/modules/auth/auth.dto.ts](../../apps/api/src/modules/auth/auth.dto.ts) | 소스/설정 파일 | 4 | B: 추가 검증 필요 |
| [apps/api/src/modules/auth/auth.repository.ts](../../apps/api/src/modules/auth/auth.repository.ts) | 데이터 접근 파일 | 3 | B: 추가 검증 필요 |
| [apps/api/src/modules/auth/auth.service.ts](../../apps/api/src/modules/auth/auth.service.ts) | 업무 처리 파일 | 2 | B: 추가 검증 필요 |
| [apps/api/src/modules/auth/auth.session-lock.test.ts](../../apps/api/src/modules/auth/auth.session-lock.test.ts) | 테스트 파일 | 0 | B: 추가 검증 필요 |
| [apps/api/src/modules/auth/auth.session-version.test.ts](../../apps/api/src/modules/auth/auth.session-version.test.ts) | 테스트 파일 | 0 | B: 추가 검증 필요 |
| [apps/api/src/modules/auth/mfa.test.ts](../../apps/api/src/modules/auth/mfa.test.ts) | 테스트 파일 | 0 | B: 추가 검증 필요 |
| [apps/api/src/modules/auth/mfa.ts](../../apps/api/src/modules/auth/mfa.ts) | 소스/설정 파일 | 5 | B: 추가 검증 필요 |
| [apps/api/src/modules/files/README.md](../../apps/api/src/modules/files/README.md) | 문서 파일 | 0 | B: 추가 검증 필요 |
| [apps/api/src/modules/files/files.controller.ts](../../apps/api/src/modules/files/files.controller.ts) | HTTP 요청 검증 및 응답 파일 | 1 | B: 추가 검증 필요 |
| [apps/api/src/modules/files/files.delete.test.ts](../../apps/api/src/modules/files/files.delete.test.ts) | 테스트 파일 | 0 | B: 추가 검증 필요 |
| [apps/api/src/modules/files/files.deletion-disk.test.ts](../../apps/api/src/modules/files/files.deletion-disk.test.ts) | 테스트 파일 | 0 | B: 추가 검증 필요 |
| [apps/api/src/modules/files/files.deletion-journal.ts](../../apps/api/src/modules/files/files.deletion-journal.ts) | 소스/설정 파일 | 2 | B: 추가 검증 필요 |
| [apps/api/src/modules/files/files.deletion-lock.test.ts](../../apps/api/src/modules/files/files.deletion-lock.test.ts) | 테스트 파일 | 0 | B: 추가 검증 필요 |
| [apps/api/src/modules/files/files.dto.ts](../../apps/api/src/modules/files/files.dto.ts) | 소스/설정 파일 | 6 | B: 추가 검증 필요 |
| [apps/api/src/modules/files/files.repository.ts](../../apps/api/src/modules/files/files.repository.ts) | 데이터 접근 파일 | 1 | B: 추가 검증 필요 |
| [apps/api/src/modules/files/files.security.test.ts](../../apps/api/src/modules/files/files.security.test.ts) | 테스트 파일 | 0 | B: 추가 검증 필요 |
| [apps/api/src/modules/files/files.security.ts](../../apps/api/src/modules/files/files.security.ts) | 소스/설정 파일 | 2 | B: 추가 검증 필요 |
| [apps/api/src/modules/files/files.service.ts](../../apps/api/src/modules/files/files.service.ts) | 업무 처리 파일 | 4 | B: 추가 검증 필요 |
| [apps/api/src/modules/files/files.upload.test.ts](../../apps/api/src/modules/files/files.upload.test.ts) | 테스트 파일 | 0 | B: 추가 검증 필요 |
| [apps/api/src/modules/files/image.processing.test.ts](../../apps/api/src/modules/files/image.processing.test.ts) | 테스트 파일 | 0 | B: 추가 검증 필요 |
| [apps/api/src/modules/files/image.processing.ts](../../apps/api/src/modules/files/image.processing.ts) | 소스/설정 파일 | 3 | B: 추가 검증 필요 |
| [apps/api/src/modules/files/storage/local.storage.test.ts](../../apps/api/src/modules/files/storage/local.storage.test.ts) | 테스트 파일 | 0 | B: 추가 검증 필요 |
| [apps/api/src/modules/files/storage/local.storage.ts](../../apps/api/src/modules/files/storage/local.storage.ts) | 소스/설정 파일 | 3 | B: 추가 검증 필요 |
| [apps/api/src/modules/files/storage/storage.interface.ts](../../apps/api/src/modules/files/storage/storage.interface.ts) | 소스/설정 파일 | 2 | B: 추가 검증 필요 |
| [apps/api/src/modules/notes/README.md](../../apps/api/src/modules/notes/README.md) | 문서 파일 | 0 | B: 추가 검증 필요 |
| [apps/api/src/modules/notes/notes.controller.ts](../../apps/api/src/modules/notes/notes.controller.ts) | HTTP 요청 검증 및 응답 파일 | 1 | B: 추가 검증 필요 |
| [apps/api/src/modules/notes/notes.dto.test.ts](../../apps/api/src/modules/notes/notes.dto.test.ts) | 테스트 파일 | 0 | B: 추가 검증 필요 |
| [apps/api/src/modules/notes/notes.dto.ts](../../apps/api/src/modules/notes/notes.dto.ts) | 소스/설정 파일 | 5 | B: 추가 검증 필요 |
| [apps/api/src/modules/notes/notes.idempotency.ts](../../apps/api/src/modules/notes/notes.idempotency.ts) | 소스/설정 파일 | 1 | B: 추가 검증 필요 |
| [apps/api/src/modules/notes/notes.repository.ts](../../apps/api/src/modules/notes/notes.repository.ts) | 데이터 접근 파일 | 1 | B: 추가 검증 필요 |
| [apps/api/src/modules/notes/notes.service.ts](../../apps/api/src/modules/notes/notes.service.ts) | 업무 처리 파일 | 1 | B: 추가 검증 필요 |
| [apps/api/src/modules/platform/account.service.ts](../../apps/api/src/modules/platform/account.service.ts) | 업무 처리 파일 | 1 | B: 추가 검증 필요 |
| [apps/api/src/modules/platform/admin.controller.ts](../../apps/api/src/modules/platform/admin.controller.ts) | HTTP 요청 검증 및 응답 파일 | 1 | B: 추가 검증 필요 |
| [apps/api/src/modules/platform/mail.ts](../../apps/api/src/modules/platform/mail.ts) | 소스/설정 파일 | 4 | B: 추가 검증 필요 |
| [apps/api/src/modules/platform/platform.controller.ts](../../apps/api/src/modules/platform/platform.controller.ts) | HTTP 요청 검증 및 응답 파일 | 1 | B: 추가 검증 필요 |
| [apps/api/src/modules/platform/smtp.test.ts](../../apps/api/src/modules/platform/smtp.test.ts) | 테스트 파일 | 0 | B: 추가 검증 필요 |
| [apps/api/src/modules/platform/smtp.ts](../../apps/api/src/modules/platform/smtp.ts) | 소스/설정 파일 | 3 | B: 추가 검증 필요 |
| [apps/api/src/types/express.d.ts](../../apps/api/src/types/express.d.ts) | 소스/설정 파일 | 0 | B: 추가 검증 필요 |
| [apps/api/tsconfig.json](../../apps/api/tsconfig.json) | 설정 또는 구조화 데이터 파일 | 0 | B: 추가 검증 필요 |
| [apps/api/vitest.config.mts](../../apps/api/vitest.config.mts) | 테스트 파일 | 0 | B: 추가 검증 필요 |
| [apps/web/.env.local.example](../../apps/web/.env.local.example) | 소스/설정 파일 | 0 | C: 보존 |
| [apps/web/next-env.d.ts](../../apps/web/next-env.d.ts) | 소스/설정 파일 | 0 | B: 추가 검증 필요 |
| [apps/web/next.config.ts](../../apps/web/next.config.ts) | 소스/설정 파일 | 0 | B: 추가 검증 필요 |
| [apps/web/package.json](../../apps/web/package.json) | 설정 또는 구조화 데이터 파일 | 0 | B: 추가 검증 필요 |
| [apps/web/src/app/layout.tsx](../../apps/web/src/app/layout.tsx) | 소스/설정 파일 | 0 | B: 추가 검증 필요 |
| [apps/web/src/app/page.tsx](../../apps/web/src/app/page.tsx) | 웹 화면 파일 | 0 | B: 추가 검증 필요 |
| [apps/web/src/app/starter/_components/Shell.tsx](../../apps/web/src/app/starter/_components/Shell.tsx) | 소스/설정 파일 | 1 | B: 추가 검증 필요 |
| [apps/web/src/app/starter/_lib/api.ts](../../apps/web/src/app/starter/_lib/api.ts) | 소스/설정 파일 | 5 | B: 추가 검증 필요 |
| [apps/web/src/app/starter/_lib/auth.tsx](../../apps/web/src/app/starter/_lib/auth.tsx) | 소스/설정 파일 | 10 | B: 추가 검증 필요 |
| [apps/web/src/app/starter/account/page.tsx](../../apps/web/src/app/starter/account/page.tsx) | 웹 화면 파일 | 0 | B: 추가 검증 필요 |
| [apps/web/src/app/starter/admin/page.tsx](../../apps/web/src/app/starter/admin/page.tsx) | 웹 화면 파일 | 0 | B: 추가 검증 필요 |
| [apps/web/src/app/starter/email/page.tsx](../../apps/web/src/app/starter/email/page.tsx) | 웹 화면 파일 | 0 | B: 추가 검증 필요 |
| [apps/web/src/app/starter/files/page.tsx](../../apps/web/src/app/starter/files/page.tsx) | 웹 화면 파일 | 0 | B: 추가 검증 필요 |
| [apps/web/src/app/starter/layout.tsx](../../apps/web/src/app/starter/layout.tsx) | 소스/설정 파일 | 0 | B: 추가 검증 필요 |
| [apps/web/src/app/starter/login/page.tsx](../../apps/web/src/app/starter/login/page.tsx) | 웹 화면 파일 | 0 | B: 추가 검증 필요 |
| [apps/web/src/app/starter/notes/page.tsx](../../apps/web/src/app/starter/notes/page.tsx) | 웹 화면 파일 | 0 | B: 추가 검증 필요 |
| [apps/web/src/app/starter/notifications/page.tsx](../../apps/web/src/app/starter/notifications/page.tsx) | 웹 화면 파일 | 0 | B: 추가 검증 필요 |
| [apps/web/src/app/starter/page.tsx](../../apps/web/src/app/starter/page.tsx) | 웹 화면 파일 | 0 | B: 추가 검증 필요 |
| [apps/web/src/app/starter/register/page.tsx](../../apps/web/src/app/starter/register/page.tsx) | 웹 화면 파일 | 0 | B: 추가 검증 필요 |
| [apps/web/src/app/starter/starter.css](../../apps/web/src/app/starter/starter.css) | 소스/설정 파일 | 0 | B: 추가 검증 필요 |
| [apps/web/src/app/starter/toolkit/page.tsx](../../apps/web/src/app/starter/toolkit/page.tsx) | 웹 화면 파일 | 0 | B: 추가 검증 필요 |
| [apps/web/src/app/starter/toolkit/part8/page.tsx](../../apps/web/src/app/starter/toolkit/part8/page.tsx) | 웹 화면 파일 | 0 | B: 추가 검증 필요 |
| [apps/web/src/app/starter/toolkit/part9/layout.tsx](../../apps/web/src/app/starter/toolkit/part9/layout.tsx) | 소스/설정 파일 | 0 | B: 추가 검증 필요 |
| [apps/web/src/app/starter/toolkit/part9/page.tsx](../../apps/web/src/app/starter/toolkit/part9/page.tsx) | 웹 화면 파일 | 0 | B: 추가 검증 필요 |
| [apps/web/src/app/starter/toolkit/part9/private/page.tsx](../../apps/web/src/app/starter/toolkit/part9/private/page.tsx) | 웹 화면 파일 | 0 | B: 추가 검증 필요 |
| [apps/web/src/shared/api/README.md](../../apps/web/src/shared/api/README.md) | 문서 파일 | 0 | B: 추가 검증 필요 |
| [apps/web/src/shared/api/client.test.ts](../../apps/web/src/shared/api/client.test.ts) | 테스트 파일 | 0 | B: 추가 검증 필요 |
| [apps/web/src/shared/api/client.ts](../../apps/web/src/shared/api/client.ts) | 소스/설정 파일 | 4 | B: 추가 검증 필요 |
| [apps/web/src/shared/api/config.ts](../../apps/web/src/shared/api/config.ts) | 소스/설정 파일 | 4 | B: 추가 검증 필요 |
| [apps/web/src/shared/api/resilient-request.ts](../../apps/web/src/shared/api/resilient-request.ts) | 소스/설정 파일 | 1 | B: 추가 검증 필요 |
| [apps/web/src/shared/api/web-auth.ts](../../apps/web/src/shared/api/web-auth.ts) | 소스/설정 파일 | 0 | B: 추가 검증 필요 |
| [apps/web/src/shared/auth/auth-client.ts](../../apps/web/src/shared/auth/auth-client.ts) | 소스/설정 파일 | 4 | B: 추가 검증 필요 |
| [apps/web/src/shared/auth/auth-guard.tsx](../../apps/web/src/shared/auth/auth-guard.tsx) | 소스/설정 파일 | 1 | B: 추가 검증 필요 |
| [apps/web/src/shared/auth/auth-provider.tsx](../../apps/web/src/shared/auth/auth-provider.tsx) | 소스/설정 파일 | 4 | B: 추가 검증 필요 |
| [apps/web/src/shared/security/file-preflight.ts](../../apps/web/src/shared/security/file-preflight.ts) | 소스/설정 파일 | 1 | B: 추가 검증 필요 |
| [apps/web/src/shared/ui/async-state.tsx](../../apps/web/src/shared/ui/async-state.tsx) | 소스/설정 파일 | 1 | B: 추가 검증 필요 |
| [apps/web/src/shared/ui/confirm-dialog.tsx](../../apps/web/src/shared/ui/confirm-dialog.tsx) | 소스/설정 파일 | 1 | B: 추가 검증 필요 |
| [apps/web/src/shared/ui/error-boundary.tsx](../../apps/web/src/shared/ui/error-boundary.tsx) | 소스/설정 파일 | 1 | B: 추가 검증 필요 |
| [apps/web/src/shared/ui/index.tsx](../../apps/web/src/shared/ui/index.tsx) | 소스/설정 파일 | 5 | B: 추가 검증 필요 |
| [apps/web/src/shared/ui/toast.tsx](../../apps/web/src/shared/ui/toast.tsx) | 소스/설정 파일 | 3 | B: 추가 검증 필요 |
| [apps/web/src/shared/ui/ui.css](../../apps/web/src/shared/ui/ui.css) | 소스/설정 파일 | 0 | B: 추가 검증 필요 |
| [apps/web/src/shared/ui/ui.test.tsx](../../apps/web/src/shared/ui/ui.test.tsx) | 테스트 파일 | 0 | B: 추가 검증 필요 |
| [apps/web/tsconfig.json](../../apps/web/tsconfig.json) | 설정 또는 구조화 데이터 파일 | 0 | B: 추가 검증 필요 |
| [apps/web/vitest.config.mts](../../apps/web/vitest.config.mts) | 테스트 파일 | 0 | B: 추가 검증 필요 |
| [backup/V5-source-before-changes.zip](../../backup/V5-source-before-changes.zip) | 소스/설정 파일 | 0 | C: 보존 |
| [compose.mail-dev.yaml](../../compose.mail-dev.yaml) | 소스/설정 파일 | 0 | B: 추가 검증 필요 |
| [compose.production.yaml](../../compose.production.yaml) | 소스/설정 파일 | 0 | B: 추가 검증 필요 |
| [compose.yaml](../../compose.yaml) | 소스/설정 파일 | 0 | B: 추가 검증 필요 |
| [create-starter-ps1-shell-script/create-starter-part10.ps1](../../create-starter-ps1-shell-script/create-starter-part10.ps1) | Windows 설치·실행 자동화 파일 | 0 | B: 추가 검증 필요 |
| [create-starter-ps1-shell-script/create-starter-part11.ps1](../../create-starter-ps1-shell-script/create-starter-part11.ps1) | Windows 설치·실행 자동화 파일 | 0 | B: 추가 검증 필요 |
| [create-starter-ps1-shell-script/create-starter-part2.ps1](../../create-starter-ps1-shell-script/create-starter-part2.ps1) | Windows 설치·실행 자동화 파일 | 0 | B: 추가 검증 필요 |
| [create-starter-ps1-shell-script/create-starter-part3.ps1](../../create-starter-ps1-shell-script/create-starter-part3.ps1) | Windows 설치·실행 자동화 파일 | 0 | B: 추가 검증 필요 |
| [create-starter-ps1-shell-script/create-starter-part4.ps1](../../create-starter-ps1-shell-script/create-starter-part4.ps1) | Windows 설치·실행 자동화 파일 | 0 | B: 추가 검증 필요 |
| [create-starter-ps1-shell-script/create-starter-part5.ps1](../../create-starter-ps1-shell-script/create-starter-part5.ps1) | Windows 설치·실행 자동화 파일 | 0 | B: 추가 검증 필요 |
| [create-starter-ps1-shell-script/create-starter-part6.ps1](../../create-starter-ps1-shell-script/create-starter-part6.ps1) | Windows 설치·실행 자동화 파일 | 0 | B: 추가 검증 필요 |
| [create-starter-ps1-shell-script/create-starter-part7.ps1](../../create-starter-ps1-shell-script/create-starter-part7.ps1) | Windows 설치·실행 자동화 파일 | 0 | B: 추가 검증 필요 |
| [create-starter-ps1-shell-script/create-starter-part8.ps1](../../create-starter-ps1-shell-script/create-starter-part8.ps1) | Windows 설치·실행 자동화 파일 | 0 | B: 추가 검증 필요 |
| [create-starter-ps1-shell-script/create-starter-part9.ps1](../../create-starter-ps1-shell-script/create-starter-part9.ps1) | Windows 설치·실행 자동화 파일 | 0 | B: 추가 검증 필요 |
| [create-starter-ps1-shell-script/create-starter.ps1](../../create-starter-ps1-shell-script/create-starter.ps1) | Windows 설치·실행 자동화 파일 | 0 | B: 추가 검증 필요 |
| [create-starter-ps1-shell-script/repair-starter-part8.ps1](../../create-starter-ps1-shell-script/repair-starter-part8.ps1) | Windows 설치·실행 자동화 파일 | 0 | B: 추가 검증 필요 |
| [deploy/Caddyfile](../../deploy/Caddyfile) | 소스/설정 파일 | 0 | B: 추가 검증 필요 |
| [deploy/Dockerfile.api](../../deploy/Dockerfile.api) | 소스/설정 파일 | 0 | B: 추가 검증 필요 |
| [deploy/Dockerfile.migrate](../../deploy/Dockerfile.migrate) | 소스/설정 파일 | 0 | B: 추가 검증 필요 |
| [deploy/Dockerfile.web](../../deploy/Dockerfile.web) | 소스/설정 파일 | 0 | B: 추가 검증 필요 |
| [deploy/production.env.example](../../deploy/production.env.example) | 소스/설정 파일 | 0 | C: 보존 |
| [docs/API.md](../../docs/API.md) | 문서 파일 | 0 | B: 추가 검증 필요 |
| [docs/CHANGELOG.md](../../docs/CHANGELOG.md) | 문서 파일 | 0 | B: 추가 검증 필요 |
| [docs/OPERATIONS.md](../../docs/OPERATIONS.md) | 문서 파일 | 0 | B: 추가 검증 필요 |
| [docs/README.md](../../docs/README.md) | 문서 파일 | 0 | B: 추가 검증 필요 |
| [docs/SECURITY.md](../../docs/SECURITY.md) | 문서 파일 | 0 | B: 추가 검증 필요 |
| [docs/V6-REPORT.md](../../docs/V6-REPORT.md) | 문서 파일 | 0 | B: 추가 검증 필요 |
| [docs/WINDOWS.md](../../docs/WINDOWS.md) | 문서 파일 | 0 | B: 추가 검증 필요 |
| [docs/architecture/developer-platform.md](../../docs/architecture/developer-platform.md) | 문서 파일 | 0 | B: 추가 검증 필요 |
| [docs/files/generated-index.md](../../docs/files/generated-index.md) | 문서 파일 | 0 | B: 추가 검증 필요 |
| [docs/installation/developer-platform.md](../../docs/installation/developer-platform.md) | 문서 파일 | 0 | B: 추가 검증 필요 |
| [docs/openapi.json](../../docs/openapi.json) | 설정 또는 구조화 데이터 파일 | 0 | B: 추가 검증 필요 |
| [docs/operations/email.md](../../docs/operations/email.md) | 문서 파일 | 0 | B: 추가 검증 필요 |
| [docs/security/platform-review.md](../../docs/security/platform-review.md) | 문서 파일 | 0 | B: 추가 검증 필요 |
| [docs/testing/current-results.md](../../docs/testing/current-results.md) | 테스트 파일 | 0 | B: 추가 검증 필요 |
| [docs/workflows/code-flows.md](../../docs/workflows/code-flows.md) | 문서 파일 | 0 | B: 추가 검증 필요 |
| [package-lock.json](../../package-lock.json) | 설정 또는 구조화 데이터 파일 | 0 | B: 추가 검증 필요 |
| [package.json](../../package.json) | 설정 또는 구조화 데이터 파일 | 0 | B: 추가 검증 필요 |
| [tools/SecureStarterLauncher.cs](../../tools/SecureStarterLauncher.cs) | 소스/설정 파일 | 0 | C: 보존 |
| [tools/analyze-project.mjs](../../tools/analyze-project.mjs) | 소스/설정 파일 | 6 | B: 추가 검증 필요 |
| [tools/backup.mjs](../../tools/backup.mjs) | 소스/설정 파일 | 1 | C: 보존 |
| [tools/bootstrap-admin.ts](../../tools/bootstrap-admin.ts) | 소스/설정 파일 | 0 | B: 추가 검증 필요 |
| [tools/build-component-preview.mjs](../../tools/build-component-preview.mjs) | 소스/설정 파일 | 0 | B: 추가 검증 필요 |
| [tools/build-launchers.ps1](../../tools/build-launchers.ps1) | Windows 설치·실행 자동화 파일 | 0 | C: 보존 |
| [tools/check-files.ts](../../tools/check-files.ts) | 소스/설정 파일 | 0 | B: 추가 검증 필요 |
| [tools/dev-observed.mjs](../../tools/dev-observed.mjs) | 소스/설정 파일 | 0 | B: 추가 검증 필요 |
| [tools/dev-portal/app.js](../../tools/dev-portal/app.js) | 소스/설정 파일 | 0 | B: 추가 검증 필요 |
| [tools/dev-portal/components.tsx](../../tools/dev-portal/components.tsx) | 소스/설정 파일 | 0 | B: 추가 검증 필요 |
| [tools/dev-portal/events.mjs](../../tools/dev-portal/events.mjs) | 소스/설정 파일 | 2 | B: 추가 검증 필요 |
| [tools/dev-portal/events.test.mjs](../../tools/dev-portal/events.test.mjs) | 테스트 파일 | 0 | B: 추가 검증 필요 |
| [tools/dev-portal/index.html](../../tools/dev-portal/index.html) | 소스/설정 파일 | 0 | B: 추가 검증 필요 |
| [tools/dev-portal/portal.test.mjs](../../tools/dev-portal/portal.test.mjs) | 테스트 파일 | 0 | B: 추가 검증 필요 |
| [tools/dev-portal/server.mjs](../../tools/dev-portal/server.mjs) | 소스/설정 파일 | 1 | B: 추가 검증 필요 |
| [tools/dev-portal/style.css](../../tools/dev-portal/style.css) | 소스/설정 파일 | 0 | B: 추가 검증 필요 |
| [tools/developer-event.mjs](../../tools/developer-event.mjs) | 소스/설정 파일 | 2 | B: 추가 검증 필요 |
| [tools/developer-event.test.mjs](../../tools/developer-event.test.mjs) | 테스트 파일 | 0 | B: 추가 검증 필요 |
| [tools/docs-index.mjs](../../tools/docs-index.mjs) | 소스/설정 파일 | 0 | B: 추가 검증 필요 |
| [tools/license-inventory.mjs](../../tools/license-inventory.mjs) | 소스/설정 파일 | 0 | B: 추가 검증 필요 |
| [tools/process-definitions.mjs](../../tools/process-definitions.mjs) | 소스/설정 파일 | 1 | B: 추가 검증 필요 |
| [tools/smoke-web.mjs](../../tools/smoke-web.mjs) | 소스/설정 파일 | 0 | B: 추가 검증 필요 |
| [tools/test-backup.mjs](../../tools/test-backup.mjs) | 테스트 파일 | 0 | C: 보존 |
| [tools/test-mail.mts](../../tools/test-mail.mts) | 테스트 파일 | 0 | B: 추가 검증 필요 |
| [tools/test-migrations.mjs](../../tools/test-migrations.mjs) | 테스트 파일 | 0 | C: 보존 |
| [tools/test-platform.mjs](../../tools/test-platform.mjs) | 테스트 파일 | 0 | B: 추가 검증 필요 |
| [tools/test-smtp.mts](../../tools/test-smtp.mts) | 테스트 파일 | 0 | B: 추가 검증 필요 |
| [tools/verify-platform.mjs](../../tools/verify-platform.mjs) | 소스/설정 파일 | 0 | B: 추가 검증 필요 |
| [tools/verify-powershell.ps1](../../tools/verify-powershell.ps1) | Windows 설치·실행 자동화 파일 | 0 | B: 추가 검증 필요 |
| [tools/verify-source.mjs](../../tools/verify-source.mjs) | 소스/설정 파일 | 0 | B: 추가 검증 필요 |
| [tools/verify-starter.ps1](../../tools/verify-starter.ps1) | Windows 설치·실행 자동화 파일 | 0 | B: 추가 검증 필요 |
| [verification/change-list.json](../../verification/change-list.json) | 설정 또는 구조화 데이터 파일 | 0 | B: 추가 검증 필요 |
| [verification/execution-results.json](../../verification/execution-results.json) | 설정 또는 구조화 데이터 파일 | 0 | B: 추가 검증 필요 |
| [verification/input-sha256.json](../../verification/input-sha256.json) | 설정 또는 구조화 데이터 파일 | 0 | B: 추가 검증 필요 |
| [verification/license-inventory.json](../../verification/license-inventory.json) | 설정 또는 구조화 데이터 파일 | 0 | B: 추가 검증 필요 |
| [verification/npm-audit.json](../../verification/npm-audit.json) | 설정 또는 구조화 데이터 파일 | 0 | B: 추가 검증 필요 |
| [verification/source-sha256.json](../../verification/source-sha256.json) | 설정 또는 구조화 데이터 파일 | 0 | B: 추가 검증 필요 |
| [verification/static-checks.json](../../verification/static-checks.json) | 설정 또는 구조화 데이터 파일 | 0 | B: 추가 검증 필요 |
| [verification/v5-source-sha256.json](../../verification/v5-source-sha256.json) | 설정 또는 구조화 데이터 파일 | 0 | B: 추가 검증 필요 |
| [검증결과.md](../../검증결과.md) | 문서 파일 | 0 | B: 추가 검증 필요 |
