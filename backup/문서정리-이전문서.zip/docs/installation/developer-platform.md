# 개발 플랫폼 시작

기존 SETUP/STARTER/STOP 흐름은 변경하지 않았습니다. 첨부본에는 EXE가 없고 C# 소스 및 재빌드 PowerShell만 있습니다. Windows에서 `tools/build-launchers.ps1`로 생성하는 절차는 기존 [Windows 안내](../WINDOWS.md)를 따르세요. 이번 환경에는 Windows, PowerShell, Docker가 없습니다.

## 설치

Node.js 22 이상에서 프로젝트 루트의 `npm ci --ignore-scripts`, `npm run db:generate`를 실행하세요. 기존 DB를 사용하는 경우 환경설정과 백업을 확인한 뒤 기존 migration deploy 절차를 사용하세요. reset 및 Docker volume 삭제는 사용하지 않습니다.

## 별도 로컬 포털 (PowerShell 5.1)

```powershell
$bytes = New-Object byte[] 32
$rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
try { $rng.GetBytes($bytes) } finally { $rng.Dispose() }
$env:DEV_PORTAL_TOKEN = [Convert]::ToBase64String($bytes)
# 이 값을 로컬 포털 입력란에 붙여넣으세요. 공유하거나 로그에 저장하지 마세요.
$env:DEV_PORTAL_TOKEN
npm run dev:portal
```

`http://127.0.0.1:4310`에 접속합니다. localhost 별칭은 Host 검증에서 거부됩니다. 서버는 127.0.0.1에만 바인딩하고 설정 누락/production에서 실행을 거부합니다. 접근키는 서버 시작 후 1시간 만료됩니다. 종료는 Ctrl+C입니다. 접근키는 일반 사용자 JWT와 별개이며 브라우저 영구 저장소에 저장하지 않습니다. 로컬 접근키는 MFA 관리자 인증의 대체 수단이 아닙니다. 이 도구를 원격 공개하지 마세요.

## 관측 수집

API: `npm run dev:api:observed`. WEB: `npm run dev:web:observed`. 운영환경에서는 두 래퍼 모두 실행을 거부합니다. 고정된 npm 개발 명령의 출력을 수집하며 원문은 기존 터미널에만 표시됩니다. 포털은 두 서비스의 고정된 `.starter-state/developer-events.jsonl`만 읽습니다. 요청 본문·URL·오류 원문은 수집하지 않으며 API 허용 필드만 유지합니다. 파일당 1MiB 상한, 화면 최대 100건, 1시간 보존 필터입니다. 재실행 이전 이벤트가 보일 수 있으며 서비스 정상 상태를 뜻하지 않습니다.

`npm run analyze`, `npm run docs:index`, `npm run docs:check`, `npm run test:portal`로 갱신/검증합니다. 포털 데이터는 시작 시 스냅샷이므로 소스 변경 후 서버를 다시 시작하세요.
