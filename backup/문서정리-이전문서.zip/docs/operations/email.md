# 이메일 설정과 제한

선택형 SMTP 어댑터를 추가했습니다. SMTP_HOST 미설정 시 기존 fail-closed 동작(503 MAIL_NOT_CONFIGURED)을 유지합니다. SMTP_USER/PASSWORD는 함께 설정하고 실제 비밀값은 .env에만 보관하세요. 설정 예시는 apps/api/.env.example입니다.

개발용 수신함: `docker compose -f compose.mail-dev.yaml up -d`. SMTP 127.0.0.1:1025, 수신함 http://127.0.0.1:8025. 이 구성의 실제 Docker 실행은 미검증입니다. 정지는 같은 명령의 `stop`으로 수행하세요. 일반 compose 파일과 운영 compose에는 포함하지 않습니다.

운영에서는 TLS SMTP와 HTTPS MAIL_PUBLIC_URL이 필요합니다. MAIL_FROM 도메인에 제공자 지침의 SPF 발송 허용, DKIM 서명 키, DMARC 정책/보고 주소를 설정하고 DNS 반영 및 수신 헤더를 확인하세요. 특정 DNS 값을 임의로 생성하지 않습니다.

현재 제공: 텍스트 템플릿, 제공자 교체용 MailTransport 계약, SMTP 연결/소켓 시간 제한, 외부 파일/URL 템플릿 로딩 차단, 동시 대기 20건 상한. 포화/발송 실패는 기존 계정 처리에 전달됩니다. 자동 재시도는 SMTP 응답 유실 시 중복 발송 위험이 있어 구현하지 않았습니다.

**미구현**: 영속 발송 큐, 지수 재시도, 제공자 idempotency, 반송 웹훅, 발송 상태 DB 기록, 계정별 재발송 cooldown. 기존 sensitiveLimiter 요청 제한은 유지됩니다. 실제 외부 발송·수신·SPF/DKIM/DMARC 검증은 외부 설정 필요입니다.
