# 주요 실행 흐름

수동 검토 설명이며, 소스 파일의 함수 이름과 연결합니다. 포털의 선언 목록에는 AST에서 찾은 줄 번호가 제공됩니다.

## 이메일 접근 확인

```mermaid
sequenceDiagram
 participant U as 사용자
 participant A as accountRouter
 participant S as account.service
 participant D as PostgreSQL
 participant M as MailTransport
 U->>A: POST /account/email/request
 A->>S: requestAccountAction
 S->>D: 사용자 조회 / 토큰 해시 저장
 S->>M: 원문 토큰 전송
 M-->>U: 인증 코드와 링크
 U->>A: POST /account/email/verify
 A->>S: consumeAccountAction
 S->>D: 회원 행 잠금 / 만료·버전·일회용 검사
 D-->>U: 이메일 인증 완료
```

- [요청 검증 및 엔드포인트](../../apps/api/src/modules/platform/platform.controller.ts)
- [토큰 발행·소비·메일 변경](../../apps/api/src/modules/platform/account.service.ts)
- [SMTP 제공자](../../apps/api/src/modules/platform/smtp.ts)
- [공개 인증·재설정 화면](../../apps/web/src/app/starter/email/page.tsx)
- [격리 계정 테스트](../../tools/test-mail.mts)

실패 시 만료/재사용/버전 불일치는 거부하고, 전송 실패 시 발행한 토큰을 소비 처리합니다. 비밀번호 재설정은 기존 MFA를 해제하지 않습니다. 이메일 형식 검사는 계정 실재 여부 확인이 아닙니다.

## 요청·로그·종료

```mermaid
flowchart TD
 A[HTTP 요청] --> B[requestContext: 서버 요청 ID]
 B --> C[Helmet·Origin·Body 제한]
 C --> D[Redis 요청 제한]
 D --> E[Router → Service → Repository]
 E --> F[응답 또는 globalErrorHandler]
 F --> G[Pino 허용 필드 관측]
```

[API 부트스트랩](../../apps/api/src/bootstrap/app.ts), [안전 종료](../../apps/api/src/bootstrap/server.ts), [실행기 C#](../../tools/SecureStarterLauncher.cs), [PowerShell 수명주기](../../SECURE-LIFECYCLE.ps1).

C# 런처는 자신의 파일명으로 SETUP/STARTER/STOP Action을 선택하고 Windows PowerShell 5.1 프로세스를 기다린 뒤 같은 종료코드를 반환합니다. 실행기 소스는 보존했으며 Windows 런타임 동작은 미검증입니다.
