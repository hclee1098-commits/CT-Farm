// 소스 본문/비밀값을 내보내지 않는 보수적 정적 분석기입니다.
import fs from 'node:fs';
import {workflows} from './process-definitions.mjs';
import ts from 'typescript';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
export const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const skip=new Set(['node_modules','.git','.next','dist','uploads','.starter-state','.starter-backups','analysis']);
export function analyze(){
 const files=[]; const walk=d=>{for(const e of fs.readdirSync(d,{withFileTypes:true})){if(e.isSymbolicLink())continue;const p=path.join(d,e.name);if(e.isDirectory()){if(!skip.has(e.name))walk(p);}else if(!/^\.env($|\.(?!.*example))/.test(e.name)&&!e.name.endsWith('.log')&&!e.name.endsWith('.tsbuildinfo')){
 const b=fs.readFileSync(p), rel=path.relative(root,p).split(path.sep).join('/');const text=/\.(tsx?|m?js|mts|json|md|prisma|sql|yaml|yml|ps1|cs|toml|css)$/.test(p)?b.toString('utf8').replace(/^\uFEFF/,''):'';
 const matches=re=>[...text.matchAll(re)].map(m=>({name:m[1],line:text.slice(0,m.index).split('\n').length}));
 const imports=matches(/(?:from\s*|import\s*\(|require\s*\()\s*['"]([^'"]+)['"]/g);
 const ext=path.extname(p);let purpose='역할 확인되지 않음';
 const kind=rel.includes('test')?'테스트':rel.endsWith('.controller.ts')?'HTTP 요청 검증 및 응답':rel.endsWith('.service.ts')?'업무 처리':rel.endsWith('.repository.ts')?'데이터 접근':rel.endsWith('page.tsx')?'웹 화면':ext==='.md'?'문서':ext==='.ps1'?'Windows 설치·실행 자동화':ext==='.sql'?'DB 마이그레이션':ext==='.prisma'?'데이터 모델':ext==='.json'?'설정 또는 구조화 데이터':'소스/설정';
 purpose=kind+' 파일';
 files.push({path:rel,type:ext,size:b.length,hash:crypto.createHash('sha256').update(b).digest('hex'),purpose,features:[],functions:matches(/(?:function\s+|(?:const|let)\s+)([A-Za-z_$][\w$]*)\s*(?:[=(<])/g),classes:matches(/class\s+(\w+)/g),interfaces:matches(/interface\s+(\w+)/g),imports:imports.map(i=>i.name),internalDependencies:[],externalDependencies:imports.filter(i=>!i.name.startsWith('.')).map(i=>i.name),usedBy:[],apis:matches(/\b\w+Router\.(get|post|put|patch|delete)\s*\(/g).map(i=>({method:i.name,line:i.line})),models:matches(/(?:prisma|tx)\.(\w+)\./g).map(i=>i.name),environment:matches(/process\.env\.([A-Z_][A-Z_0-9]*)/g).map(i=>i.name),tests:[],documents:[],security:/auth|admin|mfa|mail|env|security|backup|lifecycle/i.test(rel)?'보안 민감 영역: 수정 후 회귀 검증 필요':'확인되지 않음',importance:/migration|auth|lifecycle|schema|bootstrap/.test(rel)?'높음':'보통',usage:'확인되지 않음',deletion:/migration|backup|\.exe$|\.env|lifecycle|launcher/i.test(rel)?'C: 보존':'B: 추가 검증 필요',duplicate:[],evidence:{method:'정규식 정적 분석; 함수 후보는 변수도 포함, 동적 실행/사용 여부 확정 불가',sha256:crypto.createHash('sha256').update(b).digest('hex')}});
 }}};walk(root);const paths=new Set(files.map(f=>f.path));
 for(const f of files){for(const i of f.imports.filter(i=>i.startsWith('.'))){const base=path.posix.normalize(path.posix.join(path.posix.dirname(f.path),i));const target=[base,...['.ts','.tsx','.js','.mjs','/index.ts','/index.tsx'].map(e=>base+e)].find(p=>paths.has(p));if(target)f.internalDependencies.push(target);}f.tests=files.filter(t=>/\.test\./.test(t.path)&&t.path.replace(/\.test\..+$/,'')===f.path.replace(/\.[^.]+$/,'')).map(t=>t.path);f.documents=files.filter(d=>d.type==='.md'&&path.posix.dirname(d.path)===path.posix.dirname(f.path)).map(d=>d.path);}
 for(const f of files){f.usedBy=files.filter(g=>g.internalDependencies.includes(f.path)).map(g=>g.path);if(f.usedBy.length)f.usage='정적 import 확인';f.duplicate=files.filter(g=>g.path!==f.path&&g.hash===f.hash).map(g=>g.path);}
 // TypeScript AST로 선언과 import 위치를 보강합니다. 실행 중 사용 여부는 추정하지 않습니다.
 for(const f of files.filter(f=>/\.(tsx?|mts|m?js)$/.test(f.path))){
  const source=ts.createSourceFile(f.path,fs.readFileSync(path.join(root,f.path),'utf8'),ts.ScriptTarget.Latest,true);
  const functions=[],classes=[],interfaces=[],constants=[],routes=[];
  function visit(node){const name=node.name?.getText(source),line=source.getLineAndCharacterOfPosition(node.getStart(source)).line+1;
   if((ts.isFunctionDeclaration(node)||ts.isMethodDeclaration(node))&&name)functions.push({name,line});
   if(ts.isVariableDeclaration(node)&&name){if(node.initializer&&(ts.isArrowFunction(node.initializer)||ts.isFunctionExpression(node.initializer)))functions.push({name,line});else constants.push({name,line});}
   if(ts.isClassDeclaration(node)&&name)classes.push({name,line});if(ts.isInterfaceDeclaration(node)&&name)interfaces.push({name,line,properties:node.members.map(m=>m.name?.getText(source)).filter(Boolean)});
   if(ts.isCallExpression(node)&&ts.isPropertyAccessExpression(node.expression)&&['get','post','patch','put','delete'].includes(node.expression.name.text)&&node.expression.expression.getText(source).endsWith('Router')&&node.arguments[0]&&ts.isStringLiteral(node.arguments[0]))routes.push({method:node.expression.name.text.toUpperCase(),route:node.arguments[0].text,line,router:node.expression.expression.getText(source)});
   ts.forEachChild(node,visit);
  }visit(source);Object.assign(f,{functions,classes,interfaces,constants,apis:routes});f.evidence.method='TypeScript AST 선언/라우트 + 정규식 의존성 후보; 동적 실행은 확인되지 않음';
 }
 const openapi=JSON.parse(fs.readFileSync(path.join(root,'docs/openapi.json'),'utf8'));
 const apis=Object.entries(openapi.paths||{}).flatMap(([endpoint,methods])=>Object.entries(methods).filter(([m])=>['get','post','put','patch','delete'].includes(m)).map(([method,detail])=>({endpoint,method:method.toUpperCase(),...detail,evidence:'기존 OpenAPI 문서; 런타임 일치 미검증'})));
 const mounts=[...fs.readFileSync(path.join(root,'apps/api/src/bootstrap/app.ts'),'utf8').matchAll(/app\.use\(\s*["']([^"']+)["']\s*,\s*(\w+Router)/g)].map(m=>({prefix:m[1],router:m[2]}));
 for(const api of apis){api.implementations=files.flatMap(f=>f.apis.filter(r=>r.method===api.method&&mounts.some(m=>m.router===r.router&&(m.prefix+r.route).replace(/:([A-Za-z_][A-Za-z_0-9]*)/g,'{$1}').replace(/\/$/,'')===('/api/v1'+api.endpoint).replace(/\/$/,''))).map(r=>({file:f.path,line:r.line,router:r.router})));api.sourceStatus=api.implementations.length?'정적 라우트 확인':'OpenAPI 경로 매칭 확인되지 않음';}
 const modelText=fs.readFileSync(path.join(root,'apps/api/prisma/schema.prisma'),'utf8');const dataModels=[...modelText.matchAll(/model\s+(\w+)\s*\{([^}]+)\}/g)].map(m=>({name:m[1],fields:m[2].split('\n').map(l=>l.trim()).filter(l=>l&&!l.startsWith('//')),file:'apps/api/prisma/schema.prisma'}));for(const model of dataModels)model.related=dataModels.filter(other=>model.fields.some(f=>new RegExp('^\\w+\\s+'+other.name+'(?:[?\\[\\]\\s])').test(f))).map(m=>m.name);
 const cyclePaths=[];const visiting=new Set(),visited=new Set();function search(p,stack=[]){if(visiting.has(p)){cyclePaths.push([...stack.slice(stack.indexOf(p)),p]);return;}if(visited.has(p))return;visiting.add(p);for(const dep of files.find(f=>f.path===p)?.internalDependencies??[])search(dep,[...stack,p]);visiting.delete(p);visited.add(p);}for(const f of files)search(f.path);
 const quality={cycles:cyclePaths,exactDuplicates:files.filter(f=>f.duplicate.length).map(f=>({file:f.path,duplicates:f.duplicate})),unreferencedCandidates:files.filter(f=>!f.usedBy.length).map(f=>({file:f.path,status:f.deletion,note:'정적 import 외 실행 가능; 미사용 확정 아님'})),dependencies:'미사용 패키지 자동 제거 없음'};
 const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
 const features=['인증','권한','보안','데이터베이스','Redis','API','파일','이미지','이메일','알림','공통 컴포넌트','로깅','모니터링','테스트','설치','배포','개발 도구'].map((name,i)=>{const patterns=['auth','admin|middleware','security|mfa','prisma|repository','redis','controller','files','image','mail|account.service','notification|platform.controller','shared/ui','logger|observability','health|readiness','test','LIFECYCLE|Launcher','deploy|compose','dev-portal'];return {name,status:i===8?'외부 설정 필요':'일부 구현',files:files.filter(f=>new RegExp(patterns[i],'i').test(f.path)).map(f=>f.path),testStatus:'실행 보고서 참조',note:'소스 존재와 기능 완료/검증은 별개입니다.'};});
 const processes=workflows.map(w=>({...w,origin:'수동 설명 + 자동 파일/기호 존재 검사',testStatus:'실행 보고서 참조',steps:w.steps.map(step=>{const file=files.find(f=>f.path===step.file),text=file?fs.readFileSync(path.join(root,step.file),'utf8'):'';const found=text.indexOf(step.symbol);return {...step,verified:found>=0,line:file?.functions.find(f=>f.name===step.symbol)?.line??(found>=0?text.slice(0,found).split('\n').length:null),tests:file?.tests??[],security:file?.security??'확인되지 않음'};})}));
 let verification=null;try{const report=JSON.parse(fs.readFileSync(path.join(root,'analysis/current-verification.json'),'utf8'));verification={at:report.at,runtime:report.runtime,checks:report.results.map(r=>({name:r.name,status:r.status,durationMs:r.durationMs}))};}catch{}
 return {schemaVersion:1,verification,processes,quality,dataModels,project:pkg.name,version:pkg.version,analyzedAt:new Date().toISOString(),sourceDigest:crypto.createHash('sha256').update(files.map(f=>f.path+f.hash).join('\n')).digest('hex'),files,features,apis,limitations:['정규식 분석으로 확인되지 않는 동적 참조 존재','정적 참조가 없다고 삭제 가능하지 않음','기존 검증 기록은 이번 실행 결과가 아님']};
}
if(process.argv[1]===fileURLToPath(import.meta.url)){fs.mkdirSync(path.join(root,'analysis'),{recursive:true});const data=analyze();fs.writeFileSync(path.join(root,'analysis/project.json'),JSON.stringify(data,null,2));console.log(`분석 완료: ${data.files.length}개 파일, ${data.apis.length}개 API`);}
