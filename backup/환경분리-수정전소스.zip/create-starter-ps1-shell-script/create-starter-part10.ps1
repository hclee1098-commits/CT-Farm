﻿# filepath: create-starter-part10.ps1 - 기존 프론트엔드 인증 시스템을 통합하고 보안 및 호환성을 개선하는 스크립트

$ErrorActionPreference = "Stop"

# ============================================================
# 1. 프로젝트 경로
# ============================================================

$Root = Join-Path $env:USERPROFILE "Desktop\secure-starter"

# 보안 검토가 끝난 프로젝트에 예전 생성 코드를 덮어쓰지 않습니다.
if (Test-Path -LiteralPath (Join-Path $Root "SECURITY-REVISION.json")) {
    throw "보안 수정이 적용된 V5입니다. 이전 부별 생성 스크립트 적용을 차단합니다."
}


if (-not (Test-Path (Join-Path $Root "apps\web\package.json"))) {
    throw "기존 Next.js 프로젝트를 찾을 수 없습니다."
}

Set-Location $Root

$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)

Write-Host ""
Write-Host "============================================"
Write-Host " 10부 프론트엔드 인증 시스템 통합"
Write-Host "============================================"
Write-Host ""

# ============================================================
# 2. 변경 대상 파일
# ============================================================

$Files = @(
    "apps/web/src/shared/auth/auth-client.ts"
    "apps/web/src/shared/auth/auth-provider.tsx"
    "apps/web/src/app/starter/_lib/auth.tsx"
    "apps/web/src/app/starter/toolkit/part9/layout.tsx"
    "apps/web/src/shared/api/client.ts"
)

foreach ($RelativePath in $Files) {

    $FullPath = Join-Path $Root $RelativePath

    if (-not (Test-Path $FullPath)) {
        throw "필수 파일이 없습니다: $RelativePath"
    }
}

Write-Host "[확인] 변경 대상 파일 5개 존재" -ForegroundColor Green

# ============================================================
# 3. 기존 코드 구조 확인
# ============================================================

$LegacyAuth = [System.IO.File]::ReadAllText(
    (Join-Path $Root "apps/web/src/app/starter/_lib/auth.tsx")
)

$SharedAuth = [System.IO.File]::ReadAllText(
    (Join-Path $Root "apps/web/src/shared/auth/auth-client.ts")
)

$SharedProvider = [System.IO.File]::ReadAllText(
    (Join-Path $Root "apps/web/src/shared/auth/auth-provider.tsx")
)

$Part9Layout = [System.IO.File]::ReadAllText(
    (Join-Path $Root "apps/web/src/app/starter/toolkit/part9/layout.tsx")
)

$ApiClient = [System.IO.File]::ReadAllText(
    (Join-Path $Root "apps/web/src/shared/api/client.ts")
)

if (
    -not $LegacyAuth.Contains("export function AuthProvider") -or
    -not $LegacyAuth.Contains("export function useAuth")
) {
    throw "기존 Starter 인증 구조가 예상과 다릅니다."
}

if (
    -not $SharedAuth.Contains("export async function refreshSession") -or
    -not $SharedAuth.Contains("export async function authorizedFetch")
) {
    throw "9부 인증 클라이언트 구조가 예상과 다릅니다."
}

if (
    -not $SharedProvider.Contains("export function AuthProvider") -or
    -not $SharedProvider.Contains("export function useAuth")
) {
    throw "9부 인증 Provider 구조가 예상과 다릅니다."
}

if (-not $Part9Layout.Contains("<AuthProvider>")) {
    throw "9부 레이아웃 구조가 예상과 다릅니다."
}

if (
    -not $ApiClient.Contains("export const tokenMemory") -or
    -not $ApiClient.Contains("async function refreshWebSession")
) {
    throw "공통 API 클라이언트 구조가 예상과 다릅니다."
}

Write-Host "[확인] 기존 인증 구조 검사 완료" -ForegroundColor Green

# ============================================================
# 4. 기존 파일 백업
# ============================================================

$Backup = Join-Path $env:USERPROFILE (
    "Desktop\starter-part10-backup-" +
    (Get-Date -Format "yyyyMMdd_HHmmss")
)

New-Item -ItemType Directory -Path $Backup -Force |
    Out-Null

foreach ($RelativePath in $Files) {

    $Source = Join-Path $Root $RelativePath

    $Destination = Join-Path $Backup $RelativePath

    $Directory = Split-Path $Destination -Parent

    New-Item -ItemType Directory -Path $Directory -Force |
        Out-Null

    Copy-Item `
        -LiteralPath $Source `
        -Destination $Destination
}

Write-Host "[완료] 기존 파일 백업" -ForegroundColor Green
Write-Host "백업 위치: $Backup"

# ============================================================
# 5. 파일 저장 함수
# ============================================================

function Save-Source {

    param(
        [string]$RelativePath,
        [string]$Content
    )

    $FullPath = Join-Path $Root $RelativePath

    if (-not (Test-Path $FullPath)) {
        throw "수정 대상 파일이 없습니다: $RelativePath"
    }

    [System.IO.File]::WriteAllText(
        $FullPath,
        $Content,
        $Utf8NoBom
    )

    Write-Host "[수정 완료] $RelativePath" -ForegroundColor Green
}

# ============================================================
# 6. 정규식 기반 안전한 코드 교체 함수
# ============================================================

function Replace-Once {

    param(
        [string]$Content,
        [string]$Pattern,
        [string]$Replacement,
        [string]$Description
    )

    $Matches = [regex]::Matches(
        $Content,
        $Pattern
    )

    if ($Matches.Count -ne 1) {
        throw "$Description 교체 대상이 정확히 1개가 아닙니다. 발견: $($Matches.Count)"
    }

    $Match = $Matches[0]

    return (
        $Content.Substring(0, $Match.Index) +
        $Replacement +
        $Content.Substring($Match.Index + $Match.Length)
    )
}

# ============================================================
# 7. 파일 수정 시작
# ============================================================

try {

# ============================================================
# 7-1. 공통 인증 클라이언트
# ============================================================

Save-Source "apps/web/src/shared/auth/auth-client.ts" @'
// filepath: apps/web/src/shared/auth/auth-client.ts - 웹 공통 인증 API와 단일 Access Token 저장소 및 안전한 세션 갱신
"use client";

// ============================================================
// API 주소
// ============================================================

const configuredUrl =
  process.env.NEXT_PUBLIC_API_BASE_URL ??
  process.env.NEXT_PUBLIC_API_URL ??
  "http://localhost:4000";

const API_ORIGIN = new URL(configuredUrl).origin;

export const AUTH_API_BASE_URL = `${API_ORIGIN}/api/v1`;

// ============================================================
// 인증 사용자
// ============================================================

export interface AuthUser {
  id: string;
  email: string;
  name: string;
  createdAt: string;
  updatedAt: string;
}

export interface AuthResult {
  accessToken: string;
  user?: AuthUser;
}

// ============================================================
// API 응답 규격
// ============================================================

interface ApiEnvelope<T> {
  success: boolean;
  data?: T;
  message?: string;
  errorCode?: string;
}

// ============================================================
// 인증 오류
// ============================================================

export class AuthRequestError extends Error {

  constructor(
    public readonly status: number,
    public readonly errorCode: string,
    message: string
  ) {

    super(message);

    this.name = "AuthRequestError";
  }
}

// ============================================================
// 단일 Access Token 저장소
// ============================================================

// Access Token은 브라우저 메모리에만 보관합니다.
// localStorage 및 sessionStorage에는 저장하지 않습니다.

let accessToken: string | null = null;

// 오래된 비동기 요청이 로그아웃 이후
// 인증 상태를 복구하지 못하도록 세대를 관리합니다.

let sessionGeneration = 0;

// Refresh Token 회전 요청을 중복 실행하지 않습니다.

let refreshPromise: Promise<AuthResult | null> | null = null;

// ============================================================
// Access Token 조회
// ============================================================

export function getAccessToken(): string | null {

  return accessToken;
}

// ============================================================
// Access Token 저장
// ============================================================

export function setAccessToken(token: string): void {

  sessionGeneration++;

  accessToken = token;
}

// ============================================================
// Access Token 삭제
// ============================================================

export function clearAccessToken(): void {

  sessionGeneration++;

  accessToken = null;
}

// ============================================================
// 인증 만료 이벤트
// ============================================================

export const AUTH_EXPIRED_EVENT = "starter:auth-expired";

export function expireSession(): void {

  clearAccessToken();

  if (typeof window !== "undefined") {

    window.dispatchEvent(
      new Event(AUTH_EXPIRED_EVENT)
    );
  }
}

// ============================================================
// API 응답 처리
// ============================================================

export async function readAuthApiResponse<T>(
  response: Response
): Promise<T> {

  const payload = await response
    .json()
    .catch(() => null) as ApiEnvelope<T> | null;

  if (
    !response.ok ||
    !payload ||
    payload.success !== true
  ) {

    throw new AuthRequestError(
      response.status,
      payload?.errorCode ?? "API_ERROR",
      payload?.message ??
        "서버 요청을 처리하지 못했습니다."
    );
  }

  if (payload.data === undefined) {

    throw new AuthRequestError(
      response.status,
      "INVALID_RESPONSE",
      "서버 응답 데이터가 올바르지 않습니다."
    );
  }

  return payload.data;
}

// ============================================================
// 인증 API POST 요청
// ============================================================

async function postJson<T>(
  path: string,
  body?: unknown
): Promise<T> {

  const headers = new Headers();

  headers.set(
    "Accept",
    "application/json"
  );

  if (body !== undefined) {

    headers.set(
      "Content-Type",
      "application/json; charset=utf-8"
    );
  }

  const response = await fetch(
    `${AUTH_API_BASE_URL}${path}`,
    {
      method: "POST",

      credentials: "include",

      cache: "no-store",

      headers,

      body:
        body === undefined
          ? undefined
          : JSON.stringify(body)
    }
  );

  return readAuthApiResponse<T>(response);
}

// ============================================================
// 인증 응답 검증
// ============================================================

function validateAuthResult(
  result: AuthResult,
  requireUser: boolean
): AuthResult {

  if (
    !result ||
    typeof result.accessToken !== "string" ||
    result.accessToken.length === 0
  ) {

    throw new AuthRequestError(
      500,
      "INVALID_AUTH_RESPONSE",
      "서버 인증 응답이 올바르지 않습니다."
    );
  }

  if (requireUser) {

    const user = result.user;

    if (
      !user ||
      typeof user.id !== "string" ||
      typeof user.email !== "string" ||
      typeof user.name !== "string"
    ) {

      throw new AuthRequestError(
        500,
        "INVALID_USER_RESPONSE",
        "회원 정보가 올바르지 않습니다."
      );
    }
  }

  return result;
}

// ============================================================
// 로그인
// ============================================================

export async function loginRequest(
  email: string,
  password: string
): Promise<AuthResult> {

  const result = validateAuthResult(
    await postJson<AuthResult>(
      "/auth/web/login",
      {
        email,
        password
      }
    ),
    true
  );

  setAccessToken(result.accessToken);

  return result;
}

// ============================================================
// 회원가입
// ============================================================

export async function registerRequest(
  email: string,
  password: string,
  name: string
): Promise<AuthResult> {

  const result = validateAuthResult(
    await postJson<AuthResult>(
      "/auth/web/register",
      {
        email,
        password,
        name
      }
    ),
    true
  );

  setAccessToken(result.accessToken);

  return result;
}

// ============================================================
// Refresh Token 갱신
// ============================================================

// 웹에서는 Refresh Token을 JavaScript로 읽지 않습니다.
// HttpOnly 쿠키가 브라우저에 의해 자동으로 전달됩니다.
//
// 동시에 여러 API가 토큰 갱신을 요청하더라도
// 하나의 Promise를 공유합니다.

export async function refreshSession():
  Promise<AuthResult | null> {

  if (refreshPromise) {

    return refreshPromise;
  }

  const generation = sessionGeneration;

  const task = (async (): Promise<AuthResult | null> => {

    try {

      const result = validateAuthResult(
        await postJson<AuthResult>(
          "/auth/web/refresh"
        ),
        false
      );

      // 요청 도중 로그아웃 또는 새 로그인이 발생했다면
      // 이전 Refresh 결과를 사용하지 않습니다.

      if (generation !== sessionGeneration) {

        return null;
      }

      accessToken = result.accessToken;

      return result;

    }
    catch {

      if (generation === sessionGeneration) {

        accessToken = null;
      }

      return null;
    }

  })();

  refreshPromise = task;

  try {

    return await task;

  }
  finally {

    if (refreshPromise === task) {

      refreshPromise = null;
    }
  }
}

// ============================================================
// 현재 사용자 조회
// ============================================================

export async function fetchCurrentUser():
  Promise<AuthUser> {

  const response = await authorizedFetch(
    "/auth/me",
    {
      method: "GET"
    }
  );

  return readAuthApiResponse<AuthUser>(response);
}

// ============================================================
// 로그아웃
// ============================================================

export async function logoutRequest(): Promise<void> {

  // 서버가 Refresh Token 세션을 폐기한 경우에만
  // 로컬 Access Token을 제거합니다.

  await postJson<{
    loggedOut: boolean;
  }>(
    "/auth/web/logout"
  );

  clearAccessToken();
}

// ============================================================
// 전체 기기 로그아웃
// ============================================================

export async function logoutAllRequest(): Promise<void> {

  const response = await authorizedFetch(
    "/auth/logout-all",
    {
      method: "POST"
    }
  );

  await readAuthApiResponse<{
    loggedOut: boolean;
  }>(response);

  clearAccessToken();
}

// ============================================================
// 안전한 API 요청 경로
// ============================================================

function createAuthorizedUrl(path: string): string {

  if (
    !path.startsWith("/") ||
    path.startsWith("//") ||
    path.includes("\\") ||
    path.includes("#")
  ) {

    throw new AuthRequestError(
      0,
      "INVALID_API_PATH",
      "API 요청 경로가 올바르지 않습니다."
    );
  }

  const url = new URL(
    `${AUTH_API_BASE_URL}${path}`
  );

  if (
    url.origin !== API_ORIGIN ||
    !url.pathname.startsWith("/api/v1/")
  ) {

    throw new AuthRequestError(
      0,
      "INVALID_API_PATH",
      "허용되지 않은 API 요청 경로입니다."
    );
  }

  return url.toString();
}

// ============================================================
// 인증된 API 요청
// ============================================================

// GET 및 HEAD만 인증 갱신 후 자동 재시도합니다.
//
// POST, PUT, PATCH, DELETE는 중복 실행을 방지하기 위해
// 자동 재전송하지 않습니다.

export async function authorizedFetch(
  path: string,
  options: RequestInit = {}
): Promise<Response> {

  const requestUrl = createAuthorizedUrl(path);

  const method = (
    options.method ?? "GET"
  ).toUpperCase();

  const canRetry =
    method === "GET" ||
    method === "HEAD";

  // Access Token이 없으면 Refresh Cookie로 복구합니다.

  if (!accessToken) {

    const refreshed = await refreshSession();

    if (!refreshed) {

      expireSession();

      throw new AuthRequestError(
        401,
        "UNAUTHORIZED",
        "로그인이 필요합니다."
      );
    }
  }

  // ==========================================================
  // 실제 요청
  // ==========================================================

  const send = async (
    token: string
  ): Promise<Response> => {

    const headers = new Headers(
      options.headers
    );

    // 호출자가 전달한 Authorization을 그대로 신뢰하지 않고
    // 공통 인증 저장소의 토큰으로 설정합니다.

    headers.set(
      "Authorization",
      `Bearer ${token}`
    );

    return fetch(
      requestUrl,
      {
        ...options,

        method,

        headers,

        credentials: "include",

        cache: "no-store"
      }
    );
  };

  const initialToken = accessToken;

  if (!initialToken) {

    expireSession();

    throw new AuthRequestError(
      401,
      "UNAUTHORIZED",
      "로그인이 필요합니다."
    );
  }

  let response = await send(initialToken);

  if (response.status !== 401) {

    return response;
  }

  // ==========================================================
  // 401 응답 처리
  // ==========================================================

  // 다른 요청이 이미 토큰을 갱신했다면
  // 다시 Refresh 요청을 보내지 않습니다.

  let renewedToken = accessToken;

  if (renewedToken === initialToken) {

    const refreshed = await refreshSession();

    renewedToken = refreshed?.accessToken ?? null;
  }

  if (!renewedToken) {

    expireSession();

    throw new AuthRequestError(
      401,
      "SESSION_EXPIRED",
      "로그인 세션이 만료되었습니다."
    );
  }

  // 변경 요청은 자동 재실행하지 않습니다.

  if (!canRetry) {

    throw new AuthRequestError(
      401,
      "RETRY_REQUIRED",
      "인증이 갱신되었습니다. 요청을 다시 실행해 주세요."
    );
  }

  // 조회 요청만 한 번 재시도합니다.

  response = await send(renewedToken);

  if (response.status === 401) {

    expireSession();

    throw new AuthRequestError(
      401,
      "SESSION_EXPIRED",
      "로그인 세션이 만료되었습니다."
    );
  }

  return response;
}
'@

# ============================================================
# 7-2. 공통 인증 Provider
# ============================================================

Save-Source "apps/web/src/shared/auth/auth-provider.tsx" @'
// filepath: apps/web/src/shared/auth/auth-provider.tsx - 전체 Starter 화면의 단일 인증 상태와 세션 복구 및 탭 간 로그아웃 동기화
"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState
} from "react";

import type {
  ReactNode
} from "react";

import {
  AUTH_EXPIRED_EVENT,
  authorizedFetch,
  clearAccessToken,
  fetchCurrentUser,
  loginRequest,
  logoutAllRequest,
  logoutRequest,
  readAuthApiResponse,
  refreshSession,
  registerRequest
} from "./auth-client";

import type {
  AuthUser
} from "./auth-client";

// ============================================================
// 인증 상태
// ============================================================

export type AuthStatus =
  | "checking"
  | "authenticated"
  | "guest";

// ============================================================
// 인증 Context
// ============================================================

interface AuthContextValue {

  status: AuthStatus;

  user: AuthUser | null;

  loading: boolean;

  login(
    email: string,
    password: string
  ): Promise<void>;

  register(
    email: string,
    password: string,
    name: string
  ): Promise<void>;

  logout(): Promise<void>;

  logoutAll(): Promise<void>;

  refresh(): Promise<boolean>;

  request<T>(
    path: string,
    options?: RequestInit
  ): Promise<T>;

  authorizedFetch(
    path: string,
    options?: RequestInit
  ): Promise<Response>;
}

const AuthContext =
  createContext<AuthContextValue | null>(null);

// ============================================================
// 탭 간 동기화
// ============================================================

const AUTH_CHANNEL = "starter-auth-events";

// ============================================================
// 공통 인증 Provider
// ============================================================

export function AuthProvider({
  children
}: {
  children: ReactNode;
}) {

  const [status, setStatus] =
    useState<AuthStatus>("checking");

  const [user, setUser] =
    useState<AuthUser | null>(null);

  // 오래된 초기화 요청이 새로운 로그인 상태를
  // 덮어쓰지 못하도록 작업 세대를 관리합니다.

  const revisionRef = useRef(0);

  const channelRef =
    useRef<BroadcastChannel | null>(null);

  // ==========================================================
  // 비로그인 상태 적용
  // ==========================================================

  const setGuest = useCallback(() => {

    setUser(null);

    setStatus("guest");

  }, []);

  // ==========================================================
  // 로그인 상태 적용
  // ==========================================================

  const setAuthenticated = useCallback(
    (currentUser: AuthUser) => {

      setUser(currentUser);

      setStatus("authenticated");

    },
    []
  );

  // ==========================================================
  // 초기 세션 복구
  // ==========================================================

  useEffect(() => {

    let active = true;

    const revision = revisionRef.current;

    const initialize = async () => {

      try {

        const result = await refreshSession();

        if (!result) {

          if (
            active &&
            revision === revisionRef.current
          ) {

            setGuest();
          }

          return;
        }

        // Refresh 응답에는 회원 정보가 없으므로
        // /auth/me API에서 사용자 정보를 가져옵니다.

        const currentUser =
          await fetchCurrentUser();

        if (
          active &&
          revision === revisionRef.current
        ) {

          setAuthenticated(currentUser);
        }

      }
      catch {

        if (
          active &&
          revision === revisionRef.current
        ) {

          clearAccessToken();

          setGuest();
        }
      }
    };

    void initialize();

    // ========================================================
    // 인증 만료 이벤트
    // ========================================================

    const handleExpired = () => {

      revisionRef.current++;

      setGuest();
    };

    window.addEventListener(
      AUTH_EXPIRED_EVENT,
      handleExpired
    );

    // ========================================================
    // 다른 브라우저 탭의 로그아웃
    // ========================================================

    if (typeof BroadcastChannel !== "undefined") {

      const channel =
        new BroadcastChannel(AUTH_CHANNEL);

      channelRef.current = channel;

      channel.onmessage = (event) => {

        if (event.data === "logout") {

          revisionRef.current++;

          clearAccessToken();

          setGuest();
        }
      };
    }

    return () => {

      active = false;

      window.removeEventListener(
        AUTH_EXPIRED_EVENT,
        handleExpired
      );

      channelRef.current?.close();

      channelRef.current = null;
    };

  }, [
    setAuthenticated,
    setGuest
  ]);

  // ==========================================================
  // 로그인
  // ==========================================================

  const login = useCallback(
    async (
      email: string,
      password: string
    ) => {

      const revision = ++revisionRef.current;

      const result = await loginRequest(
        email,
        password
      );

      if (!result.user) {

        throw new Error(
          "로그인 사용자 정보가 없습니다."
        );
      }

      if (revision === revisionRef.current) {

        setAuthenticated(result.user);
      }

    },
    [setAuthenticated]
  );

  // ==========================================================
  // 회원가입
  // ==========================================================

  const register = useCallback(
    async (
      email: string,
      password: string,
      name: string
    ) => {

      const revision = ++revisionRef.current;

      const result = await registerRequest(
        email,
        password,
        name
      );

      if (!result.user) {

        throw new Error(
          "회원가입 사용자 정보가 없습니다."
        );
      }

      if (revision === revisionRef.current) {

        setAuthenticated(result.user);
      }

    },
    [setAuthenticated]
  );

  // ==========================================================
  // 다른 탭에 로그아웃 알림
  // ==========================================================

  const broadcastLogout = useCallback(() => {

    channelRef.current?.postMessage("logout");

  }, []);

  // ==========================================================
  // 현재 기기 로그아웃
  // ==========================================================

  const logout = useCallback(async () => {

    revisionRef.current++;

    await logoutRequest();

    setGuest();

    broadcastLogout();

  }, [
    setGuest,
    broadcastLogout
  ]);

  // ==========================================================
  // 전체 기기 로그아웃
  // ==========================================================

  const logoutAll = useCallback(async () => {

    revisionRef.current++;

    await logoutAllRequest();

    setGuest();

    broadcastLogout();

  }, [
    setGuest,
    broadcastLogout
  ]);

  // ==========================================================
  // 수동 세션 갱신
  // ==========================================================

  const refresh = useCallback(
    async (): Promise<boolean> => {

      const revision = ++revisionRef.current;

      try {

        const result = await refreshSession();

        if (!result) {

          if (revision === revisionRef.current) {

            setGuest();
          }

          return false;
        }

        const currentUser =
          await fetchCurrentUser();

        if (revision === revisionRef.current) {

          setAuthenticated(currentUser);
        }

        return true;

      }
      catch {

        if (revision === revisionRef.current) {

          clearAccessToken();

          setGuest();
        }

        return false;
      }

    },
    [
      setAuthenticated,
      setGuest
    ]
  );

  // ==========================================================
  // 인증된 HTTP 요청
  // ==========================================================

  const fetchAuthorized = useCallback(
    async (
      path: string,
      options: RequestInit = {}
    ): Promise<Response> => {

      return authorizedFetch(path, options);

    },
    []
  );

  // ==========================================================
  // 표준 JSON API 요청
  // ==========================================================

  const request = useCallback(
    async <T,>(
      path: string,
      options: RequestInit = {}
    ): Promise<T> => {

      const response = await fetchAuthorized(
        path,
        options
      );

      return readAuthApiResponse<T>(response);

    },
    [fetchAuthorized]
  );

  // ==========================================================
  // Context 값
  // ==========================================================

  const value = useMemo<AuthContextValue>(
    () => ({

      status,

      user,

      loading: status === "checking",

      login,

      register,

      logout,

      logoutAll,

      refresh,

      request,

      authorizedFetch: fetchAuthorized

    }),
    [
      status,
      user,
      login,
      register,
      logout,
      logoutAll,
      refresh,
      request,
      fetchAuthorized
    ]
  );

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

// ============================================================
// 인증 상태 Hook
// ============================================================

export function useAuth(): AuthContextValue {

  const context = useContext(AuthContext);

  if (!context) {

    throw new Error(
      "AuthProvider 내부에서 useAuth를 사용해야 합니다."
    );
  }

  return context;
}
'@

# ============================================================
# 7-3. 기존 Starter 인증 모듈 호환 계층
# ============================================================

# 기존 화면의 import 경로를 유지합니다.
# 인증 상태는 shared/auth/auth-provider.tsx에서 관리합니다.

Save-Source "apps/web/src/app/starter/_lib/auth.tsx" @'
// filepath: apps/web/src/app/starter/_lib/auth.tsx - 기존 Starter 화면과 통합 인증 Provider의 호환성을 유지하는 연결 모듈
"use client";

// ============================================================
// 기존 Starter 인증 인터페이스 호환
// ============================================================

// 기존 로그인, 회원가입, 게시글, 파일 관리 화면은
// 이 모듈의 useAuth를 그대로 사용할 수 있습니다.
//
// 실제 인증 상태와 토큰 관리는
// shared/auth 모듈에서 단일화하여 처리합니다.

export {
  AuthProvider,
  useAuth
} from "../../../shared/auth/auth-provider";
'@

# ============================================================
# 7-4. 9부 중복 Provider 제거
# ============================================================

Save-Source "apps/web/src/app/starter/toolkit/part9/layout.tsx" @'
// filepath: apps/web/src/app/starter/toolkit/part9/layout.tsx - 상위 통합 인증 Provider를 재사용하고 Toast Provider만 연결
import type {
  ReactNode
} from "react";

import {
  ToastProvider
} from "../../../../shared/ui/toast";

// ============================================================
// 9부 공통 레이아웃
// ============================================================

// 인증 Provider는 /starter/layout.tsx에서
// 이미 전체 Starter 화면에 적용됩니다.
//
// 여기서 다시 생성하면 인증 상태가 중복되므로
// Toast Provider만 연결합니다.

export default function Part9Layout({
  children
}: {
  children: ReactNode;
}) {

  return (
    <ToastProvider>
      {children}
    </ToastProvider>
  );
}
'@

# ============================================================
# 7-5. 공통 API 클라이언트 인증 저장소 통합
# ============================================================

# 기존 API 클라이언트의 타임아웃, 오류 처리,
# 요청 검증 및 모바일 확장 인터페이스는 보존합니다.
#
# 인증 토큰 저장소와 Refresh 로직만 연결합니다.

$Content = $ApiClient

# ------------------------------------------------------------
# 공통 인증 모듈 import 추가
# ------------------------------------------------------------

$Content = Replace-Once `
    -Content $Content `
    -Pattern '(?m)^(?=// ============================================================\r?\n// API 기본 설정)' `
    -Replacement @'
import {
  getAccessToken,
  setAccessToken,
  clearAccessToken,
  expireSession,
  refreshSession
} from "../auth/auth-client";

'@ `
    -Description "공통 인증 모듈 import"

# ------------------------------------------------------------
# 기존 독립 토큰 저장소 교체
# ------------------------------------------------------------

$Content = Replace-Once `
    -Content $Content `
    -Pattern '(?s)let accessToken: string \| null = null;\s*export const tokenMemory = \{.*?\r?\n\};' `
    -Replacement @'
export const tokenMemory = {

  get(): string | null {
    return getAccessToken();
  },

  set(token: string): void {
    setAccessToken(token);
  },

  clear(): void {
    clearAccessToken();
  }
};
'@ `
    -Description "Access Token 저장소"

# ------------------------------------------------------------
# Refresh Token 갱신 함수 통합
# ------------------------------------------------------------

$Content = Replace-Once `
    -Content $Content `
    -Pattern '(?s)async function refreshWebSession\(\): Promise<string \| null> \{.*?\r?\n\}' `
    -Replacement @'
async function refreshWebSession(): Promise<string | null> {

  const result = await refreshSession();

  return result?.accessToken ?? null;
}
'@ `
    -Description "Refresh Token 갱신"

# ------------------------------------------------------------
# 갱신된 토큰 저장 처리
# ------------------------------------------------------------

$Content = Replace-Once `
    -Content $Content `
    -Pattern '(?s)tokenMemory\.set\(renewedToken\);\s*clientOptions\.onAccessToken\?\.\(\s*renewedToken\s*\);' `
    -Replacement @'
if (!clientOptions.getAccessToken) {

          tokenMemory.set(renewedToken);
        }

        clientOptions.onAccessToken?.(
          renewedToken
        );
'@ `
    -Description "갱신 토큰 저장"

# ------------------------------------------------------------
# 변경 요청의 자동 재전송 제한
# ------------------------------------------------------------

$Content = Replace-Once `
    -Content $Content `
    -Pattern '(?s)// 원래 요청을 한 번만 재시도합니다\.\s*response = await send\(\s*options,\s*renewedToken\s*\);' `
    -Replacement @'
// 조회 요청만 자동으로 한 번 재시도합니다.
        // 변경 요청은 중복 실행을 방지합니다.

        const method = options.method ?? "GET";

        if (method === "GET") {

          response = await send(
            options,
            renewedToken
          );

        }
        else {

          throw new ApiClientError(
            401,
            "RETRY_REQUIRED",
            "인증이 갱신되었습니다. 요청을 다시 실행해 주세요."
          );
        }
'@ `
    -Description "안전한 요청 재시도"

# ------------------------------------------------------------
# 인증 만료 처리 통합
# ------------------------------------------------------------

$Content = Replace-Once `
    -Content $Content `
    -Pattern '(?s)tokenMemory\.clear\(\);\s*clientOptions\.onAccessToken\?\.\(null\);\s*clientOptions\.onUnauthorized\?\.\(\);' `
    -Replacement @'
if (!clientOptions.getAccessToken) {

          expireSession();
        }

        clientOptions.onAccessToken?.(null);

        clientOptions.onUnauthorized?.();
'@ `
    -Description "인증 만료 처리"

Save-Source "apps/web/src/shared/api/client.ts" $Content

# ============================================================
# 8. 수정 파일 저장 상태 확인
# ============================================================

foreach ($RelativePath in $Files) {

    $FullPath = Join-Path $Root $RelativePath

    $SavedContent = [System.IO.File]::ReadAllText($FullPath)

    if (-not $SavedContent.StartsWith("// filepath:")) {
        throw "파일 최상단 주석이 없습니다: $RelativePath"
    }
}

Write-Host ""
Write-Host "[완료] 인증 통합 파일 저장 확인" -ForegroundColor Green

# ============================================================
# 9. 프론트엔드 빌드
# ============================================================

Write-Host ""
Write-Host "============================================"
Write-Host " 프론트엔드 빌드 확인"
Write-Host "============================================"
Write-Host ""

npm run build -w @starter/web

if ($LASTEXITCODE -ne 0) {
    throw "프론트엔드 빌드에 실패했습니다."
}

# ============================================================
# 10. 작업 완료
# ============================================================

Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host " 10부 인증 시스템 통합 완료"
Write-Host "============================================" -ForegroundColor Green
Write-Host ""

Write-Host "[완료] 인증 Provider 단일화" -ForegroundColor Green
Write-Host "[완료] Access Token 저장소 통합" -ForegroundColor Green
Write-Host "[완료] Refresh Token 갱신 로직 통합" -ForegroundColor Green
Write-Host "[완료] 기존 Starter 인증 인터페이스 유지" -ForegroundColor Green
Write-Host "[완료] 9부 중복 Provider 제거" -ForegroundColor Green
Write-Host "[완료] 변경 요청 자동 재전송 제한" -ForegroundColor Green
Write-Host "[완료] 프론트엔드 빌드 성공" -ForegroundColor Green

Write-Host ""
Write-Host "수정 파일: $($Files.Count)개"
Write-Host "백업 위치: $Backup"
Write-Host "데이터베이스 변경: 없음"
Write-Host "패키지 설치 및 변경: 없음"
Write-Host ""

}
catch {

    $FailureMessage = $_.Exception.Message

    Write-Host ""
    Write-Host "[오류] 10부 작업에 문제가 발생했습니다." -ForegroundColor Red
    Write-Host $FailureMessage -ForegroundColor Red

    Write-Host ""
    Write-Host "기존 파일을 복원합니다." -ForegroundColor Yellow

    $RestoreErrors = @()

    foreach ($RelativePath in $Files) {

        $Source = Join-Path $Backup $RelativePath

        $Destination = Join-Path $Root $RelativePath

        try {

            if (Test-Path $Source) {

                Copy-Item `
                    -LiteralPath $Source `
                    -Destination $Destination `
                    -Force

                Write-Host "[복원] $RelativePath" -ForegroundColor Yellow
            }

        }
        catch {

            $RestoreErrors += $RelativePath

            Write-Host "[복원 실패] $RelativePath" -ForegroundColor Red
        }
    }

    if ($RestoreErrors.Count -gt 0) {

        Write-Host ""
        Write-Host "일부 파일의 자동 복원에 실패했습니다." -ForegroundColor Red
        Write-Host "백업 위치: $Backup" -ForegroundColor Yellow
    }
    else {

        Write-Host ""
        Write-Host "[완료] 기존 소스코드 복원" -ForegroundColor Green
    }

    throw "10부 인증 통합 실패: $FailureMessage"
}

