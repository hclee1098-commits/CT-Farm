﻿# filepath: create-starter-part3.ps1 - 게시글 CRUD 및 검색, 정렬, 페이징 공통 모듈 생성

$ErrorActionPreference = "Stop"

# ============================================================
# 1. 프로젝트 경로 설정
# ============================================================

$Root = Join-Path $PSScriptRoot "secure-starter"

# 보안 검토가 끝난 프로젝트에 예전 생성 코드를 덮어쓰지 않습니다.
if (Test-Path -LiteralPath (Join-Path $Root "SECURITY-REVISION.json")) {
    throw "보안 수정이 적용된 V5입니다. 이전 부별 생성 스크립트 적용을 차단합니다."
}


if (-not (Test-Path $Root)) {
    throw "secure-starter 프로젝트가 없습니다. 1부를 먼저 생성하세요."
}

# ============================================================
# 2. 필수 파일 확인
# ============================================================

$RequiredFiles = @(
    "apps/api/prisma/schema.prisma",
    "apps/api/src/common/errors.ts",
    "apps/api/src/common/response.ts",
    "apps/api/src/common/validate.ts",
    "apps/api/src/common/pagination.ts",
    "apps/api/src/common/auth.middleware.ts",
    "apps/api/src/infrastructure/prisma.ts",
    "apps/api/src/modules/auth/auth.controller.ts"
)

foreach ($RelativePath in $RequiredFiles) {

    $FullPath = Join-Path $Root $RelativePath

    if (-not (Test-Path $FullPath)) {
        throw "필수 파일이 없습니다: $RelativePath"
    }
}

# Prisma에 Note 모델이 존재하는지 확인합니다.
$SchemaPath = Join-Path $Root "apps/api/prisma/schema.prisma"

$SchemaContent = Get-Content `
    -LiteralPath $SchemaPath `
    -Raw `
    -Encoding UTF8

if ($SchemaContent -notmatch "model\s+Note\s*\{") {
    throw "Prisma 스키마에 Note 모델이 없습니다."
}

# ============================================================
# 3. 파일 저장 함수
# ============================================================

$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)

function Save-Source3 {

    param(
        [string]$RelativePath,
        [string]$Description,
        [string]$Content
    )

    $FullPath = Join-Path $Root $RelativePath

    $Directory = Split-Path $FullPath -Parent

    # 기존 파일을 덮어쓰지 않습니다.
    if (Test-Path $FullPath) {

        throw "기존 파일을 보호하기 위해 중단합니다: $RelativePath"
    }

    if (-not (Test-Path $Directory)) {

        New-Item `
            -ItemType Directory `
            -Path $Directory `
            -Force | Out-Null
    }

    $Extension = [System.IO.Path]::GetExtension($RelativePath)

    $Header = switch ($Extension) {

        ".ts" {
            "// filepath: $RelativePath - $Description`n"
        }

        ".tsx" {
            "// filepath: $RelativePath - $Description`n"
        }

        ".md" {
            "<!-- filepath: $RelativePath - $Description -->`n"
        }

        default {
            "# filepath: $RelativePath - $Description`n"
        }
    }

    $FinalContent = $Header + $Content

    [System.IO.File]::WriteAllText(
        $FullPath,
        $FinalContent,
        $Utf8NoBom
    )

    Write-Host "[생성 완료] $RelativePath" -ForegroundColor Green
}

# ============================================================
# 4. 생성 대상 파일 사전 검사
# ============================================================

$OutputFiles = @(
    "apps/api/src/modules/notes/notes.dto.ts",
    "apps/api/src/modules/notes/notes.repository.ts",
    "apps/api/src/modules/notes/notes.service.ts",
    "apps/api/src/modules/notes/notes.controller.ts",
    "apps/api/src/modules/notes/notes.dto.test.ts",
    "apps/api/src/modules/notes/README.md"
)

foreach ($RelativePath in $OutputFiles) {

    $FullPath = Join-Path $Root $RelativePath

    if (Test-Path $FullPath) {
        throw "이미 생성된 파일이 있습니다: $RelativePath"
    }
}

Write-Host ""
Write-Host "=========================================="
Write-Host " 3부 CRUD 공통 모듈 생성 시작"
Write-Host "=========================================="
Write-Host ""


# ============================================================
# 5. DTO - 요청 데이터 검증
# ============================================================

Save-Source3 "apps/api/src/modules/notes/notes.dto.ts" "게시글 등록, 수정, 검색, 정렬, 페이징 요청값 검증" @'
import { z } from "zod";

import {
  paginationSchema
} from "../../common/pagination";

// ============================================================
// 게시글 제목 검증
// ============================================================

const titleSchema = z.string()
  .trim()
  .min(
    1,
    "제목을 입력해 주세요."
  )
  .max(
    120,
    "제목은 최대 120자까지 입력할 수 있습니다."
  );

// ============================================================
// 게시글 내용 검증
// ============================================================

const contentSchema = z.string()
  .trim()
  .min(
    1,
    "내용을 입력해 주세요."
  )
  .max(
    10000,
    "내용은 최대 10,000자까지 입력할 수 있습니다."
  );

// ============================================================
// 게시글 등록 요청
// ============================================================

export const createNoteSchema = z.object({

  title: titleSchema,

  content: contentSchema

}).strict();

// ============================================================
// 게시글 전체 수정 요청
// ============================================================

export const replaceNoteSchema = createNoteSchema;

// ============================================================
// 게시글 부분 수정 요청
// ============================================================

// PATCH 요청은 제목이나 내용 중 하나만 전달해도 됩니다.
// 단, 빈 객체는 허용하지 않습니다.

export const updateNoteSchema = createNoteSchema
  .partial()
  .refine(
    (data) => Object.keys(data).length > 0,
    {
      message: "수정할 항목을 하나 이상 입력해 주세요."
    }
  );

// ============================================================
// 정렬 가능한 필드
// ============================================================

// 클라이언트가 임의의 DB 필드를 지정하지 못하도록
// 정렬 필드를 명시적으로 제한합니다.

export const noteSortFields = [
  "createdAt",
  "updatedAt",
  "title"
] as const;

// ============================================================
// 게시글 목록 조회
// ============================================================

export const listNotesSchema = paginationSchema
  .extend({

    // 페이지 번호의 상한을 설정하여
    // 지나치게 큰 오프셋 요청을 제한합니다.
    page: z.coerce.number()
      .int()
      .min(1)
      .max(1000000)
      .default(1),

    sortBy: z.enum(noteSortFields)
      .default("createdAt"),

    sortOrder: z.enum([
      "asc",
      "desc"
    ]).default("desc")

  })
  .strict();

// ============================================================
// 타입 정의
// ============================================================

export type CreateNoteInput =
  z.infer<typeof createNoteSchema>;

export type ReplaceNoteInput =
  z.infer<typeof replaceNoteSchema>;

export type UpdateNoteInput =
  z.infer<typeof updateNoteSchema>;

export type ListNotesQuery =
  z.infer<typeof listNotesSchema>;
'@


# ============================================================
# 6. Repository - 데이터베이스 접근
# ============================================================

Save-Source3 "apps/api/src/modules/notes/notes.repository.ts" "Prisma를 이용한 게시글 데이터 접근 및 소유권 검사" @'
import {
  Prisma
} from "@prisma/client";

import {
  prisma
} from "../../infrastructure/prisma";

import {
  AppError
} from "../../common/errors";

import type {
  CreateNoteInput,
  ReplaceNoteInput,
  UpdateNoteInput,
  ListNotesQuery
} from "./notes.dto";

// ============================================================
// 게시글 응답 필드
// ============================================================

// DB에 새로운 민감 필드가 추가되더라도
// 자동으로 API 응답에 포함되지 않도록
// 반환 필드를 명시적으로 지정합니다.

const noteSelect = {
  id: true,
  title: true,
  content: true,
  createdAt: true,
  updatedAt: true
} as const;

// ============================================================
// 게시글 Repository
// ============================================================

export const notesRepository = {

  // ----------------------------------------------------------
  // 게시글 등록
  // ----------------------------------------------------------

  async create(
    ownerId: string,
    input: CreateNoteInput
  ) {

    return prisma.note.create({

      data: {
        ownerId,
        title: input.title,
        content: input.content
      },

      select: noteSelect

    });
  },

  // ----------------------------------------------------------
  // 게시글 목록 조회
  // ----------------------------------------------------------

  async findPage(
    ownerId: string,
    query: ListNotesQuery
  ) {

    const {
      page,
      limit,
      search,
      sortBy,
      sortOrder
    } = query;

    // 반드시 로그인한 사용자 소유의 게시글만 검색합니다.
    const where: Prisma.NoteWhereInput = {

      ownerId,

      ...(search
        ? {
            OR: [
              {
                title: {
                  contains: search,
                  mode: "insensitive" as const
                }
              },
              {
                content: {
                  contains: search,
                  mode: "insensitive" as const
                }
              }
            ]
          }
        : {})

    };

    // 정렬 필드는 DTO에서 허용된 값만 전달됩니다.
    const orderBy: Prisma.NoteOrderByWithRelationInput = {
      [sortBy]: sortOrder
    };

    const skip = (page - 1) * limit;

    // 목록과 전체 개수를 트랜잭션으로 조회합니다.
    const [items, total] = await prisma.$transaction([

      prisma.note.findMany({

        where,

        select: noteSelect,

        orderBy: [
          orderBy,
          {
            id: "asc"
          }
        ],

        skip,

        take: limit

      }),

      prisma.note.count({
        where
      })

    ]);

    return {
      items,
      total
    };
  },

  // ----------------------------------------------------------
  // 게시글 상세 조회
  // ----------------------------------------------------------

  async findById(
    ownerId: string,
    noteId: string
  ) {

    return prisma.note.findFirst({

      where: {
        id: noteId,
        ownerId
      },

      select: noteSelect

    });
  },

  // ----------------------------------------------------------
  // 게시글 전체 수정
  // ----------------------------------------------------------

  async replace(
    ownerId: string,
    noteId: string,
    input: ReplaceNoteInput
  ) {

    return prisma.$transaction(async (tx) => {

      // 게시글 ID와 사용자 ID를 동시에 검사합니다.
      // 소유권 확인과 수정을 하나의 DB 작업으로 수행합니다.
      const result = await tx.note.updateMany({

        where: {
          id: noteId,
          ownerId
        },

        data: {
          title: input.title,
          content: input.content
        }

      });

      if (result.count !== 1) {

        throw new AppError(
          404,
          "NOTE_NOT_FOUND",
          "게시글을 찾을 수 없습니다."
        );
      }

      return tx.note.findUniqueOrThrow({

        where: {
          id: noteId
        },

        select: noteSelect

      });
    });
  },

  // ----------------------------------------------------------
  // 게시글 부분 수정
  // ----------------------------------------------------------

  async update(
    ownerId: string,
    noteId: string,
    input: UpdateNoteInput
  ) {

    return prisma.$transaction(async (tx) => {

      // 다른 사용자의 게시글은 수정할 수 없습니다.
      const result = await tx.note.updateMany({

        where: {
          id: noteId,
          ownerId
        },

        data: {
          ...(input.title !== undefined
            ? { title: input.title }
            : {}),

          ...(input.content !== undefined
            ? { content: input.content }
            : {})
        }

      });

      if (result.count !== 1) {

        throw new AppError(
          404,
          "NOTE_NOT_FOUND",
          "게시글을 찾을 수 없습니다."
        );
      }

      return tx.note.findUniqueOrThrow({

        where: {
          id: noteId
        },

        select: noteSelect

      });
    });
  },

  // ----------------------------------------------------------
  // 게시글 삭제
  // ----------------------------------------------------------

  async delete(
    ownerId: string,
    noteId: string
  ) {

    // 삭제할 때도 사용자 소유권을 동시에 검사합니다.
    const result = await prisma.note.deleteMany({

      where: {
        id: noteId,
        ownerId
      }

    });

    if (result.count !== 1) {

      throw new AppError(
        404,
        "NOTE_NOT_FOUND",
        "게시글을 찾을 수 없습니다."
      );
    }

    return {
      id: noteId,
      deleted: true
    };
  }
};
'@


# ============================================================
# 7. Service - 비즈니스 로직
# ============================================================

Save-Source3 "apps/api/src/modules/notes/notes.service.ts" "게시글 CRUD 비즈니스 로직 및 공통 페이징 응답 처리" @'
import {
  AppError
} from "../../common/errors";

import {
  paginated
} from "../../common/pagination";

import {
  notesRepository
} from "./notes.repository";

import type {
  CreateNoteInput,
  ReplaceNoteInput,
  UpdateNoteInput,
  ListNotesQuery
} from "./notes.dto";

// ============================================================
// 게시글 서비스
// ============================================================

export const notesService = {

  // ----------------------------------------------------------
  // 게시글 등록
  // ----------------------------------------------------------

  async create(
    userId: string,
    input: CreateNoteInput
  ) {

    return notesRepository.create(
      userId,
      input
    );
  },

  // ----------------------------------------------------------
  // 게시글 목록 조회
  // ----------------------------------------------------------

  async list(
    userId: string,
    query: ListNotesQuery
  ) {

    const result = await notesRepository.findPage(
      userId,
      query
    );

    // 모든 목록 API에서 재사용할 수 있는
    // 표준 페이징 구조로 응답합니다.
    return paginated(
      result.items,
      result.total,
      query.page,
      query.limit
    );
  },

  // ----------------------------------------------------------
  // 게시글 상세 조회
  // ----------------------------------------------------------

  async getById(
    userId: string,
    noteId: string
  ) {

    const note = await notesRepository.findById(
      userId,
      noteId
    );

    if (!note) {

      // 다른 사용자의 게시글과 존재하지 않는 게시글을
      // 구분하지 않고 동일한 오류를 반환합니다.
      throw new AppError(
        404,
        "NOTE_NOT_FOUND",
        "게시글을 찾을 수 없습니다."
      );
    }

    return note;
  },

  // ----------------------------------------------------------
  // 게시글 전체 수정
  // ----------------------------------------------------------

  async replace(
    userId: string,
    noteId: string,
    input: ReplaceNoteInput
  ) {

    return notesRepository.replace(
      userId,
      noteId,
      input
    );
  },

  // ----------------------------------------------------------
  // 게시글 부분 수정
  // ----------------------------------------------------------

  async update(
    userId: string,
    noteId: string,
    input: UpdateNoteInput
  ) {

    return notesRepository.update(
      userId,
      noteId,
      input
    );
  },

  // ----------------------------------------------------------
  // 게시글 삭제
  // ----------------------------------------------------------

  async delete(
    userId: string,
    noteId: string
  ) {

    return notesRepository.delete(
      userId,
      noteId
    );
  }
};
'@


# ============================================================
# 8. Controller - REST API
# ============================================================

Save-Source3 "apps/api/src/modules/notes/notes.controller.ts" "게시글 등록, 조회, 수정, 삭제 REST API 라우터" @'
import {
  Router
} from "express";

import {
  requireAuth
} from "../../common/auth.middleware";

import {
  validate,
  asyncHandler,
  uuidSchema
} from "../../common/validate";

import {
  success
} from "../../common/response";

import {
  createNoteSchema,
  replaceNoteSchema,
  updateNoteSchema,
  listNotesSchema
} from "./notes.dto";

import type {
  CreateNoteInput,
  ReplaceNoteInput,
  UpdateNoteInput,
  ListNotesQuery
} from "./notes.dto";

import {
  notesService
} from "./notes.service";

// ============================================================
// 라우터 생성
// ============================================================

export const notesRouter = Router();

// 모든 게시글 API에 JWT 인증을 적용합니다.
notesRouter.use(requireAuth);

// ============================================================
// POST /api/v1/notes
// 게시글 등록
// ============================================================

notesRouter.post(
  "/",

  validate("body", createNoteSchema),

  asyncHandler(async (req, res) => {

    const userId = req.userId!;

    const input = req.body as CreateNoteInput;

    const note = await notesService.create(
      userId,
      input
    );

    success(
      res,
      note,
      "게시글이 등록되었습니다.",
      201
    );
  })
);

// ============================================================
// GET /api/v1/notes
// 게시글 목록 조회
// ============================================================

notesRouter.get(
  "/",

  validate("query", listNotesSchema),

  asyncHandler(async (req, res) => {

    const userId = req.userId!;

    const query = req.validated?.query as ListNotesQuery;

    const result = await notesService.list(
      userId,
      query
    );

    success(
      res,
      result,
      "게시글 목록을 조회했습니다."
    );
  })
);

// ============================================================
// GET /api/v1/notes/:id
// 게시글 상세 조회
// ============================================================

notesRouter.get(
  "/:id",

  validate("params", uuidSchema),

  asyncHandler(async (req, res) => {

    const userId = req.userId!;

    const params = req.validated?.params as {
      id: string;
    };

    const note = await notesService.getById(
      userId,
      params.id
    );

    success(
      res,
      note,
      "게시글을 조회했습니다."
    );
  })
);

// ============================================================
// PUT /api/v1/notes/:id
// 게시글 전체 수정
// ============================================================

notesRouter.put(
  "/:id",

  validate("params", uuidSchema),

  validate("body", replaceNoteSchema),

  asyncHandler(async (req, res) => {

    const userId = req.userId!;

    const params = req.validated?.params as {
      id: string;
    };

    const input = req.body as ReplaceNoteInput;

    const note = await notesService.replace(
      userId,
      params.id,
      input
    );

    success(
      res,
      note,
      "게시글이 수정되었습니다."
    );
  })
);

// ============================================================
// PATCH /api/v1/notes/:id
// 게시글 부분 수정
// ============================================================

notesRouter.patch(
  "/:id",

  validate("params", uuidSchema),

  validate("body", updateNoteSchema),

  asyncHandler(async (req, res) => {

    const userId = req.userId!;

    const params = req.validated?.params as {
      id: string;
    };

    const input = req.body as UpdateNoteInput;

    const note = await notesService.update(
      userId,
      params.id,
      input
    );

    success(
      res,
      note,
      "게시글이 수정되었습니다."
    );
  })
);

// ============================================================
// DELETE /api/v1/notes/:id
// 게시글 삭제
// ============================================================

notesRouter.delete(
  "/:id",

  validate("params", uuidSchema),

  asyncHandler(async (req, res) => {

    const userId = req.userId!;

    const params = req.validated?.params as {
      id: string;
    };

    const result = await notesService.delete(
      userId,
      params.id
    );

    success(
      res,
      result,
      "게시글이 삭제되었습니다."
    );
  })
);
'@


# ============================================================
# 9. 자동 테스트
# ============================================================

Save-Source3 "apps/api/src/modules/notes/notes.dto.test.ts" "게시글 CRUD 입력값과 검색, 정렬, 페이징 검증 테스트" @'
import {
  describe,
  expect,
  it
} from "vitest";

import {
  createNoteSchema,
  replaceNoteSchema,
  updateNoteSchema,
  listNotesSchema
} from "./notes.dto";

// ============================================================
// 게시글 등록 테스트
// ============================================================

describe("게시글 등록 검증", () => {

  it("정상적인 게시글을 허용합니다.", () => {

    const result = createNoteSchema.safeParse({
      title: "테스트 제목",
      content: "테스트 내용입니다."
    });

    expect(result.success).toBe(true);
  });

  it("제목이 비어 있으면 거부합니다.", () => {

    const result = createNoteSchema.safeParse({
      title: "",
      content: "테스트 내용"
    });

    expect(result.success).toBe(false);
  });

  it("내용이 비어 있으면 거부합니다.", () => {

    const result = createNoteSchema.safeParse({
      title: "테스트 제목",
      content: ""
    });

    expect(result.success).toBe(false);
  });

  it("제목이 120자를 초과하면 거부합니다.", () => {

    const result = createNoteSchema.safeParse({
      title: "가".repeat(121),
      content: "테스트 내용"
    });

    expect(result.success).toBe(false);
  });

  it("내용이 10000자를 초과하면 거부합니다.", () => {

    const result = createNoteSchema.safeParse({
      title: "테스트 제목",
      content: "가".repeat(10001)
    });

    expect(result.success).toBe(false);
  });

  it("사용자 ID를 임의로 지정할 수 없습니다.", () => {

    const result = createNoteSchema.safeParse({
      title: "테스트 제목",
      content: "테스트 내용",
      ownerId: "other-user"
    });

    expect(result.success).toBe(false);
  });
});

// ============================================================
// 게시글 수정 테스트
// ============================================================

describe("게시글 수정 검증", () => {

  it("전체 수정에는 제목과 내용이 필요합니다.", () => {

    const result = replaceNoteSchema.safeParse({
      title: "수정 제목"
    });

    expect(result.success).toBe(false);
  });

  it("제목만 부분 수정할 수 있습니다.", () => {

    const result = updateNoteSchema.safeParse({
      title: "수정된 제목"
    });

    expect(result.success).toBe(true);
  });

  it("내용만 부분 수정할 수 있습니다.", () => {

    const result = updateNoteSchema.safeParse({
      content: "수정된 내용"
    });

    expect(result.success).toBe(true);
  });

  it("빈 수정 요청은 거부합니다.", () => {

    const result = updateNoteSchema.safeParse({});

    expect(result.success).toBe(false);
  });

  it("허용되지 않은 필드는 수정할 수 없습니다.", () => {

    const result = updateNoteSchema.safeParse({
      ownerId: "other-user"
    });

    expect(result.success).toBe(false);
  });
});

// ============================================================
// 페이징 테스트
// ============================================================

describe("게시글 페이징 검증", () => {

  it("기본 페이징 값을 적용합니다.", () => {

    const result = listNotesSchema.parse({});

    expect(result.page).toBe(1);
    expect(result.limit).toBe(20);
    expect(result.sortBy).toBe("createdAt");
    expect(result.sortOrder).toBe("desc");
  });

  it("문자열 페이지 번호를 숫자로 변환합니다.", () => {

    const result = listNotesSchema.parse({
      page: "3",
      limit: "10"
    });

    expect(result.page).toBe(3);
    expect(result.limit).toBe(10);
  });

  it("페이지 번호 0을 거부합니다.", () => {

    const result = listNotesSchema.safeParse({
      page: "0"
    });

    expect(result.success).toBe(false);
  });

  it("최대 조회 개수 100을 초과하면 거부합니다.", () => {

    const result = listNotesSchema.safeParse({
      limit: "101"
    });

    expect(result.success).toBe(false);
  });

  it("허용되지 않은 정렬 필드를 거부합니다.", () => {

    const result = listNotesSchema.safeParse({
      sortBy: "passwordHash"
    });

    expect(result.success).toBe(false);
  });

  it("허용되지 않은 정렬 방향을 거부합니다.", () => {

    const result = listNotesSchema.safeParse({
      sortOrder: "random"
    });

    expect(result.success).toBe(false);
  });
});
'@


# ============================================================
# 10. API 설명서
# ============================================================

Save-Source3 "apps/api/src/modules/notes/README.md" "게시글 CRUD API 사용법과 보안 설계 안내" @'
# 게시글 CRUD API 사용 설명서

## 1. 개요

이 모듈은 웹과 모바일 앱에서 공통으로 사용하는
게시글 CRUD 기능을 제공합니다.

모든 API는 JWT Access Token 인증이 필요합니다.

게시글은 사용자별로 분리됩니다.

다른 사용자의 게시글은 조회, 수정, 삭제할 수 없습니다.

## 2. 인증

모든 요청에 다음 HTTP 헤더가 필요합니다.

Authorization: Bearer ACCESS_TOKEN

## 3. 게시글 등록

POST /api/v1/notes

요청 JSON:

{
  "title": "게시글 제목",
  "content": "게시글 내용"
}

성공 HTTP 상태 코드: 201

## 4. 게시글 목록 조회

GET /api/v1/notes

지원하는 Query 파라미터:

page: 페이지 번호

limit: 페이지당 조회 개수

search: 제목과 내용 검색어

sortBy: 정렬 필드

sortOrder: 정렬 방향

기본값:

page = 1

limit = 20

sortBy = createdAt

sortOrder = desc

조회 개수는 최대 100개입니다.

정렬 필드:

createdAt

updatedAt

title

정렬 방향:

asc

desc

예시:

GET /api/v1/notes?page=1&limit=20

GET /api/v1/notes?search=테스트

GET /api/v1/notes?sortBy=title&sortOrder=asc

GET /api/v1/notes?page=2&limit=10&search=안내

## 5. 목록 응답

{
  "success": true,
  "data": {
    "items": [],
    "pagination": {
      "page": 1,
      "limit": 20,
      "total": 0,
      "totalPages": 0,
      "hasNext": false,
      "hasPrevious": false
    }
  },
  "message": "게시글 목록을 조회했습니다."
}

## 6. 게시글 상세 조회

GET /api/v1/notes/:id

게시글 ID는 UUID 형식이어야 합니다.

## 7. 게시글 전체 수정

PUT /api/v1/notes/:id

요청 JSON:

{
  "title": "수정한 제목",
  "content": "수정한 내용"
}

제목과 내용을 모두 전달해야 합니다.

## 8. 게시글 부분 수정

PATCH /api/v1/notes/:id

요청 JSON:

{
  "title": "수정한 제목"
}

또는:

{
  "content": "수정한 내용"
}

수정할 필드를 하나 이상 전달해야 합니다.

## 9. 게시글 삭제

DELETE /api/v1/notes/:id

삭제에 성공하면 deleted: true를 반환합니다.

## 10. 보안 정책

1. 모든 요청에 JWT 인증을 적용합니다.

2. ownerId는 클라이언트에서 받지 않습니다.

3. ownerId는 인증된 사용자 정보에서 가져옵니다.

4. 데이터베이스 조회 시 ownerId 조건을 적용합니다.

5. 수정 및 삭제 시에도 ownerId 조건을 적용합니다.

6. 다른 사용자의 게시글은 404로 응답합니다.

7. 정렬 가능한 필드를 제한합니다.

8. 페이지당 조회 개수를 최대 100개로 제한합니다.

9. 제목과 내용 길이를 제한합니다.

10. 반환할 데이터베이스 필드를 명시합니다.

11. 검색에는 Prisma의 매개변수화된 쿼리를 사용합니다.

12. 클라이언트는 사용자 입력을 HTML로 직접 삽입하지 않아야 합니다.

## 11. 주의사항

이 모듈은 인증 모듈과 Prisma 연결 모듈에 의존합니다.

Express 서버에 notesRouter를 등록해야 실제 API가 동작합니다.

이 모듈의 DTO 테스트만으로 DB 접근 권한이
검증되었다고 판단해서는 안 됩니다.

운영 전에는 실제 PostgreSQL을 이용한
사용자별 접근 권한 통합 테스트가 필요합니다.
'@


# ============================================================
# 11. 완료 메시지
# ============================================================

Write-Host ""
Write-Host "=========================================="
Write-Host " 3부 CRUD 공통 모듈 생성 완료"
Write-Host "=========================================="
Write-Host ""

Write-Host "생성된 파일:" -ForegroundColor Cyan

foreach ($RelativePath in $OutputFiles) {

    Write-Host " - $RelativePath"
}

Write-Host ""
Write-Host "기존 1부와 2부 파일은 변경하지 않았습니다."
Write-Host ""
Write-Host "다음 단계에서 Express 서버에 라우터를 연결해야 합니다."
Write-Host ""

