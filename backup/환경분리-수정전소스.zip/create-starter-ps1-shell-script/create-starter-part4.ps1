﻿# filepath: create-starter-part4.ps1 - 범용 파일 업로드 및 다운로드 공통 모듈 생성

$ErrorActionPreference = "Stop"

# ============================================================
# 1. 프로젝트 경로 설정
# ============================================================

$Root = Join-Path $PSScriptRoot "secure-starter"

# 보안 검토가 끝난 프로젝트에 예전 생성 코드를 덮어쓰지 않습니다.
if (Test-Path -LiteralPath (Join-Path $Root "SECURITY-REVISION.json")) {
    throw "보안 수정이 적용된 V5입니다. 이전 부별 생성 스크립트 적용을 차단합니다."
}


if (-not (Test-Path $Root)) {
    throw "secure-starter 프로젝트가 없습니다. 1부를 먼저 생성하세요."
}

# ============================================================
# 2. 필수 파일 검사
# ============================================================

$RequiredFiles = @(
    "apps/api/prisma/schema.prisma",
    "apps/api/src/config/env.ts",
    "apps/api/src/common/errors.ts",
    "apps/api/src/common/response.ts",
    "apps/api/src/common/validate.ts",
    "apps/api/src/common/pagination.ts",
    "apps/api/src/common/auth.middleware.ts",
    "apps/api/src/infrastructure/prisma.ts",
    "apps/api/src/infrastructure/redis.ts",
    "apps/api/src/infrastructure/logger.ts",
    "apps/api/src/modules/auth/auth.controller.ts",
    "apps/api/src/modules/notes/notes.controller.ts"
)

foreach ($RelativePath in $RequiredFiles) {

    $FullPath = Join-Path $Root $RelativePath

    if (-not (Test-Path $FullPath)) {
        throw "필수 파일이 없습니다: $RelativePath"
    }
}

# Prisma 파일 모델 검사
$SchemaPath = Join-Path $Root "apps/api/prisma/schema.prisma"

$SchemaContent = Get-Content `
    -LiteralPath $SchemaPath `
    -Raw `
    -Encoding UTF8

if ($SchemaContent -notmatch "model\s+StoredFile\s*\{") {
    throw "Prisma 스키마에 StoredFile 모델이 없습니다."
}

# ============================================================
# 3. 생성 대상 파일
# ============================================================

$OutputFiles = @(
    "apps/api/src/modules/files/files.dto.ts",
    "apps/api/src/modules/files/files.security.ts",
    "apps/api/src/modules/files/files.repository.ts",
    "apps/api/src/modules/files/files.service.ts",
    "apps/api/src/modules/files/files.controller.ts",
    "apps/api/src/modules/files/files.security.test.ts",
    "apps/api/src/modules/files/storage/storage.interface.ts",
    "apps/api/src/modules/files/storage/local.storage.ts",
    "apps/api/src/modules/files/README.md"
)

# 기존 파일을 덮어쓰지 않습니다.
foreach ($RelativePath in $OutputFiles) {

    $FullPath = Join-Path $Root $RelativePath

    if (Test-Path $FullPath) {
        throw "이미 존재하는 파일이 있습니다: $RelativePath"
    }
}

# ============================================================
# 4. UTF-8 파일 저장 함수
# ============================================================

$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)

function Save-Source4 {

    param(
        [string]$RelativePath,
        [string]$Description,
        [string]$Content
    )

    $FullPath = Join-Path $Root $RelativePath

    $Directory = Split-Path $FullPath -Parent

    if (Test-Path $FullPath) {
        throw "기존 파일 보호: $RelativePath"
    }

    if (-not (Test-Path $Directory)) {

        New-Item `
            -ItemType Directory `
            -Path $Directory `
            -Force | Out-Null
    }

    $Extension = [System.IO.Path]::GetExtension($RelativePath)

    $Header = switch ($Extension) {

        ".ts" {
            "// filepath: $RelativePath - $Description`n"
        }

        ".tsx" {
            "// filepath: $RelativePath - $Description`n"
        }

        ".md" {
            "<!-- filepath: $RelativePath - $Description -->`n"
        }

        default {
            "# filepath: $RelativePath - $Description`n"
        }
    }

    $FinalContent = $Header + $Content

    [System.IO.File]::WriteAllText(
        $FullPath,
        $FinalContent,
        $Utf8NoBom
    )

    Write-Host "[생성 완료] $RelativePath" -ForegroundColor Green
}

Write-Host ""
Write-Host "=========================================="
Write-Host " 4부 파일 관리 공통 모듈 생성 시작"
Write-Host "=========================================="
Write-Host ""


# ============================================================
# 5. 파일 요청 DTO
# ============================================================

Save-Source4 "apps/api/src/modules/files/files.dto.ts" "파일 목록 검색과 정렬 및 페이징 요청 검증" @'
import { z } from "zod";

import {
  paginationSchema
} from "../../common/pagination";

// ============================================================
// 파일 관리 공통 설정
// ============================================================

// 파일당 최대 업로드 크기: 5MB
export const MAX_FILE_SIZE = 5 * 1024 * 1024;

// 목록 조회 시 허용할 정렬 필드
export const fileSortFields = [
  "createdAt",
  "originalName",
  "size"
] as const;

// ============================================================
// 파일 목록 조회 검증
// ============================================================

export const listFilesSchema = paginationSchema
  .extend({

    page: z.coerce.number()
      .int()
      .min(1)
      .max(1000000)
      .default(1),

    sortBy: z.enum(fileSortFields)
      .default("createdAt"),

    sortOrder: z.enum([
      "asc",
      "desc"
    ]).default("desc")

  })
  .strict();

// ============================================================
// 타입 정의
// ============================================================

export type ListFilesQuery =
  z.infer<typeof listFilesSchema>;
'@


# ============================================================
# 6. 파일 보안 검증
# ============================================================

Save-Source4 "apps/api/src/modules/files/files.security.ts" "파일 시그니처와 확장자 및 MIME 타입 검증" @'
import path from "node:path";

import {
  AppError
} from "../../common/errors";

// ============================================================
// 허용 파일 형식
// ============================================================

type AllowedMime =
  | "image/jpeg"
  | "image/png"
  | "image/webp"
  | "application/pdf";

type FileType = {
  mimeType: AllowedMime;
  extension: string;
};

// 파일 형식별 허용 확장자
const allowedExtensions: Record<
  AllowedMime,
  readonly string[]
> = {

  "image/jpeg": [
    ".jpg",
    ".jpeg"
  ],

  "image/png": [
    ".png"
  ],

  "image/webp": [
    ".webp"
  ],

  "application/pdf": [
    ".pdf"
  ]

};

// ============================================================
// 한글 파일명 인코딩 복구
// ============================================================

// 일부 multipart 파서는 UTF-8 파일명을
// Latin-1 문자열로 해석할 수 있습니다.
//
// 원본 바이트가 유효한 UTF-8인 경우에만
// 파일명을 복구합니다.

function restoreUtf8Filename(
  filename: string
): string {

  const latin1Compatible = Array.from(filename)
    .every((character) => character.codePointAt(0)! <= 255);

  if (!latin1Compatible) {
    return filename;
  }

  const bytes = Buffer.from(
    filename,
    "latin1"
  );

  const restored = bytes.toString("utf8");

  if (restored.includes("\uFFFD")) {
    return filename;
  }

  if (!Buffer.from(restored, "utf8").equals(bytes)) {
    return filename;
  }

  return restored;
}

// ============================================================
// 파일명 정리
// ============================================================

export function sanitizeFilename(
  originalName: string
): string {

  const restored = restoreUtf8Filename(
    originalName
  );

  const cleaned = restored
    .normalize("NFC")
    .replace(/[\x00-\x1F\x7F]/g, "")
    .replace(/[\/\\]/g, "_")
    .replace(/[\u202A-\u202E\u2066-\u2069]/g, "")
    .trim();

  if (
    !cleaned ||
    cleaned === "." ||
    cleaned === ".."
  ) {

    throw new AppError(
      400,
      "INVALID_FILENAME",
      "파일명이 올바르지 않습니다."
    );
  }

  if (
    Buffer.byteLength(cleaned, "utf8") > 255
  ) {

    throw new AppError(
      400,
      "FILENAME_TOO_LONG",
      "파일명이 너무 깁니다."
    );
  }

  return cleaned;
}

// ============================================================
// 실제 파일 시그니처 검사
// ============================================================

// 파일명과 클라이언트 MIME 타입만으로
// 파일 종류를 판단하지 않습니다.
//
// 아래 검사는 기본 시그니처 검사이며,
// 파일 전체의 구조적 무결성이나 악성코드
// 포함 여부를 보장하지 않습니다.

export function detectFileType(
  buffer: Buffer
): FileType | null {

  // JPEG
  if (
    buffer.length >= 4 &&
    buffer[0] === 0xff &&
    buffer[1] === 0xd8 &&
    buffer[2] === 0xff &&
    buffer[buffer.length - 2] === 0xff &&
    buffer[buffer.length - 1] === 0xd9
  ) {

    return {
      mimeType: "image/jpeg",
      extension: ".jpg"
    };
  }

  // PNG
  const pngSignature = Buffer.from([
    0x89,
    0x50,
    0x4e,
    0x47,
    0x0d,
    0x0a,
    0x1a,
    0x0a
  ]);

  if (
    buffer.length >= 8 &&
    buffer.subarray(0, 8).equals(pngSignature)
  ) {

    return {
      mimeType: "image/png",
      extension: ".png"
    };
  }

  // WebP
  if (
    buffer.length >= 12 &&
    buffer.toString("ascii", 0, 4) === "RIFF" &&
    buffer.toString("ascii", 8, 12) === "WEBP"
  ) {

    return {
      mimeType: "image/webp",
      extension: ".webp"
    };
  }

  // PDF
  if (
    buffer.length >= 5 &&
    buffer.toString("ascii", 0, 5) === "%PDF-"
  ) {

    return {
      mimeType: "application/pdf",
      extension: ".pdf"
    };
  }

  return null;
}

// ============================================================
// 업로드 파일 검증
// ============================================================

export function validateUploadedFile(
  file: Express.Multer.File
) {

  if (!file.buffer || file.size === 0) {

    throw new AppError(
      400,
      "EMPTY_FILE",
      "빈 파일은 업로드할 수 없습니다."
    );
  }

  const originalName = sanitizeFilename(
    file.originalname
  );

  const extension = path.extname(
    originalName
  ).toLowerCase();

  const detected = detectFileType(
    file.buffer
  );

  if (!detected) {

    throw new AppError(
      400,
      "UNSUPPORTED_FILE_TYPE",
      "허용되지 않은 파일 형식입니다."
    );
  }

  const validExtensions =
    allowedExtensions[detected.mimeType];

  if (!validExtensions.includes(extension)) {

    throw new AppError(
      400,
      "INVALID_FILE_EXTENSION",
      "파일 확장자와 실제 파일 형식이 일치하지 않습니다."
    );
  }

  if (file.mimetype !== detected.mimeType) {

    throw new AppError(
      400,
      "INVALID_MIME_TYPE",
      "요청한 MIME 타입과 실제 파일 형식이 일치하지 않습니다."
    );
  }

  return {
    originalName,
    mimeType: detected.mimeType,
    extension: detected.extension,
    size: file.size
  };
}
'@


# ============================================================
# 7. 저장소 인터페이스
# ============================================================

Save-Source4 "apps/api/src/modules/files/storage/storage.interface.ts" "로컬 디스크와 AWS S3에서 공통으로 사용할 파일 저장소 인터페이스" @'
import type {
  Readable
} from "node:stream";

// ============================================================
// 파일 읽기 결과
// ============================================================

export interface StoredFileStream {

  stream: Readable;

  size: number;

}

// ============================================================
// 파일 저장소 인터페이스
// ============================================================

// 파일 저장 방식이 변경되어도
// Service는 동일한 인터페이스를 사용합니다.

export interface FileStorage {

  // 파일 저장
  save(
    key: string,
    buffer: Buffer
  ): Promise<void>;

  // 파일 읽기
  openRead(
    key: string
  ): Promise<StoredFileStream>;

  // 파일 삭제
  remove(
    key: string
  ): Promise<void>;

}
'@


# ============================================================
# 8. 로컬 파일 저장소
# ============================================================

Save-Source4 "apps/api/src/modules/files/storage/local.storage.ts" "비공개 로컬 디스크에 파일을 안전하게 저장하고 읽는 기능" @'
import path from "node:path";

import {
  constants
} from "node:fs";

import {
  mkdir,
  open,
  unlink,
  writeFile
} from "node:fs/promises";

import {
  env
} from "../../../config/env";

import type {
  FileStorage,
  StoredFileStream
} from "./storage.interface";

// ============================================================
// 로컬 저장소
// ============================================================

export class LocalFileStorage implements FileStorage {

  private readonly rootDirectory: string;

  constructor() {

    // 상대 경로는 API 실행 디렉터리를 기준으로 처리합니다.
    this.rootDirectory = path.resolve(
      process.cwd(),
      env.UPLOAD_DIR
    );
  }

  // ----------------------------------------------------------
  // 저장 키 검증
  // ----------------------------------------------------------

  private resolveSafePath(
    key: string
  ): string {

    // 저장 키는 서버가 생성한 UUID 기반 파일명만 허용합니다.
    // 디렉터리 구분자와 상대 경로를 허용하지 않습니다.

    const safeKeyPattern =
      /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\.(jpg|png|webp|pdf)$/i;

    if (!safeKeyPattern.test(key)) {

      throw new Error(
        "파일 저장 키가 올바르지 않습니다."
      );
    }

    return path.join(
      this.rootDirectory,
      key
    );
  }

  // ----------------------------------------------------------
  // 파일 저장
  // ----------------------------------------------------------

  async save(
    key: string,
    buffer: Buffer
  ): Promise<void> {

    const targetPath = this.resolveSafePath(
      key
    );

    // 저장 디렉터리는 외부에 공개하지 않습니다.
    await mkdir(
      this.rootDirectory,
      {
        recursive: true,
        mode: 0o700
      }
    );

    // wx 옵션으로 기존 파일 덮어쓰기를 방지합니다.
    await writeFile(
      targetPath,
      buffer,
      {
        flag: "wx",
        mode: 0o600
      }
    );
  }

  // ----------------------------------------------------------
  // 파일 읽기
  // ----------------------------------------------------------

  async openRead(
    key: string
  ): Promise<StoredFileStream> {

    const targetPath = this.resolveSafePath(
      key
    );

    // 가능한 환경에서는 심볼릭 링크를 따라가지 않습니다.
    const flags =
      constants.O_RDONLY |
      (constants.O_NOFOLLOW ?? 0);

    const handle = await open(
      targetPath,
      flags
    );

    try {

      const stats = await handle.stat();

      if (!stats.isFile()) {
        throw new Error(
          "일반 파일이 아닙니다."
        );
      }

      return {
        stream: handle.createReadStream({
          autoClose: true
        }),
        size: stats.size
      };

    } catch (error) {

      await handle.close();

      throw error;
    }
  }

  // ----------------------------------------------------------
  // 파일 삭제
  // ----------------------------------------------------------

  async remove(
    key: string
  ): Promise<void> {

    const targetPath = this.resolveSafePath(
      key
    );

    try {

      await unlink(targetPath);

    } catch (error) {

      const nodeError = error as NodeJS.ErrnoException;

      // 이미 삭제된 파일은 삭제 완료로 처리합니다.
      if (nodeError.code === "ENOENT") {
        return;
      }

      throw error;
    }
  }
}
'@


# ============================================================
# 9. 파일 Repository
# ============================================================

Save-Source4 "apps/api/src/modules/files/files.repository.ts" "Prisma를 이용한 파일 메타데이터 저장 및 사용자별 접근 권한 검사" @'
import {
  Prisma
} from "@prisma/client";

import {
  prisma
} from "../../infrastructure/prisma";

import type {
  ListFilesQuery
} from "./files.dto";

// ============================================================
// 외부 응답용 파일 필드
// ============================================================

const publicFileSelect = {

  id: true,

  originalName: true,

  mimeType: true,

  size: true,

  createdAt: true

} as const;

// ============================================================
// 파일 Repository
// ============================================================

export const filesRepository = {

  // ----------------------------------------------------------
  // 파일 메타데이터 등록
  // ----------------------------------------------------------

  async create(data: {

    ownerId: string;

    storageKey: string;

    originalName: string;

    mimeType: string;

    size: number;

  }) {

    return prisma.storedFile.create({

      data,

      select: publicFileSelect

    });
  },

  // ----------------------------------------------------------
  // 파일 목록 조회
  // ----------------------------------------------------------

  async findPage(
    ownerId: string,
    query: ListFilesQuery
  ) {

    const {
      page,
      limit,
      search,
      sortBy,
      sortOrder
    } = query;

    const where: Prisma.StoredFileWhereInput = {

      ownerId,

      ...(search
        ? {
            originalName: {
              contains: search,
              mode: "insensitive" as const
            }
          }
        : {})

    };

    const orderBy: Prisma.StoredFileOrderByWithRelationInput = {
      [sortBy]: sortOrder
    };

    const [items, total] = await prisma.$transaction([

      prisma.storedFile.findMany({

        where,

        select: publicFileSelect,

        orderBy: [
          orderBy,
          {
            id: "asc"
          }
        ],

        skip: (page - 1) * limit,

        take: limit

      }),

      prisma.storedFile.count({
        where
      })

    ]);

    return {
      items,
      total
    };
  },

  // ----------------------------------------------------------
  // 파일 상세 조회
  // ----------------------------------------------------------

  async findById(
    ownerId: string,
    fileId: string
  ) {

    return prisma.storedFile.findFirst({

      where: {
        id: fileId,
        ownerId
      }

    });
  },

  // ----------------------------------------------------------
  // 파일 메타데이터 삭제
  // ----------------------------------------------------------

  async delete(
    ownerId: string,
    fileId: string
  ) {

    return prisma.storedFile.deleteMany({

      where: {
        id: fileId,
        ownerId
      }

    });
  }
};
'@


# ============================================================
# 10. 파일 Service
# ============================================================

Save-Source4 "apps/api/src/modules/files/files.service.ts" "파일 업로드, 조회, 다운로드 및 삭제 비즈니스 로직" @'
import crypto from "node:crypto";

import {
  AppError
} from "../../common/errors";

import {
  paginated
} from "../../common/pagination";

import {
  logger
} from "../../infrastructure/logger";

import {
  filesRepository
} from "./files.repository";

import {
  validateUploadedFile
} from "./files.security";

import {
  LocalFileStorage
} from "./storage/local.storage";

import type {
  FileStorage
} from "./storage/storage.interface";

import type {
  ListFilesQuery
} from "./files.dto";

// ============================================================
// 저장소 의존성
// ============================================================

// 나중에 S3로 전환할 경우 이 저장소 구현을 교체합니다.
// Service와 Controller는 동일한 인터페이스를 사용합니다.

const storage: FileStorage = new LocalFileStorage();

// ============================================================
// 파일 Service
// ============================================================

export const filesService = {

  // ----------------------------------------------------------
  // 파일 업로드
  // ----------------------------------------------------------

  async upload(
    userId: string,
    file: Express.Multer.File | undefined
  ) {

    if (!file) {

      throw new AppError(
        400,
        "FILE_REQUIRED",
        "업로드할 파일을 선택해 주세요."
      );
    }

    // 확장자, MIME 타입, 파일 시그니처 검사
    const validated = validateUploadedFile(
      file
    );

    // 사용자 파일명을 저장 경로에 사용하지 않습니다.
    const storageKey =
      crypto.randomUUID() + validated.extension;

    // 파일을 비공개 저장소에 저장합니다.
    await storage.save(
      storageKey,
      file.buffer
    );

    try {

      // 파일 메타데이터는 DB에 저장합니다.
      return await filesRepository.create({

        ownerId: userId,

        storageKey,

        originalName: validated.originalName,

        mimeType: validated.mimeType,

        size: validated.size

      });

    } catch (error) {

      // DB 저장에 실패하면 파일을 정리합니다.
      try {

        await storage.remove(storageKey);

      } catch (cleanupError) {

        logger.error(
          {
            storageKey,
            error: cleanupError
          },
          "파일 업로드 실패 후 임시 파일 정리에 실패했습니다."
        );
      }

      throw error;
    }
  },

  // ----------------------------------------------------------
  // 파일 목록 조회
  // ----------------------------------------------------------

  async list(
    userId: string,
    query: ListFilesQuery
  ) {

    const result = await filesRepository.findPage(
      userId,
      query
    );

    return paginated(
      result.items,
      result.total,
      query.page,
      query.limit
    );
  },

  // ----------------------------------------------------------
  // 파일 상세 조회
  // ----------------------------------------------------------

  async getById(
    userId: string,
    fileId: string
  ) {

    const file = await filesRepository.findById(
      userId,
      fileId
    );

    if (!file) {

      throw new AppError(
        404,
        "FILE_NOT_FOUND",
        "파일을 찾을 수 없습니다."
      );
    }

    // 저장소 내부 키는 클라이언트에 노출하지 않습니다.
    return {
      id: file.id,
      originalName: file.originalName,
      mimeType: file.mimeType,
      size: file.size,
      createdAt: file.createdAt
    };
  },

  // ----------------------------------------------------------
  // 파일 다운로드
  // ----------------------------------------------------------

  async download(
    userId: string,
    fileId: string
  ) {

    const file = await filesRepository.findById(
      userId,
      fileId
    );

    if (!file) {

      throw new AppError(
        404,
        "FILE_NOT_FOUND",
        "파일을 찾을 수 없습니다."
      );
    }

    try {

      const opened = await storage.openRead(
        file.storageKey
      );

      return {
        stream: opened.stream,
        size: opened.size,
        originalName: file.originalName,
        mimeType: file.mimeType
      };

    } catch (error) {

      const nodeError = error as NodeJS.ErrnoException;

      if (nodeError.code === "ENOENT") {

        throw new AppError(
          404,
          "FILE_NOT_FOUND",
          "파일을 찾을 수 없습니다."
        );
      }

      throw error;
    }
  },

  // ----------------------------------------------------------
  // 파일 삭제
  // ----------------------------------------------------------

  async delete(
    userId: string,
    fileId: string
  ) {

    const file = await filesRepository.findById(
      userId,
      fileId
    );

    if (!file) {

      throw new AppError(
        404,
        "FILE_NOT_FOUND",
        "파일을 찾을 수 없습니다."
      );
    }

    // 실제 파일을 먼저 삭제합니다.
    // 파일 삭제가 실패하면 DB 메타데이터를 유지합니다.
    await storage.remove(
      file.storageKey
    );

    const result = await filesRepository.delete(
      userId,
      fileId
    );

    if (result.count !== 1) {

      throw new AppError(
        404,
        "FILE_NOT_FOUND",
        "파일을 찾을 수 없습니다."
      );
    }

    return {
      id: fileId,
      deleted: true
    };
  }
};
'@


# ============================================================
# 11. 파일 Controller
# ============================================================

Save-Source4 "apps/api/src/modules/files/files.controller.ts" "파일 업로드, 다운로드, 조회 및 삭제 REST API 라우터" @'
import {
  Router
} from "express";

import multer from "multer";

import {
  rateLimit
} from "express-rate-limit";

import {
  RedisStore
} from "rate-limit-redis";

import {
  pipeline
} from "node:stream/promises";

import {
  requireAuth
} from "../../common/auth.middleware";

import {
  validate,
  asyncHandler,
  uuidSchema
} from "../../common/validate";

import {
  success,
  failure
} from "../../common/response";

import {
  redis
} from "../../infrastructure/redis";

import {
  MAX_FILE_SIZE,
  listFilesSchema
} from "./files.dto";

import type {
  ListFilesQuery
} from "./files.dto";

import {
  filesService
} from "./files.service";

// ============================================================
// 파일 라우터
// ============================================================

export const filesRouter = Router();

// 모든 파일 API는 인증이 필요합니다.
filesRouter.use(requireAuth);

// ============================================================
// 업로드 요청 제한
// ============================================================

// 일반 API 요청 제한과 별도로
// 파일 업로드 요청 횟수를 제한합니다.

const uploadLimiter = rateLimit({

  windowMs: 15 * 60 * 1000,

  limit: 20,

  standardHeaders: "draft-7",

  legacyHeaders: false,

  store: new RedisStore({

    prefix: "rate:file-upload:",

    sendCommand: async (...args: string[]) => {
      return await redis.sendCommand(args);
    }

  }),

  handler: (_req, res) => {

    failure(
      res,
      429,
      "UPLOAD_RATE_LIMITED",
      "파일 업로드 요청이 너무 많습니다."
    );
  }
});

// ============================================================
// Multer 업로드 설정
// ============================================================

// 메모리에 임시 저장한 후 파일 검증을 수행합니다.
// 최대 5MB로 제한하여 메모리 사용량을 제한합니다.

const upload = multer({

  storage: multer.memoryStorage(),

  limits: {

    fileSize: MAX_FILE_SIZE,

    files: 1,

    fields: 0,

    parts: 1

  }

});

// ============================================================
// POST /api/v1/files
// 파일 업로드
// ============================================================

filesRouter.post(
  "/",

  uploadLimiter,

  upload.single("file"),

  asyncHandler(async (req, res) => {

    const userId = req.userId!;

    const result = await filesService.upload(
      userId,
      req.file
    );

    success(
      res,
      result,
      "파일이 업로드되었습니다.",
      201
    );
  })
);

// ============================================================
// GET /api/v1/files
// 파일 목록 조회
// ============================================================

filesRouter.get(
  "/",

  validate("query", listFilesSchema),

  asyncHandler(async (req, res) => {

    const userId = req.userId!;

    const query = req.validated?.query as ListFilesQuery;

    const result = await filesService.list(
      userId,
      query
    );

    success(
      res,
      result,
      "파일 목록을 조회했습니다."
    );
  })
);

// ============================================================
// GET /api/v1/files/:id
// 파일 상세 조회
// ============================================================

filesRouter.get(
  "/:id",

  validate("params", uuidSchema),

  asyncHandler(async (req, res) => {

    const userId = req.userId!;

    const params = req.validated?.params as {
      id: string;
    };

    const result = await filesService.getById(
      userId,
      params.id
    );

    success(
      res,
      result,
      "파일 정보를 조회했습니다."
    );
  })
);

// ============================================================
// GET /api/v1/files/:id/download
// 파일 다운로드
// ============================================================

filesRouter.get(
  "/:id/download",

  validate("params", uuidSchema),

  asyncHandler(async (req, res) => {

    const userId = req.userId!;

    const params = req.validated?.params as {
      id: string;
    };

    const result = await filesService.download(
      userId,
      params.id
    );

    // UTF-8 파일명을 RFC 5987 형식으로 인코딩합니다.
    const encodedName = encodeURIComponent(
      result.originalName
    ).replace(
      /['()*]/g,
      (character) =>
        "%" +
        character.charCodeAt(0)
          .toString(16)
          .toUpperCase()
    );

    // ASCII 대체 파일명
    const fallbackName = "download";

    // 브라우저가 파일을 직접 실행하거나
    // HTML로 해석하지 않도록 강제 다운로드합니다.
    res.setHeader(
      "Content-Type",
      "application/octet-stream"
    );

    res.setHeader(
      "Content-Disposition",
      `attachment; filename="${fallbackName}"; filename*=UTF-8''${encodedName}`
    );

    res.setHeader(
      "X-Content-Type-Options",
      "nosniff"
    );

    res.setHeader(
      "Cache-Control",
      "private, no-store"
    );

    res.setHeader(
      "Content-Length",
      String(result.size)
    );

    // 스트림 방식으로 다운로드합니다.
    // 파일 전체를 응답 메모리에 올리지 않습니다.
    await pipeline(
      result.stream,
      res
    );
  })
);

// ============================================================
// DELETE /api/v1/files/:id
// 파일 삭제
// ============================================================

filesRouter.delete(
  "/:id",

  validate("params", uuidSchema),

  asyncHandler(async (req, res) => {

    const userId = req.userId!;

    const params = req.validated?.params as {
      id: string;
    };

    const result = await filesService.delete(
      userId,
      params.id
    );

    success(
      res,
      result,
      "파일이 삭제되었습니다."
    );
  })
);
'@


# ============================================================
# 12. 파일 보안 테스트
# ============================================================

Save-Source4 "apps/api/src/modules/files/files.security.test.ts" "파일 형식과 파일명 검증 및 목록 요청 자동 테스트" @'
import {
  describe,
  expect,
  it
} from "vitest";

import {
  detectFileType,
  sanitizeFilename
} from "./files.security";

import {
  listFilesSchema
} from "./files.dto";

// ============================================================
// 파일 형식 검사
// ============================================================

describe("파일 시그니처 검사", () => {

  it("PNG 파일 시그니처를 인식합니다.", () => {

    const buffer = Buffer.from([
      0x89,
      0x50,
      0x4e,
      0x47,
      0x0d,
      0x0a,
      0x1a,
      0x0a
    ]);

    const result = detectFileType(buffer);

    expect(result?.mimeType).toBe(
      "image/png"
    );
  });

  it("JPEG 파일 시그니처를 인식합니다.", () => {

    const buffer = Buffer.from([
      0xff,
      0xd8,
      0xff,
      0xe0,
      0xff,
      0xd9
    ]);

    const result = detectFileType(buffer);

    expect(result?.mimeType).toBe(
      "image/jpeg"
    );
  });

  it("알 수 없는 파일 형식을 거부합니다.", () => {

    const buffer = Buffer.from(
      "unknown-file-content"
    );

    const result = detectFileType(buffer);

    expect(result).toBeNull();
  });

});

// ============================================================
// 파일명 검사
// ============================================================

describe("파일명 보안 검사", () => {

  it("정상적인 한글 파일명을 허용합니다.", () => {

    const result = sanitizeFilename(
      "테스트이미지.png"
    );

    expect(result).toBe(
      "테스트이미지.png"
    );
  });

  it("경로 구분자를 제거합니다.", () => {

    const result = sanitizeFilename(
      "../../test.png"
    );

    expect(result.includes("/")).toBe(false);
  });

  it("빈 파일명을 거부합니다.", () => {

    expect(() => {
      sanitizeFilename("");
    }).toThrow();
  });

});

// ============================================================
// 목록 조회 검증
// ============================================================

describe("파일 목록 조회 검증", () => {

  it("기본 페이징을 적용합니다.", () => {

    const result = listFilesSchema.parse({});

    expect(result.page).toBe(1);

    expect(result.limit).toBe(20);

    expect(result.sortBy).toBe("createdAt");
  });

  it("잘못된 정렬 필드를 거부합니다.", () => {

    const result = listFilesSchema.safeParse({
      sortBy: "storageKey"
    });

    expect(result.success).toBe(false);
  });

  it("조회 개수 100개 초과를 거부합니다.", () => {

    const result = listFilesSchema.safeParse({
      limit: "101"
    });

    expect(result.success).toBe(false);
  });

});
'@


# ============================================================
# 13. 파일 API 설명서
# ============================================================

Save-Source4 "apps/api/src/modules/files/README.md" "파일 업로드와 다운로드 및 저장소 전환 사용 설명서" @'
# 파일 관리 공통 모듈

## 1. 개요

이 모듈은 웹과 모바일 앱에서 공통으로 사용할 수 있는
파일 업로드 및 다운로드 기능을 제공합니다.

모든 API에는 JWT 인증이 필요합니다.

## 2. 지원 파일

JPEG 이미지

PNG 이미지

WebP 이미지

PDF 문서

기본 최대 용량은 파일당 5MB입니다.

## 3. 파일 업로드

POST /api/v1/files

요청 형식:

multipart/form-data

파일 필드 이름:

file

요청 헤더:

Authorization: Bearer ACCESS_TOKEN

성공 HTTP 상태 코드:

201

## 4. 파일 목록

GET /api/v1/files

지원하는 파라미터:

page

limit

search

sortBy

sortOrder

정렬 필드:

createdAt

originalName

size

## 5. 파일 상세 조회

GET /api/v1/files/:id

파일 ID는 UUID 형식이어야 합니다.

## 6. 파일 다운로드

GET /api/v1/files/:id/download

다운로드 시 인증 및 소유권을 검사합니다.

Content-Disposition은 attachment로 설정합니다.

원본 한글 파일명은 UTF-8로 인코딩하여 전달합니다.

## 7. 파일 삭제

DELETE /api/v1/files/:id

본인이 업로드한 파일만 삭제할 수 있습니다.

## 8. 파일 저장 구조

실제 파일은 로컬 비공개 디렉터리에 저장합니다.

데이터베이스에는 파일 메타데이터를 저장합니다.

원본 파일명은 저장 경로에 사용하지 않습니다.

서버가 생성한 UUID 파일명을 사용합니다.

## 9. AWS S3 전환

storage.interface.ts에 정의된 FileStorage 인터페이스를
구현하는 S3 저장소 클래스를 작성합니다.

S3 저장소는 비공개 버킷을 사용해야 합니다.

서버에서 사용자 권한을 검증한 뒤
파일 다운로드를 허용해야 합니다.

현재 코드는 S3 구현 자체를 포함하지 않습니다.

## 10. 보안 주의사항

파일 시그니처 검사만으로 악성코드를 탐지할 수 없습니다.

PDF 파일에는 위험한 콘텐츠가 포함될 수 있습니다.

운영 환경에서는 악성코드 검사와
파일 형식별 구조 검증을 추가해야 합니다.

업로드 저장소를 웹 정적 파일 디렉터리로 공개하지 마세요.

파일 접근 시 항상 사용자 소유권을 검사해야 합니다.

운영 환경에서는 업로드 요청 제한과
전체 저장 용량 제한도 적용해야 합니다.

## 11. 운영 환경의 추가 요구사항

현재 구현은 로컬 개발용 기본 저장소입니다.

파일과 DB의 변경은 하나의 트랜잭션으로
묶을 수 없습니다.

따라서 운영 환경에서는 업로드 및 삭제 실패 시
정리 작업을 재시도하는 작업 큐 또는
Transactional Outbox 패턴을 고려해야 합니다.

여러 서버에서 로컬 저장소를 공유하지 않는 경우
서버별 파일 불일치가 발생할 수 있습니다.

운영 환경에서는 S3와 같은 공용 객체 저장소를 권장합니다.

## 12. 테스트

파일 형식과 파일명에 대한 단위 테스트가 포함됩니다.

실제 파일 업로드, 다운로드, 권한 검사는
별도의 통합 테스트가 필요합니다.
'@


# ============================================================
# 14. 생성 완료
# ============================================================

Write-Host ""
Write-Host "=========================================="
Write-Host " 4부 파일 관리 공통 모듈 생성 완료"
Write-Host "=========================================="
Write-Host ""

Write-Host "생성된 파일:" -ForegroundColor Cyan

foreach ($RelativePath in $OutputFiles) {

    Write-Host " - $RelativePath"
}

Write-Host ""
Write-Host "기존 1부, 2부, 3부 파일은 변경하지 않았습니다."
Write-Host ""
Write-Host "다음 단계에서 Express 서버에 filesRouter를 등록해야 합니다."
Write-Host ""

