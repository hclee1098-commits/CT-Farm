﻿# filepath: create-starter-part5.ps1 - Express 통합 서버, 보안 미들웨어, 헬스체크 및 안전한 종료 기능 생성

$ErrorActionPreference = "Stop"

# ============================================================
# 1. 기본 경로
# ============================================================

$Root = Join-Path $PSScriptRoot "secure-starter"

# 보안 검토가 끝난 프로젝트에 예전 생성 코드를 덮어쓰지 않습니다.
if (Test-Path -LiteralPath (Join-Path $Root "SECURITY-REVISION.json")) {
    throw "보안 수정이 적용된 V5입니다. 이전 부별 생성 스크립트 적용을 차단합니다."
}


$ApiRoot = Join-Path $Root "apps/api"

$ApiPackagePath = Join-Path $ApiRoot "package.json"

$RootPackagePath = Join-Path $Root "package.json"

# ============================================================
# 2. 프로젝트 확인
# ============================================================

if (-not (Test-Path $Root)) {
    throw "secure-starter 프로젝트가 없습니다."
}

if (-not (Test-Path $ApiPackagePath)) {
    throw "API package.json 파일이 없습니다."
}

if (-not (Test-Path $RootPackagePath)) {
    throw "루트 package.json 파일이 없습니다."
}

# ============================================================
# 3. 필수 파일 검사
# ============================================================

$RequiredFiles = @(
    "apps/api/src/config/env.ts",
    "apps/api/src/common/errors.ts",
    "apps/api/src/common/response.ts",
    "apps/api/src/common/validate.ts",
    "apps/api/src/common/auth.middleware.ts",
    "apps/api/src/infrastructure/prisma.ts",
    "apps/api/src/infrastructure/redis.ts",
    "apps/api/src/infrastructure/logger.ts",
    "apps/api/src/modules/auth/auth.controller.ts",
    "apps/api/src/modules/notes/notes.controller.ts",
    "apps/api/src/modules/files/files.controller.ts"
)

foreach ($RelativePath in $RequiredFiles) {

    $FullPath = Join-Path $Root $RelativePath

    if (-not (Test-Path $FullPath)) {

        throw "필수 파일이 없습니다: $RelativePath"
    }
}

# ============================================================
# 4. 기존 환경 설정 검사
# ============================================================

$EnvPath = Join-Path $Root "apps/api/src/config/env.ts"

$EnvContent = Get-Content `
    -LiteralPath $EnvPath `
    -Raw `
    -Encoding UTF8

$RequiredEnvFields = @(
    "CORS_ORIGIN_LIST",
    "IS_PRODUCTION",
    "UPLOAD_DIR"
)

foreach ($Field in $RequiredEnvFields) {

    if ($EnvContent -notmatch $Field) {

        throw "기존 환경 설정에서 필드를 찾지 못했습니다: $Field"
    }
}

# ============================================================
# 5. 생성 파일 사전 검사
# ============================================================

$OutputFiles = @(
    "apps/api/src/bootstrap/runtime.config.ts",
    "apps/api/src/bootstrap/health.ts",
    "apps/api/src/bootstrap/error-handler.ts",
    "apps/api/src/bootstrap/app.ts",
    "apps/api/src/bootstrap/server.ts",
    "apps/api/src/bootstrap/README.md"
)

foreach ($RelativePath in $OutputFiles) {

    $FullPath = Join-Path $Root $RelativePath

    if (Test-Path $FullPath) {

        throw "이미 존재하는 파일이 있습니다: $RelativePath"
    }
}

# ============================================================
# 6. package.json 검사
# ============================================================

$ApiPackage = Get-Content `
    -LiteralPath $ApiPackagePath `
    -Raw `
    -Encoding UTF8 | ConvertFrom-Json

$RootPackage = Get-Content `
    -LiteralPath $RootPackagePath `
    -Raw `
    -Encoding UTF8 | ConvertFrom-Json

if (-not $ApiPackage.scripts) {

    throw "API package.json에 scripts 설정이 없습니다."
}

if (-not $ApiPackage.scripts.dev) {

    throw "API package.json에 dev 명령이 없습니다."
}

$NewDevCommand = "tsx watch src/bootstrap/server.ts"

$ExistingDevCommand = [string]$ApiPackage.scripts.dev

$ScriptNames = @(
    $ApiPackage.scripts.PSObject.Properties.Name
)

if (
    $ExistingDevCommand -ne $NewDevCommand -and
    $ScriptNames -contains "dev:previous"
) {

    throw "dev:previous 명령이 이미 존재합니다. 자동 변경을 중단합니다."
}

if (
    $ScriptNames -contains "dev:integrated" -and
    $ApiPackage.scripts.'dev:integrated' -ne $NewDevCommand
) {

    throw "기존 dev:integrated 명령과 충돌합니다."
}

if (
    $ScriptNames -contains "start:integrated" -and
    $ApiPackage.scripts.'start:integrated' -ne "tsx src/bootstrap/server.ts"
) {

    throw "기존 start:integrated 명령과 충돌합니다."
}

# ============================================================
# 7. UTF-8 저장 함수
# ============================================================

$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)

function Save-Source5 {

    param(
        [string]$RelativePath,
        [string]$Description,
        [string]$Content
    )

    $FullPath = Join-Path $Root $RelativePath

    $Directory = Split-Path $FullPath -Parent

    if (Test-Path $FullPath) {

        throw "기존 파일을 보호하기 위해 중단합니다: $RelativePath"
    }

    if (-not (Test-Path $Directory)) {

        New-Item `
            -ItemType Directory `
            -Path $Directory `
            -Force | Out-Null
    }

    $Extension = [System.IO.Path]::GetExtension($RelativePath)

    $Header = switch ($Extension) {

        ".ts" {
            "// filepath: $RelativePath - $Description`n"
        }

        ".tsx" {
            "// filepath: $RelativePath - $Description`n"
        }

        ".md" {
            "<!-- filepath: $RelativePath - $Description -->`n"
        }

        default {
            "# filepath: $RelativePath - $Description`n"
        }
    }

    $FinalContent = $Header + $Content

    [System.IO.File]::WriteAllText(
        $FullPath,
        $FinalContent,
        $Utf8NoBom
    )

    Write-Host "[생성 완료] $RelativePath" -ForegroundColor Green
}

# ============================================================
# 8. 기존 설정 백업
# ============================================================

$Timestamp = Get-Date -Format "yyyyMMdd-HHmmss"

$BackupDirectory = Join-Path `
    $Root `
    ".starter-backups/part5-$Timestamp"

New-Item `
    -ItemType Directory `
    -Path $BackupDirectory `
    -Force | Out-Null

Copy-Item `
    -LiteralPath $ApiPackagePath `
    -Destination (Join-Path $BackupDirectory "package.json")

Write-Host ""
Write-Host "[백업 완료] $BackupDirectory" -ForegroundColor Cyan

Write-Host ""
Write-Host "=========================================="
Write-Host " 5부 Express 통합 서버 생성 시작"
Write-Host "=========================================="
Write-Host ""


# ============================================================
# 9. 런타임 환경 설정
# ============================================================

Save-Source5 "apps/api/src/bootstrap/runtime.config.ts" "서버 포트, 프록시 및 종료 시간 환경 변수 검증" @'
import { z } from "zod";

// ============================================================
// 런타임 환경 변수 검증
// ============================================================

// 기존 env.ts의 데이터베이스, JWT, CORS 설정은
// 그대로 사용합니다.
//
// 이 파일은 통합 서버 실행에 필요한
// 추가 설정만 관리합니다.

const runtimeSchema = z.object({

  PORT: z.coerce.number()
    .int()
    .min(1)
    .max(65535)
    .default(4000),

  TRUST_PROXY_HOPS: z.coerce.number()
    .int()
    .min(0)
    .max(10)
    .default(0),

  JSON_BODY_LIMIT: z.enum([
    "256kb",
    "512kb",
    "1mb",
    "2mb"
  ]).default("1mb"),

  SHUTDOWN_TIMEOUT_MS: z.coerce.number()
    .int()
    .min(1000)
    .max(30000)
    .default(10000)

});

// ============================================================
// 환경 변수 읽기
// ============================================================

const result = runtimeSchema.safeParse({

  PORT: process.env.PORT,

  TRUST_PROXY_HOPS: process.env.TRUST_PROXY_HOPS,

  JSON_BODY_LIMIT: process.env.JSON_BODY_LIMIT,

  SHUTDOWN_TIMEOUT_MS:
    process.env.SHUTDOWN_TIMEOUT_MS

});

// ============================================================
// 설정 오류 처리
// ============================================================

if (!result.success) {

  // 환경 변수 값을 그대로 출력하면
  // 민감 정보가 노출될 수 있으므로
  // 오류가 발생한 필드명만 출력합니다.

  const fields = result.error.issues
    .map((issue) => issue.path.join("."))
    .join(", ");

  throw new Error(
    `서버 환경 변수 설정이 올바르지 않습니다: ${fields}`
  );
}

export const runtimeConfig = result.data;
'@


# ============================================================
# 10. 헬스체크
# ============================================================

Save-Source5 "apps/api/src/bootstrap/health.ts" "서버와 PostgreSQL 및 Redis 연결 상태 확인 API" @'
import {
  Router
} from "express";

import {
  rateLimit
} from "express-rate-limit";

import {
  prisma
} from "../infrastructure/prisma";

import {
  redis
} from "../infrastructure/redis";

import {
  asyncHandler
} from "../common/validate";

// ============================================================
// 헬스체크 라우터
// ============================================================

export const healthRouter = Router();

// 헬스체크 API 자체가 과도하게 호출되지 않도록
// 간단한 요청 제한을 적용합니다.
//
// 이 제한은 서버별 메모리 저장소를 사용합니다.
// 여러 서버의 전체 요청 수를 합산하지는 않습니다.

healthRouter.use(
  rateLimit({

    windowMs: 60 * 1000,

    limit: 60,

    standardHeaders: "draft-7",

    legacyHeaders: false,

    handler: (_req, res) => {

      res.status(429).json({

        success: false,

        errorCode: "HEALTH_RATE_LIMITED",

        message: "상태 확인 요청이 너무 많습니다."

      });
    }

  })
);

// ============================================================
// 타임아웃 처리
// ============================================================

async function withTimeout<T>(
  operation: Promise<T>,
  timeoutMs: number
): Promise<T> {

  let timer: NodeJS.Timeout | undefined;

  try {

    const timeout = new Promise<never>(
      (_resolve, reject) => {

        timer = setTimeout(() => {

          reject(
            new Error("상태 확인 시간이 초과되었습니다.")
          );

        }, timeoutMs);
      }
    );

    return await Promise.race([
      operation,
      timeout
    ]);

  } finally {

    if (timer) {
      clearTimeout(timer);
    }
  }
}

// ============================================================
// GET /health
// ============================================================

healthRouter.get(
  "/",

  (_req, res) => {

    res.setHeader(
      "Cache-Control",
      "no-store"
    );

    res.status(200).json({

      success: true,

      data: {
        status: "ok"
      },

      message: "서버가 실행 중입니다."

    });
  }
);

// ============================================================
// GET /health/live
// ============================================================

// 프로세스가 HTTP 요청을 처리할 수 있는지 확인합니다.
//
// DB 연결 상태와는 별도로 동작합니다.

healthRouter.get(
  "/live",

  (_req, res) => {

    res.setHeader(
      "Cache-Control",
      "no-store"
    );

    res.status(200).json({

      success: true,

      data: {
        status: "alive"
      },

      message: "서버 프로세스가 정상 동작 중입니다."

    });
  }
);

// ============================================================
// GET /health/ready
// ============================================================

// PostgreSQL과 Redis가 실제로 요청을
// 처리할 수 있는지 확인합니다.

healthRouter.get(
  "/ready",

  asyncHandler(async (_req, res) => {

    res.setHeader(
      "Cache-Control",
      "no-store"
    );

    const results = await Promise.allSettled([

      withTimeout(
        Promise.resolve(
          prisma.$queryRaw`SELECT 1`
        ),
        2000
      ),

      withTimeout(
        redis.ping(),
        2000
      )

    ]);

    const databaseReady =
      results[0].status === "fulfilled";

    const redisReady =
      results[1].status === "fulfilled";

    if (!databaseReady || !redisReady) {

      // 외부 응답에는 내부 접속 주소나
      // 구체적인 DB 오류를 노출하지 않습니다.

      res.status(503).json({

        success: false,

        errorCode: "SERVICE_NOT_READY",

        message: "일부 서비스 연결이 준비되지 않았습니다."

      });

      return;
    }

    res.status(200).json({

      success: true,

      data: {
        status: "ready",
        database: "ready",
        redis: "ready"
      },

      message: "모든 필수 서비스가 준비되었습니다."

    });
  })
);
'@


# ============================================================
# 11. 전역 오류 처리
# ============================================================

Save-Source5 "apps/api/src/bootstrap/error-handler.ts" "전역 오류 분류, 민감 정보 보호 및 표준 JSON 오류 응답" @'
import type {
  ErrorRequestHandler,
  RequestHandler
} from "express";

import multer from "multer";

import {
  AppError
} from "../common/errors";

import {
  logger
} from "../infrastructure/logger";

// ============================================================
// HTTP 오류 구조
// ============================================================

type ErrorInformation = {

  statusCode: number;

  errorCode: string;

  message: string;

};

// ============================================================
// 상태 코드 안전성 검사
// ============================================================

function normalizeStatus(
  value: unknown
): number {

  if (
    typeof value === "number" &&
    Number.isInteger(value) &&
    value >= 400 &&
    value <= 599
  ) {

    return value;
  }

  return 500;
}

// ============================================================
// 오류 분류
// ============================================================

function classifyError(
  error: unknown
): ErrorInformation {

  // ----------------------------------------------------------
  // 애플리케이션 오류
  // ----------------------------------------------------------

  if (error instanceof AppError) {

    // 기존 AppError 구현에서 status 또는
    // statusCode를 사용할 수 있으므로
    // 두 형태를 확인합니다.

    const appError = error as AppError & {

      status?: number;

      statusCode?: number;

      errorCode?: string;

    };

    const statusCode = normalizeStatus(
      appError.statusCode ?? appError.status
    );

    return {

      statusCode,

      errorCode:
        appError.errorCode ?? "APPLICATION_ERROR",

      message:
        statusCode >= 500
          ? "서버 내부 오류가 발생했습니다."
          : appError.message

    };
  }

  // ----------------------------------------------------------
  // Multer 파일 업로드 오류
  // ----------------------------------------------------------

  if (error instanceof multer.MulterError) {

    if (error.code === "LIMIT_FILE_SIZE") {

      return {
        statusCode: 413,
        errorCode: "FILE_TOO_LARGE",
        message: "파일 크기가 허용 용량을 초과했습니다."
      };
    }

    if (error.code === "LIMIT_UNEXPECTED_FILE") {

      return {
        statusCode: 400,
        errorCode: "UNEXPECTED_FILE",
        message: "허용되지 않은 파일 필드입니다."
      };
    }

    return {
      statusCode: 400,
      errorCode: "INVALID_UPLOAD",
      message: "파일 업로드 요청이 올바르지 않습니다."
    };
  }

  // ----------------------------------------------------------
  // 일반 오류 정보
  // ----------------------------------------------------------

  const candidate = (
    typeof error === "object" && error !== null
      ? error
      : {}
  ) as {

    type?: string;

    code?: string;

    status?: number;

    statusCode?: number;

  };

  // ----------------------------------------------------------
  // JSON 요청 크기 초과
  // ----------------------------------------------------------

  if (candidate.type === "entity.too.large") {

    return {
      statusCode: 413,
      errorCode: "REQUEST_TOO_LARGE",
      message: "요청 데이터 크기가 너무 큽니다."
    };
  }

  // ----------------------------------------------------------
  // 잘못된 JSON
  // ----------------------------------------------------------

  if (candidate.type === "entity.parse.failed") {

    return {
      statusCode: 400,
      errorCode: "INVALID_JSON",
      message: "JSON 요청 형식이 올바르지 않습니다."
    };
  }

  // ----------------------------------------------------------
  // Prisma 중복 데이터 오류
  // ----------------------------------------------------------

  if (candidate.code === "P2002") {

    return {
      statusCode: 409,
      errorCode: "DUPLICATE_RESOURCE",
      message: "이미 존재하는 데이터입니다."
    };
  }

  // ----------------------------------------------------------
  // Prisma 데이터 없음
  // ----------------------------------------------------------

  if (candidate.code === "P2025") {

    return {
      statusCode: 404,
      errorCode: "RESOURCE_NOT_FOUND",
      message: "요청한 데이터를 찾을 수 없습니다."
    };
  }

  // ----------------------------------------------------------
  // 기타 오류
  // ----------------------------------------------------------

  return {
    statusCode: 500,
    errorCode: "INTERNAL_SERVER_ERROR",
    message: "서버 내부 오류가 발생했습니다."
  };
}

// ============================================================
// 존재하지 않는 API 처리
// ============================================================

export const notFoundHandler: RequestHandler = (
  _req,
  res
) => {

  res.setHeader(
    "Content-Type",
    "application/json; charset=utf-8"
  );

  res.status(404).json({

    success: false,

    errorCode: "ROUTE_NOT_FOUND",

    message: "요청한 API 주소를 찾을 수 없습니다."

  });
};

// ============================================================
// 전역 오류 처리
// ============================================================

export const globalErrorHandler: ErrorRequestHandler = (
  error,
  req,
  res,
  next
) => {

  // 응답이 이미 시작된 경우에는
  // Express에 연결 종료 처리를 위임합니다.

  if (res.headersSent) {

    next(error);

    return;
  }

  const information = classifyError(error);

  const requestId = String(
    res.locals.requestId ?? ""
  );

  // ----------------------------------------------------------
  // 구조화된 오류 로깅
  // ----------------------------------------------------------

  if (information.statusCode >= 500) {

    logger.error({

      err: error,

      requestId,

      method: req.method,

      path: req.path,

      statusCode: information.statusCode

    }, "서버 요청 처리 중 오류가 발생했습니다.");

  } else {

    logger.warn({

      requestId,

      method: req.method,

      path: req.path,

      statusCode: information.statusCode,

      errorCode: information.errorCode

    }, "요청이 오류 응답으로 종료되었습니다.");
  }

  // ----------------------------------------------------------
  // UTF-8 JSON 오류 응답
  // ----------------------------------------------------------

  res.setHeader(
    "Content-Type",
    "application/json; charset=utf-8"
  );

  res.status(information.statusCode).json({

    success: false,

    errorCode: information.errorCode,

    message: information.message

  });
};
'@


# ============================================================
# 12. Express 애플리케이션
# ============================================================

Save-Source5 "apps/api/src/bootstrap/app.ts" "Express 보안 미들웨어 및 전체 API 라우터 통합" @'
import crypto from "node:crypto";

import express from "express";

import helmet from "helmet";

import cors from "cors";

import cookieParser from "cookie-parser";

import {
  rateLimit
} from "express-rate-limit";

import {
  RedisStore
} from "rate-limit-redis";

import {
  env
} from "../config/env";

import {
  redis
} from "../infrastructure/redis";

import {
  logger
} from "../infrastructure/logger";

import {
  authRouter
} from "../modules/auth/auth.controller";

import {
  notesRouter
} from "../modules/notes/notes.controller";

import {
  filesRouter
} from "../modules/files/files.controller";

import {
  healthRouter
} from "./health";

import {
  runtimeConfig
} from "./runtime.config";

import {
  notFoundHandler,
  globalErrorHandler
} from "./error-handler";

// ============================================================
// Express 애플리케이션 생성
// ============================================================

export const app = express();

// 서버 구현 정보를 노출하지 않습니다.
app.disable("x-powered-by");

// ============================================================
// Reverse Proxy 설정
// ============================================================

// 기본값은 0으로 프록시를 신뢰하지 않습니다.
//
// Nginx, AWS ALB 등의 프록시를 사용하는 경우
// 실제 네트워크 구조를 확인한 뒤 설정해야 합니다.
//
// 무조건 trust proxy = true로 설정하지 않습니다.

app.set(
  "trust proxy",
  runtimeConfig.TRUST_PROXY_HOPS
);

// ============================================================
// 요청 ID 생성
// ============================================================

// 클라이언트가 보낸 요청 ID를 신뢰하지 않고
// 서버에서 새로운 UUID를 생성합니다.

app.use((req, res, next) => {

  const requestId = crypto.randomUUID();

  res.locals.requestId = requestId;

  res.setHeader(
    "X-Request-ID",
    requestId
  );

  next();
});

// ============================================================
// 구조화된 HTTP 요청 로깅
// ============================================================

app.use((req, res, next) => {

  const startedAt = process.hrtime.bigint();

  res.on("finish", () => {

    const durationMs = Number(
      process.hrtime.bigint() - startedAt
    ) / 1000000;

    // 비밀번호, JWT, 쿠키, 요청 본문은
    // 로그에 기록하지 않습니다.
    //
    // URL의 Query String도 기록하지 않습니다.

    logger.info({

      requestId: res.locals.requestId,

      method: req.method,

      path: req.path,

      statusCode: res.statusCode,

      durationMs: Math.round(
        durationMs * 100
      ) / 100

    }, "HTTP 요청 처리가 완료되었습니다.");
  });

  next();
});

// ============================================================
// Helmet 보안 헤더
// ============================================================

app.use(
  helmet({

    // API 서버의 기본 보안 헤더를 적용합니다.
    //
    // CSP는 웹 페이지를 제공하는 Next.js에서도
    // 별도로 설정해야 합니다.

    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'none'"],
        frameAncestors: ["'none'"]
      }
    }

  })
);

// ============================================================
// CORS 허용 출처
// ============================================================

const allowedOrigins = new Set(
  env.CORS_ORIGIN_LIST
);

// ============================================================
// Origin 검증
// ============================================================

// 허용되지 않은 Origin을 가진 요청은 거부합니다.
//
// 모바일 앱처럼 Origin 헤더가 없는 요청은
// 이 검사만으로 차단하지 않습니다.
//
// Origin 헤더는 인증 수단이 아니므로
// 실제 접근 권한은 JWT로 검증해야 합니다.

app.use((req, res, next) => {

  const origin = req.headers.origin;

  if (
    origin &&
    !allowedOrigins.has(origin)
  ) {

    res.status(403).json({

      success: false,

      errorCode: "CORS_ORIGIN_FORBIDDEN",

      message: "허용되지 않은 출처의 요청입니다."

    });

    return;
  }

  next();
});

// ============================================================
// CORS 설정
// ============================================================

app.use(
  cors({

    origin: (origin, callback) => {

      // Origin이 없는 요청은
      // CORS 응답 헤더 없이 처리합니다.
      //
      // 모바일 앱과 서버 간 통신은
      // 브라우저 CORS 정책의 적용 대상이 아닙니다.

      if (!origin) {

        callback(null, false);

        return;
      }

      if (allowedOrigins.has(origin)) {

        callback(null, origin);

        return;
      }

      callback(null, false);
    },

    credentials: true,

    methods: [
      "GET",
      "POST",
      "PUT",
      "PATCH",
      "DELETE",
      "OPTIONS"
    ],

    allowedHeaders: [
      "Content-Type",
      "Authorization",
      "X-Request-ID"
    ],

    exposedHeaders: [
      "X-Request-ID"
    ],

    maxAge: 600

  })
);

// ============================================================
// JSON 요청 본문 크기 제한
// ============================================================

app.use(
  express.json({

    limit: runtimeConfig.JSON_BODY_LIMIT,

    strict: true,

    type: "application/json"

  })
);

// ============================================================
// Cookie Parser
// ============================================================

// 웹 브라우저 Refresh Token은
// HttpOnly Cookie를 통해 전달됩니다.

app.use(
  cookieParser()
);

// ============================================================
// UTF-8 JSON 기본 설정
// ============================================================

app.use((req, res, next) => {

  // 파일 다운로드 응답에서는
  // 파일 Controller가 Content-Type을 다시 지정합니다.

  res.setHeader(
    "Content-Type",
    "application/json; charset=utf-8"
  );

  next();
});

// ============================================================
// 공통 API Rate Limiting
// ============================================================

// 모든 API에 공통 요청 제한을 적용합니다.
//
// 인증 API와 파일 업로드 API에는
// 기존 모듈의 개별 요청 제한도 추가 적용됩니다.
//
// Redis 장애 시에는 요청을 우회 허용하지 않고
// 오류 처리 경로로 전달합니다.

const apiLimiter = rateLimit({

  windowMs: 15 * 60 * 1000,

  limit: 300,

  standardHeaders: "draft-7",

  legacyHeaders: false,

  store: new RedisStore({

    prefix: "rate:api:",

    sendCommand: async (...args: string[]) => {

      return await redis.sendCommand(args);
    }

  }),

  handler: (_req, res) => {

    res.status(429).json({

      success: false,

      errorCode: "API_RATE_LIMITED",

      message: "API 요청 횟수 제한을 초과했습니다."

    });
  }

});

// ============================================================
// 헬스체크 라우터
// ============================================================

// Redis에 장애가 발생해도 /health/live는
// 독립적으로 응답할 수 있도록
// 공통 Redis Rate Limiter보다 먼저 등록합니다.

app.use(
  "/health",
  healthRouter
);

// ============================================================
// 공통 API 요청 제한
// ============================================================

app.use(
  "/api/v1",
  apiLimiter
);

// ============================================================
// 인증 API
// ============================================================

app.use(
  "/api/v1/auth",
  authRouter
);

// ============================================================
// 게시글 CRUD API
// ============================================================

app.use(
  "/api/v1/notes",
  notesRouter
);

// ============================================================
// 파일 관리 API
// ============================================================

app.use(
  "/api/v1/files",
  filesRouter
);

// ============================================================
// 존재하지 않는 경로 처리
// ============================================================

app.use(
  notFoundHandler
);

// ============================================================
// 전역 오류 처리
// ============================================================

// 반드시 모든 라우터보다 뒤에 등록합니다.

app.use(
  globalErrorHandler
);
'@


# ============================================================
# 13. 서버 실행 및 안전한 종료
# ============================================================

Save-Source5 "apps/api/src/bootstrap/server.ts" "PostgreSQL과 Redis 연결 후 HTTP 서버 실행 및 안전한 종료" @'
import "dotenv/config";

import {
  createServer
} from "node:http";

import {
  app
} from "./app";

import {
  runtimeConfig
} from "./runtime.config";

import {
  prisma
} from "../infrastructure/prisma";

import {
  redis
} from "../infrastructure/redis";

import {
  logger
} from "../infrastructure/logger";

// ============================================================
// HTTP 서버 생성
// ============================================================

const server = createServer(app);

// ============================================================
// HTTP 타임아웃
// ============================================================

// 지나치게 오래 유지되는 요청을 제한합니다.

server.requestTimeout = 60000;

server.headersTimeout = 15000;

server.keepAliveTimeout = 5000;

// ============================================================
// Redis 연결 준비
// ============================================================

async function prepareRedis(): Promise<void> {

  // node-redis는 명시적인 connect()가 필요할 수 있습니다.
  // 이미 연결된 클라이언트에는 중복 연결을 시도하지 않습니다.
  //
  // ioredis처럼 자동 연결하는 클라이언트는
  // ping()으로 연결 상태를 확인합니다.

  const client = redis as typeof redis & {

    isOpen?: boolean;

    connect?: () => Promise<unknown>;

  };

  if (
    typeof client.isOpen === "boolean" &&
    !client.isOpen &&
    typeof client.connect === "function"
  ) {

    await client.connect();
  }

  await redis.ping();
}

// ============================================================
// Redis 연결 종료
// ============================================================

async function closeRedis(): Promise<void> {

  const client = redis as unknown as {

    isOpen?: boolean;

    quit?: () => Promise<unknown>;

    disconnect?: () => Promise<unknown> | void;

    destroy?: () => void;

  };

  if (client.isOpen === false) {
    return;
  }

  if (typeof client.quit === "function") {

    await client.quit();

    return;
  }

  if (typeof client.disconnect === "function") {

    await client.disconnect();

    return;
  }

  if (typeof client.destroy === "function") {

    client.destroy();
  }
}

// ============================================================
// HTTP 서버 종료
// ============================================================

async function closeHttpServer(): Promise<void> {

  let timer: NodeJS.Timeout | undefined;

  try {

    await Promise.race([

      new Promise<void>((resolve) => {

        server.close(() => {
          resolve();
        });
      }),

      new Promise<void>((resolve) => {

        timer = setTimeout(() => {

          // 정상 종료 제한 시간이 초과되면
          // 남아 있는 HTTP 연결을 종료합니다.

          server.closeAllConnections();

          resolve();

        }, runtimeConfig.SHUTDOWN_TIMEOUT_MS);
      })

    ]);

  } finally {

    if (timer) {
      clearTimeout(timer);
    }
  }
}

// ============================================================
// 종료 상태
// ============================================================

let shuttingDown = false;

// ============================================================
// 안전한 서버 종료
// ============================================================

async function shutdown(
  reason: string,
  exitCode: number
): Promise<void> {

  if (shuttingDown) {
    return;
  }

  shuttingDown = true;

  logger.info({
    reason
  }, "서버 종료 절차를 시작합니다.");

  try {

    // 새로운 HTTP 요청을 받지 않습니다.
    await closeHttpServer();

  } catch (error) {

    logger.error({
      err: error
    }, "HTTP 서버 종료 중 오류가 발생했습니다.");
  }

  // DB와 Redis 연결을 정리합니다.
  const results = await Promise.allSettled([

    prisma.$disconnect(),

    closeRedis()

  ]);

  for (const result of results) {

    if (result.status === "rejected") {

      logger.error({
        err: result.reason
      }, "외부 서비스 연결 종료에 실패했습니다.");
    }
  }

  logger.info(
    "서버 종료 절차가 완료되었습니다."
  );

  process.exitCode = exitCode;
}

// ============================================================
// 종료 신호 처리
// ============================================================

process.on("SIGINT", () => {

  void shutdown("SIGINT", 0);
});

process.on("SIGTERM", () => {

  void shutdown("SIGTERM", 0);
});

// ============================================================
// 처리되지 않은 Promise 오류
// ============================================================

process.on("unhandledRejection", (reason) => {

  logger.error({
    err: reason
  }, "처리되지 않은 Promise 오류가 발생했습니다.");

  void shutdown("unhandledRejection", 1);
});

// ============================================================
// 처리되지 않은 예외
// ============================================================

process.on("uncaughtException", (error) => {

  logger.error({
    err: error
  }, "처리되지 않은 예외가 발생했습니다.");

  void shutdown("uncaughtException", 1);
});

// ============================================================
// 서버 시작
// ============================================================

async function startServer(): Promise<void> {

  // ----------------------------------------------------------
  // PostgreSQL 연결
  // ----------------------------------------------------------

  logger.info(
    "PostgreSQL 연결을 확인합니다."
  );

  await prisma.$connect();

  // ----------------------------------------------------------
  // Redis 연결
  // ----------------------------------------------------------

  logger.info(
    "Redis 연결을 확인합니다."
  );

  await prepareRedis();

  // ----------------------------------------------------------
  // HTTP 서버 실행
  // ----------------------------------------------------------

  await new Promise<void>((resolve, reject) => {

    const onError = (error: Error) => {

      reject(error);
    };

    server.once("error", onError);

    server.listen(
      runtimeConfig.PORT,
      "0.0.0.0",
      () => {

        server.off("error", onError);

        resolve();
      }
    );
  });

  logger.info({

    port: runtimeConfig.PORT,

    environment:
      process.env.NODE_ENV ?? "development"

  }, "통합 API 서버가 시작되었습니다.");

  logger.info(
    "헬스체크: /health"
  );

  logger.info(
    "인증 API: /api/v1/auth"
  );

  logger.info(
    "게시글 API: /api/v1/notes"
  );

  logger.info(
    "파일 API: /api/v1/files"
  );
}

// ============================================================
// 시작 오류 처리
// ============================================================

startServer().catch(async (error) => {

  logger.error({
    err: error
  }, "API 서버 시작에 실패했습니다.");

  try {

    await prisma.$disconnect();

    await closeRedis();

  } catch (cleanupError) {

    logger.error({
      err: cleanupError
    }, "시작 실패 후 연결 정리에 실패했습니다.");
  }

  process.exit(1);
});
'@


# ============================================================
# 14. 통합 서버 설명서
# ============================================================

Save-Source5 "apps/api/src/bootstrap/README.md" "통합 API 서버 실행 방법 및 보안 설정 안내" @'
# Express 통합 서버

## 1. 개요

이 디렉터리는 인증, CRUD, 파일 관리 기능을
하나의 Express 서버로 통합합니다.

기존 API 모듈은 변경하지 않습니다.

## 2. 서버 주소

기본 포트는 4000입니다.

기본 주소:

http://localhost:4000

## 3. 환경 변수

PORT=4000

TRUST_PROXY_HOPS=0

JSON_BODY_LIMIT=1mb

SHUTDOWN_TIMEOUT_MS=10000

기존 DATABASE_URL, REDIS_URL, JWT 관련 설정은
기존 환경 설정 파일을 그대로 사용합니다.

## 4. 개발 실행

API 프로젝트에 tsx가 설치되어 있어야 합니다.

루트 디렉터리에서 실행:

npm run dev -w @starter/api

또는:

npm run dev

루트 dev 명령이 API와 웹을 동시에 실행하도록
설정되어 있는 경우 두 서버가 함께 실행됩니다.

## 5. 헬스체크

GET /health

GET /health/live

GET /health/ready

/health/live는 HTTP 프로세스 상태를 확인합니다.

/health/ready는 PostgreSQL과 Redis 연결을 확인합니다.

## 6. 인증 API

/api/v1/auth

웹과 모바일 앱이 동일한 회원 데이터를 사용합니다.

## 7. 게시글 API

/api/v1/notes

JWT 인증이 필요합니다.

## 8. 파일 API

/api/v1/files

JWT 인증이 필요합니다.

## 9. 보안 설정

Helmet을 사용하여 HTTP 보안 헤더를 적용합니다.

CORS는 기존 환경 변수에 등록된 출처만 허용합니다.

JSON 요청 본문 크기를 제한합니다.

Redis 기반 API 요청 제한을 적용합니다.

요청마다 새로운 Request ID를 생성합니다.

비밀번호와 인증 토큰은 HTTP 로그에 기록하지 않습니다.

## 10. Reverse Proxy

기본 TRUST_PROXY_HOPS는 0입니다.

프록시 서버를 사용하는 경우
실제 프록시 홉 수와 네트워크 구성을 확인해야 합니다.

잘못된 프록시 설정은 IP 기반 요청 제한의
신뢰성을 떨어뜨릴 수 있습니다.

## 11. 서버 종료

SIGINT 또는 SIGTERM을 받으면
새로운 HTTP 요청 수신을 중지합니다.

진행 중인 요청의 종료를 기다린 뒤
Prisma와 Redis 연결을 정리합니다.

## 12. 주의사항

기존 1~4부의 실제 TypeScript 타입 호환성은
빌드 검사를 통해 확인해야 합니다.

이 통합 서버만으로 모든 보안 검증이
완료되었다고 판단해서는 안 됩니다.

운영 환경에서는 HTTPS, 프록시 설정,
데이터베이스 권한, 인증 보안, 파일 검사,
백업 및 복구 정책을 추가로 검증해야 합니다.

## 13. 운영 배포

현재 통합 실행 명령은 개발 환경을 기준으로 합니다.

운영 배포에서는 TypeScript 빌드 결과를
실행하도록 별도 배포 구성을 검증해야 합니다.

운영 환경에 tsx 개발 실행 명령을
그대로 사용하는 것은 권장하지 않습니다.
'@


# ============================================================
# 15. API package.json 개발 명령 변경
# ============================================================

Write-Host ""
Write-Host "API 실행 명령을 통합 서버로 연결합니다." -ForegroundColor Cyan

# 기존 dev 명령을 보존합니다.
if ($ExistingDevCommand -ne $NewDevCommand) {

    $ApiPackage.scripts | Add-Member `
        -NotePropertyName "dev:previous" `
        -NotePropertyValue $ExistingDevCommand

    $ApiPackage.scripts.dev = $NewDevCommand
}

# 통합 서버 개발 실행 명령
if (
    $ApiPackage.scripts.PSObject.Properties.Name -notcontains
    "dev:integrated"
) {

    $ApiPackage.scripts | Add-Member `
        -NotePropertyName "dev:integrated" `
        -NotePropertyValue $NewDevCommand
}

# 통합 서버 직접 실행 명령
if (
    $ApiPackage.scripts.PSObject.Properties.Name -notcontains
    "start:integrated"
) {

    $ApiPackage.scripts | Add-Member `
        -NotePropertyName "start:integrated" `
        -NotePropertyValue "tsx src/bootstrap/server.ts"
}

# JSON으로 변환합니다.
$NewPackageJson = $ApiPackage |
    ConvertTo-Json -Depth 50

# UTF-8 BOM 없이 저장합니다.
[System.IO.File]::WriteAllText(
    $ApiPackagePath,
    $NewPackageJson + "`n",
    $Utf8NoBom
)

Write-Host "[수정 완료] apps/api/package.json" -ForegroundColor Green

# ============================================================
# 16. 루트 실행 명령 확인
# ============================================================

if (
    $RootPackage.scripts.dev -notmatch "@starter/api"
) {

    Write-Host ""
    Write-Host "[주의] 루트 dev 명령에서 API 워크스페이스를 찾지 못했습니다." -ForegroundColor Yellow
    Write-Host "API 서버는 npm run dev -w @starter/api 명령으로 실행하세요."
}

# ============================================================
# 17. 완료
# ============================================================

Write-Host ""
Write-Host "=========================================="
Write-Host " 5부 Express 통합 서버 생성 완료"
Write-Host "=========================================="
Write-Host ""

foreach ($RelativePath in $OutputFiles) {

    Write-Host "[생성 완료] $RelativePath" -ForegroundColor Green
}

Write-Host ""
Write-Host "기존 API 개발 실행 명령은 dev:previous로 보존했습니다."
Write-Host ""
Write-Host "package.json 원본 백업:"
Write-Host $BackupDirectory
Write-Host ""
Write-Host "다음 단계: 의존성 설치 및 TypeScript 빌드 검사"
Write-Host ""

