﻿# filepath: create-starter.ps1 - 풀스택 공통 프로젝트의 파일과 폴더를 UTF-8로 생성하는 스크립트

$ErrorActionPreference = "Stop"

# 프로젝트가 생성될 경로
$Root = Join-Path $PSScriptRoot "secure-starter"

# 보안 검토가 끝난 프로젝트에 예전 생성 코드를 덮어쓰지 않습니다.
if (Test-Path -LiteralPath (Join-Path $Root "SECURITY-REVISION.json")) {
    throw "보안 수정이 적용된 V5입니다. 이전 부별 생성 스크립트 적용을 차단합니다."
}


# 기존 프로젝트를 덮어쓰지 않도록 보호
if (Test-Path $Root) {
    throw "secure-starter 폴더가 이미 존재합니다. 기존 데이터를 보호하기 위해 생성을 중단합니다."
}

# UTF-8 BOM 없는 인코딩 설정
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)

# 파일을 생성하는 공통 함수
function Save-Source {
    param(
        [string]$RelativePath,
        [string]$Description,
        [string]$Content
    )

    $FullPath = Join-Path $Root $RelativePath
    $Directory = Split-Path $FullPath -Parent

    if (-not (Test-Path $Directory)) {
        New-Item -ItemType Directory -Path $Directory -Force | Out-Null
    }

    $Extension = [System.IO.Path]::GetExtension($RelativePath)

    # 파일 종류에 맞는 주석 형식 적용
    $Header = switch ($Extension) {
        ".ts"     { "// filepath: $RelativePath - $Description`n" }
        ".tsx"    { "// filepath: $RelativePath - $Description`n" }
        ".js"     { "// filepath: $RelativePath - $Description`n" }
        ".mjs"    { "// filepath: $RelativePath - $Description`n" }
        ".prisma" { "// filepath: $RelativePath - $Description`n" }
        ".css"    { "/* filepath: $RelativePath - $Description */`n" }
        ".sql"    { "-- filepath: $RelativePath - $Description`n" }
        ".yaml"   { "# filepath: $RelativePath - $Description`n" }
        ".yml"    { "# filepath: $RelativePath - $Description`n" }
        ".toml"   { "# filepath: $RelativePath - $Description`n" }
        ".md"     { "<!-- filepath: $RelativePath - $Description -->`n" }
        default {
            if ($RelativePath -match '(^|/)\.env') {
                "# filepath: $RelativePath - $Description`n"
            }
            elseif ($RelativePath -match '(^|/)\.gitignore$') {
                "# filepath: $RelativePath - $Description`n"
            }
            elseif ($RelativePath -match '(^|/)\.editorconfig$') {
                "# filepath: $RelativePath - $Description`n"
            }
            else {
                ""
            }
        }
    }

    # 파일 저장
    $FinalContent = $Header + $Content

    [System.IO.File]::WriteAllText(
        $FullPath,
        $FinalContent,
        $Utf8NoBom
    )

    Write-Host "[생성 완료] $RelativePath" -ForegroundColor Green
}

Write-Host ""
Write-Host "============================================"
Write-Host " 풀스택 공통 Starter Kit 생성 시작"
Write-Host "============================================"
Write-Host ""

New-Item -ItemType Directory -Path $Root | Out-Null


# ============================================================
# 루트 package.json
# ============================================================

Save-Source "package.json" "모노레포 전체 패키지와 실행 명령 관리" @'
{
  "_comment": "filepath: package.json - 웹과 백엔드의 공통 실행 명령을 관리합니다.",
  "name": "secure-fullstack-starter",
  "version": "1.0.0",
  "private": true,
  "workspaces": [
    "apps/api",
    "apps/web"
  ],
  "scripts": {
    "dev": "concurrently -n API,WEB -c blue,green \"npm run dev -w @starter/api\" \"npm run dev -w @starter/web\"",
    "build": "npm run build -w @starter/api && npm run build -w @starter/web",
    "db:generate": "npm run db:generate -w @starter/api",
    "db:migrate": "npm run db:migrate -w @starter/api",
    "db:deploy": "npm run db:deploy -w @starter/api",
    "test": "npm run test -w @starter/api",
    "start:api": "npm run start -w @starter/api",
    "start:web": "npm run start -w @starter/web",
    "audit": "npm audit"
  },
  "devDependencies": {
    "concurrently": "^9.2.1"
  },
  "engines": {
    "node": ">=22"
  }
}
'@


# ============================================================
# Git 제외 파일
# ============================================================

Save-Source ".gitignore" "민감 정보와 빌드 결과물을 버전 관리에서 제외" @'
# 의존성
node_modules/

# 환경 변수 및 비밀 정보
.env
.env.local
.env.production
.env.development
.env.test
apps/**/.env
apps/**/.env.local

# 빌드 결과물
dist/
.next/
out/
coverage/
*.tsbuildinfo

# 업로드 파일
uploads/
apps/api/uploads/

# 로그
*.log
logs/

# 운영체제
.DS_Store
Thumbs.db

# IDE
.vscode/
.idea/

# 임시 파일
*.tmp
*.bak
'@


# ============================================================
# 인코딩 공통 설정
# ============================================================

Save-Source ".editorconfig" "소스 파일의 UTF-8 인코딩과 줄바꿈 규칙 설정" @'
root = true

[*]
charset = utf-8
end_of_line = lf
insert_final_newline = true
indent_style = space
indent_size = 2
trim_trailing_whitespace = true

[*.md]
trim_trailing_whitespace = false

[*.sql]
indent_size = 2
'@


# ============================================================
# Docker 환경 변수
# ============================================================

Save-Source ".env.example" "로컬 PostgreSQL과 Redis 실행에 필요한 환경 변수 예시" @'
# 로컬 개발 전용 데이터베이스 계정
# 실제 서비스에서는 반드시 별도의 강력한 비밀번호를 사용하세요.

POSTGRES_USER=starter
POSTGRES_PASSWORD=replace_with_local_password
POSTGRES_DB=starterdb
'@


# ============================================================
# Docker Compose
# ============================================================

Save-Source "compose.yaml" "PostgreSQL과 Redis 로컬 개발 환경 구성" @'
services:
  postgres:
    image: postgres:16-alpine
    restart: unless-stopped

    environment:
      POSTGRES_USER: ${POSTGRES_USER:?데이터베이스_사용자_필수}
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD:?데이터베이스_비밀번호_필수}
      POSTGRES_DB: ${POSTGRES_DB:?데이터베이스_이름_필수}
      PGDATA: /var/lib/postgresql/data/pgdata

    ports:
      - "127.0.0.1:5432:5432"

    volumes:
      - postgres_data:/var/lib/postgresql/data

    healthcheck:
      test:
        - CMD-SHELL
        - pg_isready -U "$$POSTGRES_USER" -d "$$POSTGRES_DB"
      interval: 5s
      timeout: 5s
      retries: 10

  redis:
    image: redis:7-alpine
    restart: unless-stopped

    command:
      - redis-server
      - --appendonly
      - "yes"

    ports:
      - "127.0.0.1:6379:6379"

    volumes:
      - redis_data:/data

    healthcheck:
      test:
        - CMD
        - redis-cli
        - ping
      interval: 5s
      timeout: 3s
      retries: 10

volumes:
  postgres_data:
  redis_data:
'@


# ============================================================
# API package.json
# ============================================================

Save-Source "apps/api/package.json" "Express API 서버의 의존성과 실행 명령 관리" @'
{
  "_comment": "filepath: apps/api/package.json - 백엔드 서버의 패키지 설정입니다.",
  "name": "@starter/api",
  "version": "1.0.0",
  "private": true,
  "main": "dist/server.js",
  "scripts": {
    "dev": "tsx watch src/server.ts",
    "build": "tsc -p tsconfig.json",
    "start": "node dist/server.js",
    "db:generate": "prisma generate",
    "db:migrate": "prisma migrate dev",
    "db:deploy": "prisma migrate deploy",
    "test": "vitest run"
  },
  "dependencies": {
    "@prisma/client": "6.19.3",
    "bcrypt": "^6.0.0",
    "cookie-parser": "^1.4.7",
    "cors": "^2.8.5",
    "dotenv": "^16.6.1",
    "express": "^4.21.2",
    "express-rate-limit": "^7.5.1",
    "helmet": "^8.1.0",
    "jsonwebtoken": "^9.0.2",
    "multer": "^2.0.2",
    "pino": "^9.9.0",
    "pino-http": "^10.5.0",
    "rate-limit-redis": "^4.2.0",
    "redis": "^5.8.0",
    "zod": "^3.25.76"
  },
  "devDependencies": {
    "@types/bcrypt": "^6.0.0",
    "@types/cookie-parser": "^1.4.9",
    "@types/cors": "^2.8.19",
    "@types/express": "^4.17.23",
    "@types/jsonwebtoken": "^9.0.10",
    "@types/multer": "^2.0.0",
    "@types/node": "^22.18.0",
    "prisma": "6.19.3",
    "tsx": "^4.20.5",
    "typescript": "^5.9.2",
    "vitest": "^3.2.4"
  }
}
'@


# ============================================================
# TypeScript 설정
# ============================================================

Save-Source "apps/api/tsconfig.json" "백엔드 TypeScript 컴파일 및 엄격한 타입 검사 설정" @'
{
  "_comment": "filepath: apps/api/tsconfig.json - 백엔드 타입 검사 및 컴파일 설정",
  "compilerOptions": {
    "target": "ES2022",
    "module": "CommonJS",
    "moduleResolution": "Node",
    "lib": [
      "ES2022"
    ],
    "outDir": "./dist",
    "rootDir": "./src",
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true,
    "resolveJsonModule": true,
    "noUncheckedIndexedAccess": true,
    "types": [
      "node"
    ]
  },
  "include": [
    "src/**/*.ts"
  ],
  "exclude": [
    "node_modules",
    "dist",
    "src/**/*.test.ts"
  ]
}
'@


# ============================================================
# API 환경 변수
# ============================================================

Save-Source "apps/api/.env.example" "API 서버 실행에 필요한 환경 변수 예시" @'
# 실행 환경
NODE_ENV=development

# API 포트
PORT=4000

# PostgreSQL 연결
# 루트 .env 파일의 데이터베이스 계정과 동일하게 설정하세요.
DATABASE_URL=postgresql://starter:replace_with_local_password@localhost:5432/starterdb?schema=public

# Redis 연결
REDIS_URL=redis://127.0.0.1:6379

# JWT 서명용 비밀키
# 실제 사용 시 충분히 긴 난수 문자열로 반드시 변경하세요.
JWT_ACCESS_SECRET=REPLACE_WITH_A_RANDOM_SECRET_AT_LEAST_32_CHARACTERS_LONG

# 웹에서 API 호출을 허용할 출처
# 여러 개일 경우 쉼표로 구분합니다.
CORS_ORIGINS=http://localhost:3000

# 리버스 프록시 개수
# 로컬 개발 환경에서는 0을 사용합니다.
TRUST_PROXY_HOPS=0

# 업로드 디렉터리
UPLOAD_DIR=./uploads

# 로그 수준
LOG_LEVEL=info
'@


# ============================================================
# Prisma 데이터베이스 모델
# ============================================================

Save-Source "apps/api/prisma/schema.prisma" "회원, 인증 세션, 게시글, 첨부파일의 데이터베이스 모델 정의" @'
generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

// 회원 정보
model User {
  id            String   @id @default(uuid())
  email         String   @unique @db.VarChar(254)
  passwordHash  String
  name          String   @db.VarChar(60)
  tokenVersion  Int      @default(0)
  createdAt     DateTime @default(now())
  updatedAt     DateTime @updatedAt

  refreshSessions RefreshSession[]
  notes           Note[]
  files           StoredFile[]
}

// Refresh Token 세션
// 원본 토큰은 저장하지 않고 SHA-256 해시만 저장합니다.
model RefreshSession {
  id        String    @id @default(uuid())
  userId    String
  tokenHash String    @unique
  expiresAt DateTime
  revokedAt DateTime?
  createdAt DateTime  @default(now())

  user User @relation(fields: [userId], references: [id], onDelete: Cascade)

  @@index([userId])
  @@index([expiresAt])
}

// CRUD 예제 게시글
model Note {
  id        String   @id @default(uuid())
  ownerId   String
  title     String   @db.VarChar(120)
  content   String   @db.Text
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt

  owner User @relation(fields: [ownerId], references: [id], onDelete: Cascade)

  @@index([ownerId, createdAt])
}

// 업로드 파일 메타데이터
model StoredFile {
  id           String   @id @default(uuid())
  ownerId      String
  storageKey   String   @unique
  originalName String   @db.VarChar(255)
  mimeType     String   @db.VarChar(100)
  size         Int
  createdAt    DateTime @default(now())

  owner User @relation(fields: [ownerId], references: [id], onDelete: Cascade)

  @@index([ownerId, createdAt])
}
'@


# ============================================================
# 환경 변수 검증
# ============================================================

Save-Source "apps/api/src/config/env.ts" "환경 변수를 검증하고 안전한 설정 객체로 변환" @'
import "dotenv/config";
import { z } from "zod";

// 환경 변수의 타입과 필수 조건을 검사합니다.
const envSchema = z.object({
  NODE_ENV: z.enum([
    "development",
    "test",
    "production"
  ]).default("development"),

  PORT: z.coerce.number()
    .int()
    .min(1)
    .max(65535)
    .default(4000),

  DATABASE_URL: z.string()
    .min(1, "데이터베이스 연결 정보가 필요합니다."),

  REDIS_URL: z.string()
    .min(1, "Redis 연결 정보가 필요합니다."),

  JWT_ACCESS_SECRET: z.string()
    .min(32, "JWT 비밀키는 최소 32자 이상이어야 합니다."),

  CORS_ORIGINS: z.string()
    .min(1, "허용할 웹 출처를 설정해야 합니다."),

  TRUST_PROXY_HOPS: z.coerce.number()
    .int()
    .min(0)
    .max(10)
    .default(0),

  UPLOAD_DIR: z.string()
    .default("./uploads"),

  LOG_LEVEL: z.enum([
    "fatal",
    "error",
    "warn",
    "info",
    "debug",
    "trace"
  ]).default("info")
});

// 환경 변수에 문제가 있으면 서버 시작을 중단합니다.
const parsed = envSchema.safeParse(process.env);

if (!parsed.success) {
  const fields = parsed.error.issues
    .map((issue) => issue.path.join("."))
    .join(", ");

  throw new Error(
    `환경 변수 설정이 올바르지 않습니다. 확인할 항목: ${fields}`
  );
}

export const env = {
  ...parsed.data,

  CORS_ORIGIN_LIST: parsed.data.CORS_ORIGINS
    .split(",")
    .map((origin) => origin.trim())
    .filter(Boolean),

  IS_PRODUCTION: parsed.data.NODE_ENV === "production"
};
'@


# ============================================================
# Prisma 연결
# ============================================================

Save-Source "apps/api/src/infrastructure/prisma.ts" "Prisma 데이터베이스 연결을 공통으로 관리" @'
import { PrismaClient } from "@prisma/client";

// PrismaClient는 요청마다 생성하지 않고 재사용합니다.
export const prisma = new PrismaClient({
  log: [
    "warn",
    "error"
  ]
});

// 데이터베이스 연결 상태 확인
export async function checkDatabase(): Promise<boolean> {
  try {
    await prisma.$queryRaw`SELECT 1`;
    return true;
  } catch {
    return false;
  }
}

// 서버 종료 시 연결 정리
export async function closeDatabase(): Promise<void> {
  await prisma.$disconnect();
}
'@


# ============================================================
# Redis 연결
# ============================================================

Save-Source "apps/api/src/infrastructure/redis.ts" "Redis 연결과 종료 및 상태 확인 기능 제공" @'
import { createClient } from "redis";
import { env } from "../config/env";

export const redis = createClient({
  url: env.REDIS_URL
});

// Redis 오류 이벤트를 처리합니다.
redis.on("error", () => {
  // 비밀번호 등이 포함될 수 있는 연결 문자열은 기록하지 않습니다.
  console.error("Redis 연결에 문제가 발생했습니다.");
});

// Redis 연결
export async function connectRedis(): Promise<void> {
  if (!redis.isOpen) {
    await redis.connect();
  }
}

// Redis 상태 확인
export async function checkRedis(): Promise<boolean> {
  try {
    return (await redis.ping()) === "PONG";
  } catch {
    return false;
  }
}

// Redis 연결 종료
export async function closeRedis(): Promise<void> {
  if (redis.isOpen) {
    await redis.quit();
  }
}
'@


# ============================================================
# 구조화된 로깅
# ============================================================

Save-Source "apps/api/src/infrastructure/logger.ts" "비밀번호와 인증 토큰 노출을 방지하는 구조화된 로깅" @'
import pino from "pino";
import { env } from "../config/env";

// JSON 형태의 로그를 생성합니다.
export const logger = pino({
  level: env.LOG_LEVEL,

  base: {
    service: "starter-api",
    environment: env.NODE_ENV
  },

  // 민감한 HTTP 헤더가 로그에 남지 않도록 설정합니다.
  redact: {
    paths: [
      "req.headers.authorization",
      "req.headers.cookie",
      "res.headers.set-cookie",
      "password",
      "passwordHash",
      "refreshToken",
      "accessToken"
    ],
    censor: "[보안상 비공개]"
  }
});
'@


# ============================================================
# 공통 에러
# ============================================================

Save-Source "apps/api/src/common/errors.ts" "표준 에러 객체와 전역 예외 처리 구현" @'
import {
  ErrorRequestHandler,
  RequestHandler
} from "express";

import { Prisma } from "@prisma/client";
import multer from "multer";
import { logger } from "../infrastructure/logger";

// 애플리케이션에서 사용하는 표준 에러입니다.
export class AppError extends Error {
  constructor(
    public statusCode: number,
    public errorCode: string,
    message: string
  ) {
    super(message);
    this.name = "AppError";
  }
}

// 존재하지 않는 API 경로 처리
export const notFoundHandler: RequestHandler = (
  _req,
  _res,
  next
) => {
  next(
    new AppError(
      404,
      "NOT_FOUND",
      "요청한 API 경로를 찾을 수 없습니다."
    )
  );
};

// 전역 예외 처리기
export const errorHandler: ErrorRequestHandler = (
  error: unknown,
  req,
  res,
  _next
) => {
  if (res.headersSent) {
    return;
  }

  let statusCode = 500;
  let errorCode = "INTERNAL_SERVER_ERROR";
  let message = "서버에서 오류가 발생했습니다.";

  if (error instanceof AppError) {
    statusCode = error.statusCode;
    errorCode = error.errorCode;
    message = error.message;
  }

  // Prisma 고유 제약조건 오류
  else if (
    error instanceof Prisma.PrismaClientKnownRequestError
  ) {
    if (error.code === "P2002") {
      statusCode = 409;
      errorCode = "DUPLICATE_RESOURCE";
      message = "이미 등록된 정보입니다.";
    }
  }

  // 파일 업로드 오류
  else if (error instanceof multer.MulterError) {
    statusCode = 400;
    errorCode = "FILE_UPLOAD_ERROR";

    message =
      error.code === "LIMIT_FILE_SIZE"
        ? "파일 크기가 허용 용량을 초과했습니다."
        : "파일 업로드 요청이 올바르지 않습니다.";
  }

  // JSON 문법 오류
  else if (
    error instanceof SyntaxError &&
    "status" in error &&
    error.status === 400
  ) {
    statusCode = 400;
    errorCode = "INVALID_JSON";
    message = "요청 JSON 형식이 올바르지 않습니다.";
  }

  // 내부 오류만 상세 로그를 남깁니다.
  if (statusCode >= 500) {
    logger.error(
      {
        requestId: req.id,
        error
      },
      "API 요청 처리 중 내부 오류가 발생했습니다."
    );
  }

  res.status(statusCode).json({
    success: false,
    errorCode,
    message
  });
};
'@


# ============================================================
# 공통 응답
# ============================================================

Save-Source "apps/api/src/common/response.ts" "웹과 모바일 앱에서 공통으로 사용하는 API 응답 규격" @'
import { Response } from "express";

// 성공 응답 형식을 통일합니다.
export function success<T>(
  res: Response,
  data: T,
  message = "요청이 정상적으로 처리되었습니다.",
  statusCode = 200
): void {
  res.status(statusCode).json({
    success: true,
    data,
    message
  });
}

// 실패 응답 형식을 통일합니다.
export function failure(
  res: Response,
  statusCode: number,
  errorCode: string,
  message: string
): void {
  res.status(statusCode).json({
    success: false,
    errorCode,
    message
  });
}
'@


# ============================================================
# 요청값 검증
# ============================================================

Save-Source "apps/api/src/common/validate.ts" "Zod를 이용한 Body, Query, Params 요청값 검증" @'
import {
  RequestHandler
} from "express";

import {
  z,
  ZodTypeAny
} from "zod";

import { AppError } from "./errors";

// 검증할 요청 데이터 위치
type RequestTarget = "body" | "query" | "params";

// 요청값을 검증하는 공통 미들웨어
export function validate(
  target: RequestTarget,
  schema: ZodTypeAny
): RequestHandler {
  return (req, _res, next) => {
    const result = schema.safeParse(req[target]);

    if (!result.success) {
      const firstError = result.error.issues[0];

      return next(
        new AppError(
          400,
          "VALIDATION_ERROR",
          firstError?.message ??
            "요청 데이터가 올바르지 않습니다."
        )
      );
    }

    // 검증된 데이터만 이후 처리에 사용합니다.
    if (target === "body") {
      req.body = result.data;
    } else {
      req.validated ??= {};
      req.validated[target] = result.data;
    }

    next();
  };
}

// 비동기 컨트롤러 오류를 전역 처리기로 전달합니다.
export function asyncHandler(
  handler: RequestHandler
): RequestHandler {
  return (req, res, next) => {
    Promise.resolve(handler(req, res, next)).catch(next);
  };
}

// 여러 API에서 재사용하는 UUID 검증
export const uuidSchema = z.object({
  id: z.string()
    .uuid("올바른 식별자가 아닙니다.")
}).strict();
'@


# ============================================================
# Express 타입 확장
# ============================================================

Save-Source "apps/api/src/types/express.d.ts" "인증 사용자와 검증된 요청값을 Express 타입에 추가" @'
declare global {
  namespace Express {
    interface Request {
      userId?: string;

      validated?: {
        body?: unknown;
        query?: unknown;
        params?: unknown;
      };
    }
  }
}

export {};
'@


# ============================================================
# 페이징 공통 DTO
# ============================================================

Save-Source "apps/api/src/common/pagination.ts" "페이지 번호와 조회 개수 및 검색어 검증" @'
import { z } from "zod";

// 페이지 번호는 1부터 시작합니다.
// 최대 조회 개수는 100개로 제한합니다.
export const paginationSchema = z.object({
  page: z.coerce.number()
    .int()
    .min(1)
    .default(1),

  limit: z.coerce.number()
    .int()
    .min(1)
    .max(100)
    .default(20),

  search: z.string()
    .trim()
    .max(100)
    .optional()
    .default("")
});

export type PaginationQuery =
  z.infer<typeof paginationSchema>;

// Prisma skip 계산
export function getSkip(
  page: number,
  limit: number
): number {
  return (page - 1) * limit;
}

// 표준 페이징 응답 생성
export function paginated<T>(
  items: T[],
  total: number,
  page: number,
  limit: number
) {
  return {
    items,
    pagination: {
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit),
      hasNext: page * limit < total,
      hasPrevious: page > 1
    }
  };
}
'@


# ============================================================
# JWT 인증 미들웨어
# ============================================================

Save-Source "apps/api/src/common/auth.middleware.ts" "JWT 검증과 회원별 접근 권한 검사" @'
import {
  RequestHandler
} from "express";

import jwt from "jsonwebtoken";

import { env } from "../config/env";
import { prisma } from "../infrastructure/prisma";
import { AppError } from "./errors";
import { asyncHandler } from "./validate";

// Access Token 발급
export function createAccessToken(
  userId: string,
  tokenVersion: number
): string {
  return jwt.sign(
    {
      ver: tokenVersion
    },
    env.JWT_ACCESS_SECRET,
    {
      algorithm: "HS256",
      subject: userId,
      issuer: "starter-api",
      audience: "starter-clients",
      expiresIn: "15m"
    }
  );
}

// Access Token 검증
export const requireAuth: RequestHandler = asyncHandler(
  async (req, _res, next) => {
    const authorization = req.headers.authorization;

    if (
      !authorization ||
      !authorization.startsWith("Bearer ")
    ) {
      throw new AppError(
        401,
        "UNAUTHORIZED",
        "로그인이 필요합니다."
      );
    }

    const token = authorization.slice(7);

    let payload: jwt.JwtPayload;

    try {
      const decoded = jwt.verify(
        token,
        env.JWT_ACCESS_SECRET,
        {
          algorithms: ["HS256"],
          issuer: "starter-api",
          audience: "starter-clients"
        }
      );

      if (typeof decoded === "string") {
        throw new Error("토큰 형식 오류");
      }

      payload = decoded;
    } catch {
      throw new AppError(
        401,
        "INVALID_TOKEN",
        "인증 토큰이 만료되었거나 올바르지 않습니다."
      );
    }

    if (
      typeof payload.sub !== "string" ||
      typeof payload.ver !== "number"
    ) {
      throw new AppError(
        401,
        "INVALID_TOKEN",
        "인증 정보가 올바르지 않습니다."
      );
    }

    // 회원 탈퇴 또는 전체 로그아웃 여부를 확인합니다.
    const user = await prisma.user.findUnique({
      where: {
        id: payload.sub
      },
      select: {
        id: true,
        tokenVersion: true
      }
    });

    if (
      !user ||
      user.tokenVersion !== payload.ver
    ) {
      throw new AppError(
        401,
        "SESSION_REVOKED",
        "로그인 세션이 종료되었습니다."
      );
    }

    req.userId = user.id;

    next();
  }
);
'@


# ============================================================
# Redis 기반 Rate Limiting
# ============================================================

Save-Source "apps/api/src/infrastructure/rate-limit.ts" "Redis 기반 API 요청 횟수 제한과 브루트포스 방어" @'
import { rateLimit } from "express-rate-limit";
import { RedisStore } from "rate-limit-redis";

import { redis } from "./redis";
import { failure } from "../common/response";

// Redis 저장소를 생성합니다.
// 서버가 여러 대여도 요청 횟수를 공유합니다.
function createStore(prefix: string) {
  return new RedisStore({
    prefix,

    sendCommand: async (...args: string[]) => {
      return await redis.sendCommand(args);
    }
  });
}

// 일반 API 요청 제한
export const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 120,

  standardHeaders: "draft-7",
  legacyHeaders: false,

  store: createStore("rate:api:"),

  handler: (_req, res) => {
    failure(
      res,
      429,
      "RATE_LIMITED",
      "요청이 너무 많습니다. 잠시 후 다시 시도해 주세요."
    );
  }
});

// 로그인 및 회원가입 요청 제한
export const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,

  standardHeaders: "draft-7",
  legacyHeaders: false,

  store: createStore("rate:auth:"),

  handler: (_req, res) => {
    failure(
      res,
      429,
      "AUTH_RATE_LIMITED",
      "인증 요청이 너무 많습니다. 15분 후 다시 시도해 주세요."
    );
  }
});

// Refresh Token 갱신 요청 제한
export const refreshLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 30,

  standardHeaders: "draft-7",
  legacyHeaders: false,

  store: createStore("rate:refresh:"),

  handler: (_req, res) => {
    failure(
      res,
      429,
      "REFRESH_RATE_LIMITED",
      "토큰 갱신 요청이 너무 많습니다."
    );
  }
});
'@


# ============================================================
# 생성 완료 안내
# ============================================================

Write-Host ""
Write-Host "공통 인프라 파일 생성이 완료되었습니다." -ForegroundColor Cyan
Write-Host "프로젝트 경로: $Root"
Write-Host ""

