'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');

const {
  UnsupportedModulesError,
  UNMAPPED_POD_ALLOWLIST,
  classifyUnsupported,
  unmappedPodDependencies,
  renderUnsupportedReport,
  reportUnsupported,
  renderUnmappedDependencyWarning,
  renderLeftOutCompanionWarning,
  collectDuplicatePods,
  collectRootConflicts,
  renderRootConflictWarning,
  renderPartlyProvidedPackageWarning,
  renderExtraPodsWarning,
  renderBuildFromSourceFallbackWarning,
} = require('../diagnostics');
const { spmUpdateCommand } = require('../commands');
const { resolvePodIdentities, uncoveredPod } = require('../plugin');
const { podspecDependencies } = require('../podspec');

/** An uncovered pod, from the facts the plugin gathers and the refusal pass 2 recorded. */
const pendingPod = ({ hasSources = true, prebuildProduct = null, refusal = null, ...subject }) =>
  uncoveredPod({ ...subject, prebuildProduct, sources: { hasSources } }, refusal);

describe('classifyUnsupported', () => {
  it('reports a missing interface tree once, not per module', () => {
    const entries = classifyUnsupported({
      pending: [
        { podName: 'ExpoAudio', packageName: 'expo-audio', moduleRoot: '/m/expo-audio' },
        { podName: 'EXUpdates', packageName: 'expo-updates', moduleRoot: '/m/expo-updates' },
      ],
      coreAvailable: false,
    });
    expect(entries).toEqual([{ reason: 'core-unavailable', pods: ['ExpoAudio', 'EXUpdates'] }]);
  });

  it('classifies a mixed-language module with no checked-in manifest', () => {
    const [entry] = classifyUnsupported({
      pending: [
        pendingPod({
          podName: 'ExpoAudio',
          packageName: 'expo-audio',
          moduleRoot: '/m/expo-audio',
          hasSources: true,
        }),
      ],
      coreAvailable: true,
    });
    expect(entry).toMatchObject({ reason: 'mixed-no-manifest', podName: 'ExpoAudio' });
  });

  it('prefers the prebuild route when the module declares a prebuildable product', () => {
    const [entry] = classifyUnsupported({
      pending: [
        pendingPod({
          podName: 'ExpoAudio',
          packageName: 'expo-audio',
          moduleRoot: '/m/expo-audio',
          hasSources: true,
          prebuildProduct: { name: 'ExpoAudio', sourceOnly: false },
        }),
      ],
      coreAvailable: true,
    });
    expect(entry).toMatchObject({ reason: 'prebuild-available', podName: 'ExpoAudio' });
  });

  it('does not offer the prebuild route for a source-only product', () => {
    const [entry] = classifyUnsupported({
      pending: [
        pendingPod({
          podName: 'ExpoModulesWorkletsAdapter',
          packageName: 'expo-modules-core',
          moduleRoot: '/m/expo-modules-core',
          hasSources: true,
          prebuildProduct: { name: 'ExpoModulesWorkletsAdapter', sourceOnly: true },
        }),
      ],
      coreAvailable: true,
    });
    expect(entry).toMatchObject({ reason: 'mixed-no-manifest' });
  });

  it('classifies a module whose apple sources could not be located', () => {
    const [entry] = classifyUnsupported({
      pending: [
        pendingPod({
          podName: 'ExpoWeird',
          packageName: 'expo-weird',
          moduleRoot: '/m/expo-weird',
          hasSources: false,
        }),
      ],
      coreAvailable: true,
    });
    expect(entry).toMatchObject({ reason: 'no-apple-sources', podName: 'ExpoWeird' });
  });
});

describe('diagnostic priority', () => {
  it('asks for the prebuild first, even when the podspec also needs attention', () => {
    expect(
      classifyUnsupported({
        pending: [
          pendingPod({
            podName: 'ExpoBad',
            packageName: 'expo-bad',
            moduleRoot: '/m/expo-bad',
            hasSources: true,
            prebuildProduct: { name: 'ExpoBad', sourceOnly: false },
            refusal: {
              reason: 'needs-manifest-for-linkage',
              file: '/m/expo-bad/ios/ExpoBad.podspec',
              line: 19,
              snippet: "s.frameworks = 'Photos'",
            },
          }),
        ],
        coreAvailable: true,
      })
    ).toEqual([
      {
        reason: 'prebuild-available',
        podName: 'ExpoBad',
        packageName: 'expo-bad',
        moduleRoot: '/m/expo-bad',
        productName: 'ExpoBad',
      },
    ]);
  });
});

describe('diagnostic priority order', () => {
  const subject = { podName: 'ExpoBad', packageName: 'expo-bad', moduleRoot: '/m/expo-bad' };
  const reasonFor = (pod) => classifyUnsupported({ pending: [pod], coreAvailable: true })[0].reason;
  const podspecLinkage = {
    reason: 'needs-manifest-for-linkage',
    file: '/m/expo-bad/ios/ExpoBad.podspec',
    line: 19,
    snippet: "s.frameworks = 'Photos'",
  };
  const unresolvedTargets = { reason: 'unresolvable-target-path', targetNames: ['Main'] };

  it('reports the linkage before targets whose sources it could not find', () => {
    expect(reasonFor({ ...subject, refusals: [unresolvedTargets, podspecLinkage] })).toBe(
      'needs-manifest-for-linkage'
    );
  });

  it('asks for the prebuild before reporting targets it could not resolve', () => {
    expect(
      reasonFor(
        pendingPod({
          ...subject,
          refusal: unresolvedTargets,
          prebuildProduct: { name: 'ExpoBad', sourceOnly: false },
        })
      )
    ).toBe('prebuild-available');
  });
});

describe('a pod buildFromSource names that cannot be built from source', () => {
  const subject = { podName: 'ExpoBad', packageName: 'expo-bad', moduleRoot: '/m/expo-bad' };
  const forced = (refusal, hasSources = true) => ({
    ...pendingPod({
      ...subject,
      hasSources,
      prebuildProduct: { name: 'ExpoBad', sourceOnly: false },
      refusal,
    }),
    buildFromSourceEntry: 'expo-b.*',
  });
  const classify = (pod) => classifyUnsupported({ pending: [pod], coreAvailable: true });
  const podspecLinkage = {
    reason: 'needs-manifest-for-linkage',
    file: '/m/expo-bad/ios/ExpoBad.podspec',
    line: 19,
    snippet: "s.frameworks = 'Photos'",
  };

  it('is refused for buildFromSource, with what blocks the source build as the cause', () => {
    expect(classify(forced(null))).toEqual([
      {
        ...subject,
        reason: 'build-from-source-unsupported',
        buildFromSourceEntry: 'expo-b.*',
        cause: { reason: 'mixed-no-manifest', productName: 'ExpoBad' },
      },
    ]);
  });

  it('takes the most specific cause', () => {
    expect(classify(forced(podspecLinkage))[0].cause).toEqual(podspecLinkage);
  });

  const report = (refusal, hasSources) =>
    renderUnsupportedReport(classify(forced(refusal, hasSources)));

  it('says what failed, and how to use the precompiled XCFramework instead', () => {
    const text = report(null);
    expect(text).toContain(
      'error: Expo module "expo-bad" (pod ExpoBad) is listed in buildFromSource, but Swift Package Manager cannot build it from source.'
    );
    expect(text).toContain(
      `Remove "expo-b.*" from \`"expo": { "autolinking": { "buildFromSource": [...] } }\` (or its \`"ios"\` section) in your package.json, or narrow it so it no longer matches ExpoBad or expo-bad. The module's precompiled XCFramework is then used. Then run \`${spmUpdateCommand()}\` from your app directory again.`
    );
    expect(text).toContain('Module path: /m/expo-bad');
    expect(text).not.toContain('prebuild');
  });

  it.each([
    [
      'mixed sources and no manifest',
      null,
      true,
      'It mixes Swift and Objective-C/C++ sources and ships no Package.swift, and Swift Package Manager can build such a module only from a manifest that splits the two languages into separate targets.',
    ],
    [
      'no sources',
      null,
      false,
      'It has no `ios` or `apple` source directory for Swift Package Manager to compile.',
    ],
    [
      'linkage in its podspec',
      podspecLinkage,
      true,
      'Its podspec declares native linkage at /m/expo-bad/ios/ExpoBad.podspec:19, and it ships no Package.swift stating that linkage, so a package built from its sources would link less than CocoaPods does.',
    ],
    [
      'a manifest target dependency',
      {
        reason: 'unsupported-target-dependency',
        dependencies: [{ target: 'ExpoBad', dependsOn: 'VendoredKit', kind: 'binary' }],
      },
      true,
      'Its Package.swift has targets depending on "VendoredKit", which the package generated from it cannot declare.',
    ],
    [
      'a manifest package dependency',
      { reason: 'unsupported-package-dependency', dependencies: [] },
      true,
      'Its Package.swift declares Swift packages the package generated from it cannot declare.',
    ],
    [
      'manifest targets without sources',
      { reason: 'unresolvable-target-path', targetNames: ['Main', 'Extras'] },
      true,
      'Its Package.swift names targets with no sources on disk: "Main", "Extras".',
    ],
    [
      'a manifest that does not export the product',
      { reason: 'not-exported-by-manifest', productName: 'ExpoBad', exportedProducts: [] },
      true,
      'Its Package.swift exports no "ExpoBad" library product.',
    ],
    [
      'precompiled sibling pods',
      {
        reason: 'partially-precompiled',
        precompiledSiblings: ['ExpoGood'],
        precompiledProducts: ['ExpoGood'],
        artifactDirs: [],
      },
      true,
      'Other pods of the module are linked precompiled (ExpoGood), and building the module from source would link them a second time.',
    ],
  ])('names the cause: %s', (_, refusal, hasSources, why) => {
    expect(report(refusal, hasSources)).toContain(why);
  });

  it('gives a cause it has no description for a generic line, naming the reason', () => {
    const text = renderUnsupportedReport([
      {
        ...subject,
        reason: 'build-from-source-unsupported',
        buildFromSourceEntry: 'ExpoBad',
        cause: { reason: 'some-future-reason' },
      },
    ]);
    expect(text).toContain(
      'The plugin found no way to build it from source with Swift Package Manager (reason: some-future-reason).'
    );
    expect(text).toContain('Remove "ExpoBad" from');
  });

  describe('when a pattern links it precompiled and its XCFramework is incomplete', () => {
    const incomplete = { ...forced(null), precompiledIncomplete: true };

    it('is refused naming the entry, with what blocks the source build as the cause', () => {
      expect(classify(incomplete)).toEqual([
        {
          ...subject,
          reason: 'build-from-source-fallback-incomplete',
          buildFromSourceEntry: 'expo-b.*',
          cause: { reason: 'mixed-no-manifest', productName: 'ExpoBad' },
        },
      ]);
    });

    it('says what failed, why, and how to complete the XCFramework', () => {
      expect(renderUnsupportedReport(classify(incomplete))).toBe(
        [
          'error: The buildFromSource entry "expo-b.*" matches Expo module "expo-bad" (pod ExpoBad), which Swift Package Manager cannot build from source, and its precompiled XCFramework is incomplete, so it cannot be linked precompiled either.',
          '  It mixes Swift and Objective-C/C++ sources and ships no Package.swift, and Swift Package Manager can build such a module only from a manifest that splits the two languages into separate targets.',
          '  A buildFromSource pattern links a module precompiled when Swift Package Manager cannot build it from source, and the plugin links a precompiled XCFramework only when both its Debug and Release flavors are present.',
          `  Reinstall expo-bad so it ships both flavors, or, in the Expo repository, from its root, build both with \`node tools/bin/expotools.js prebuild expo-bad\`. Then run \`${spmUpdateCommand()}\` from your app directory again.`,
          '  Module path: /m/expo-bad',
        ].join('\n')
      );
    });
  });

  it('counts the pod once', () => {
    expect(new UnsupportedModulesError(classify(forced(null))).message).toMatch(
      /^1 Expo native module /
    );
  });
});

describe('modules a buildFromSource pattern matches that are linked precompiled instead', () => {
  const option =
    '`"expo": { "autolinking": { "buildFromSource": [...] } }` (or its `"ios"` section) in your package.json';
  const core = { podName: 'ExpoModulesCore', packageName: 'expo-modules-core', entry: '.*' };

  it('renders nothing when no module fell back', () => {
    expect(renderBuildFromSourceFallbackWarning([])).toBe('');
  });

  it('names the module and the entry that matched it', () => {
    expect(renderBuildFromSourceFallbackWarning([core])).toBe(
      'warning: buildFromSource matches 1 Expo module that Swift Package Manager cannot build from source, so it is linked precompiled instead: ExpoModulesCore (expo-modules-core, matched by ".*"). ' +
        'A buildFromSource pattern links a module precompiled when Swift Package Manager cannot build that module from source; an entry that names a module exactly fails the sync instead. ' +
        `To see what blocks a module's source build, list it by its exact pod or npm package name in ${option}: the sync then fails and names the cause. ` +
        `To keep it precompiled without this warning, narrow ".*" so that no entry matches this module. Then run \`${spmUpdateCommand()}\` from your app directory again.`
    );
  });

  it('names every module, and each entry once', () => {
    const text = renderBuildFromSourceFallbackWarning([
      core,
      { podName: 'ExpoMixed', packageName: 'expo-mixed', entry: 'expo-.*' },
      { podName: 'ExpoOther', packageName: 'expo-other', entry: 'expo-.*' },
    ]);
    expect(text).toContain(
      'buildFromSource matches 3 Expo modules that Swift Package Manager cannot build from source, so they are linked precompiled instead: ExpoModulesCore (expo-modules-core, matched by ".*"), ExpoMixed (expo-mixed, matched by "expo-.*"), ExpoOther (expo-other, matched by "expo-.*").'
    );
    expect(text).toContain(
      'To keep them precompiled without this warning, narrow ".*", "expo-.*" so that no entry matches these modules.'
    );
  });
});

describe('linkage declared in a podspec', () => {
  const podspecLinkage = {
    file: '/m/expo-bad/ios/ExpoBad.podspec',
    line: 19,
    snippet: "s.frameworks = 'Photos', 'PhotosUI'",
  };
  const entries = () =>
    classifyUnsupported({
      pending: [
        pendingPod({
          podName: 'ExpoBad',
          packageName: 'expo-bad',
          moduleRoot: '/m/expo-bad',
          refusal: { reason: 'needs-manifest-for-linkage', ...podspecLinkage },
        }),
      ],
      coreAvailable: true,
    });

  it('classifies a module whose linkage only its podspec declares', () => {
    expect(entries()).toEqual([
      {
        reason: 'needs-manifest-for-linkage',
        podName: 'ExpoBad',
        packageName: 'expo-bad',
        moduleRoot: '/m/expo-bad',
        ...podspecLinkage,
      },
    ]);
  });

  it('points at the line, and at the two ways to declare linkage instead', () => {
    const report = renderUnsupportedReport(entries());
    expect(report).toContain('error: Expo module "expo-bad" (pod ExpoBad)');
    expect(report).toContain('/m/expo-bad/ios/ExpoBad.podspec:19');
    expect(report).toContain("s.frameworks = 'Photos', 'PhotosUI'");
    expect(report).toContain('linkerSettings');
    expect(report).toContain('spm.config.json');
    expect(report).toContain('patch-package expo-bad');
  });
});

describe('podspecDependencies', () => {
  it('extracts single- and double-quoted dependency names', () => {
    const text = [
      'Pod::Spec.new do |s|',
      "  s.dependency 'ExpoModulesCore'",
      '  s.dependency "SDWebImage", "~> 5.19"',
      "  s.dependency 'SDWebImageWebPCoder'",
      'end',
    ].join('\n');
    expect(podspecDependencies(text)).toEqual([
      'ExpoModulesCore',
      'SDWebImage',
      'SDWebImageWebPCoder',
    ]);
  });

  it('ignores test-spec dependencies', () => {
    const text = [
      "  s.dependency 'ExpoModulesCore'",
      "  s.test_spec 'Tests' do |test_spec|",
      "    test_spec.dependency 'Quick'",
      "    test_spec.dependency 'Nimble'",
      '  end',
    ].join('\n');
    expect(podspecDependencies(text)).toEqual(['ExpoModulesCore']);
  });

  it('returns an empty list for a podspec with no dependencies', () => {
    expect(podspecDependencies('Pod::Spec.new do |s|\nend\n')).toEqual([]);
  });
});

describe('unmappedPodDependencies', () => {
  it('keeps third-party pods and drops the SwiftPM-covered families', () => {
    const deps = [
      'ExpoModulesCore',
      'EXManifests',
      'React-Core',
      'RCTRequired',
      'ReactCommon/turbomodule/core',
      'expo-dev-menu-interface',
      'SDWebImage',
      'ZXingObjC/OneD',
    ];
    expect(unmappedPodDependencies(deps)).toEqual(['SDWebImage', 'ZXingObjC/OneD']);
  });

  it('drops pods that are already known to resolve without a podspec', () => {
    expect(UNMAPPED_POD_ALLOWLIST.has('sqlite3')).toBe(true);
    expect(unmappedPodDependencies(['sqlite3', 'SDWebImage'])).toEqual(['SDWebImage']);
  });

  it('drops a dependency whose full name or root name is a resolved SwiftPM dependency', () => {
    expect(
      unmappedPodDependencies(
        ['SDWebImage', 'libavif', 'libavif/libdav1d', 'ZXingObjC/OneD'],
        new Set(['SDWebImage', 'libavif'])
      )
    ).toEqual(['ZXingObjC/OneD']);
  });
});

describe('renderUnsupportedReport', () => {
  it('tells a mixed-language module how to add a manifest, patch it, and upstream it', () => {
    const text = renderUnsupportedReport([
      {
        reason: 'mixed-no-manifest',
        podName: 'ExpoAudio',
        packageName: 'expo-audio',
        moduleRoot: '/m/expo-audio',
      },
    ]);
    expect(text).toContain('error: ');
    expect(text).toContain('expo-audio');
    expect(text).toContain('Package.swift');
    expect(text).toContain('patch-package expo-audio');
    expect(text).toContain('exclude');
  });

  it('names the app package.json exclude key verbatim so it can be copied', () => {
    const text = renderUnsupportedReport([
      {
        reason: 'mixed-no-manifest',
        podName: 'ExpoAudio',
        packageName: 'expo-audio',
        moduleRoot: '/m/expo-audio',
      },
    ]);
    expect(text).toContain('"expo": { "autolinking": { "exclude": ["expo-audio"] } }');
  });

  it('emits one error line per module so Xcode surfaces each', () => {
    const text = renderUnsupportedReport([
      { reason: 'mixed-no-manifest', podName: 'A', packageName: 'a', moduleRoot: '/m/a' },
      { reason: 'mixed-no-manifest', podName: 'B', packageName: 'b', moduleRoot: '/m/b' },
    ]);
    expect(text.split('\n').filter((l) => l.startsWith('error: '))).toHaveLength(2);
  });

  it('tells a prebuildable module to run the prebuild command, not to write a manifest', () => {
    const text = renderUnsupportedReport([
      {
        reason: 'prebuild-available',
        podName: 'ExpoAudio',
        packageName: 'expo-audio',
        moduleRoot: '/m/expo-audio',
        productName: 'ExpoAudio',
      },
    ]);
    expect(text).toContain('error: ');
    // The prebuild command builds both flavors when --flavor is omitted, and the plugin
    // requires a complete pair — so the message must not suggest a single flavor.
    expect(text).toContain('node tools/bin/expotools.js prebuild expo-audio');
    expect(text).toMatch(/in the Expo repository, from its root/i);
    expect(text).not.toContain('-f Debug');
    expect(text).not.toContain('patch-package');
  });

  it('names the scoped package verbatim, which the prebuild command accepts', () => {
    const text = renderUnsupportedReport([
      {
        reason: 'prebuild-available',
        podName: 'ExpoUI',
        packageName: '@expo/ui',
        moduleRoot: '/m/expo-ui',
        productName: 'ExpoUI',
      },
    ]);
    expect(text).toContain('node tools/bin/expotools.js prebuild @expo/ui');
  });

  it('offers spm.config.json as a route for a module that has none', () => {
    const text = renderUnsupportedReport([
      { reason: 'mixed-no-manifest', podName: 'ExpoGL', packageName: 'expo-gl', moduleRoot: '/m' },
    ]);
    expect(text).toContain('spm.config.json');
  });

  it('explains a missing interface tree without blaming the modules', () => {
    const text = renderUnsupportedReport([
      { reason: 'core-unavailable', pods: ['ExpoAudio', 'EXUpdates'] },
    ]);
    expect(text).toContain('error: ');
    expect(text).toContain('ExpoModulesCore');
    expect(text).toContain(
      'node tools/bin/expotools.js prebuild -f Debug expo-modules-core expo-modules-jsi'
    );
    expect(text).toContain(
      'node tools/bin/expotools.js prebuild -f Release expo-modules-core expo-modules-jsi'
    );
    expect(text).toMatch(/in the Expo repository, from its root/i);
    expect(text).not.toContain('patch-package');
  });

  it('explains a module with no locatable apple sources', () => {
    const text = renderUnsupportedReport([
      {
        reason: 'no-apple-sources',
        podName: 'ExpoWeird',
        packageName: 'expo-weird',
        moduleRoot: '/m/expo-weird',
      },
    ]);
    expect(text).toContain('error: ');
    expect(text).toContain('expo-weird');
    expect(text).toMatch(/ios|apple/);
  });

  describe('a gated companion product its module would leave out', () => {
    const companion = (autolinkWhen) =>
      renderUnsupportedReport([
        {
          reason: 'unchecked-autolink-condition',
          podName: 'ExpoCameraBarcodeScanning',
          productName: 'ExpoCameraBarcodeScanning',
          packageName: 'expo-camera',
          moduleRoot: '/m/expo-camera',
          precompiled: true,
          linkedThrough: 'ExpoCamera',
          autolinkWhen,
        },
      ]);

    const scannerProperty = 'expo.camera.barcode-scanner-enabled';
    const gates = {
      podfileProperty: {
        gate: 'a Podfile property',
        autolinkWhen: { podfileProperty: scannerProperty, disabledValue: 'false' },
        because: `the Podfile property "${scannerProperty}" is not "false"`,
        turnOff: `set "${scannerProperty}" to "false" in ios/Podfile.properties.json`,
      },
      podfilePropertyWithoutValue: {
        gate: 'a Podfile property with no disabled value',
        autolinkWhen: { podfileProperty: scannerProperty },
        because: `the Podfile property "${scannerProperty}" is set`,
        turnOff: `remove "${scannerProperty}" from ios/Podfile.properties.json`,
      },
    };

    it.each(Object.values(gates))(
      'says why CocoaPods links it and where to report it, for $gate',
      ({ autolinkWhen, because }) => {
        const text = companion(autolinkWhen);

        expect(text).toContain(`CocoaPods links "ExpoCameraBarcodeScanning" because ${because}.`);
        expect(text).toContain('Swift Package Manager cannot link "ExpoCameraBarcodeScanning" yet');
        expect(text).toContain('https://github.com/expo/expo/issues');
        expect(text).not.toContain('Package.swift');
      }
    );

    // `npx expo prebuild` rewrites Podfile.properties.json from config plugins.
    it.each(Object.values(gates))(
      'tells the app how to turn it off, by hand or through prebuild, for $gate',
      ({ autolinkWhen, turnOff }) => {
        expect(companion(autolinkWhen)).toContain(
          `If the app does not need "ExpoCameraBarcodeScanning", ${turnOff}. If ios/ is generated by npx expo prebuild, set the matching option in the module's config plugin instead.`
        );
      }
    );
  });

  describe('a gated companion product its checked-in manifest does not export', () => {
    const scannerGate = {
      podfileProperty: 'expo.camera.barcode-scanner-enabled',
      disabledValue: 'false',
    };
    const render = (autolinkWhen = scannerGate) =>
      renderUnsupportedReport([
        {
          reason: 'companion-not-exported-by-manifest',
          podName: 'ExpoCameraBarcodeScanning',
          productName: 'ExpoCameraBarcodeScanning',
          packageName: 'expo-camera',
          moduleRoot: '/m/expo-camera',
          autolinkWhen,
        },
      ]);

    it('says which product the manifest leaves out, and why its condition is met', () => {
      expect(render()).toContain(
        'error: Expo module "expo-camera" does not export its companion product "ExpoCameraBarcodeScanning" in its Package.swift, although the product\'s autolinkWhen condition is met: the Podfile property "expo.camera.barcode-scanner-enabled" is not "false".'
      );
    });

    it('says the feature would be missing at runtime', () => {
      const text = render();
      expect(text).toContain('CocoaPods links "ExpoCameraBarcodeScanning" for this app');
      expect(text).toContain('missing at runtime');
    });

    it('tells the module to export the product, not the app to remove a pod', () => {
      const text = render();
      expect(text).toContain(
        'Add a `.library(name: "ExpoCameraBarcodeScanning", …)` product to /m/expo-camera/Package.swift'
      );
      expect(text).not.toContain('remove the pod');
    });

    it('tells the app how to turn it off, for a Podfile property gate', () => {
      expect(render()).toContain(
        'If the app does not need "ExpoCameraBarcodeScanning", set "expo.camera.barcode-scanner-enabled" to "false" in ios/Podfile.properties.json. If ios/ is generated by npx expo prebuild, set the matching option in the module\'s config plugin instead.'
      );
    });

    it('offers no switch for a gate the app cannot turn off', () => {
      const text = render({ npmPackage: 'react-native-worklets' });

      expect(text).toContain('the app depends on react-native-worklets');
      expect(text).not.toContain('If the app does not need');
      expect(text).not.toContain('Podfile.properties.json');
    });
  });
});

describe('renderUnmappedDependencyWarning', () => {
  it('warns that a pod dependency has no SwiftPM equivalent and will fail to compile', () => {
    const text = renderUnmappedDependencyWarning([
      {
        packageName: 'expo-image',
        podName: 'ExpoImage',
        pods: ['SDWebImage', 'SDWebImageWebPCoder'],
      },
    ]);
    expect(text).toContain('warning: ');
    expect(text).toContain('expo-image');
    expect(text).toContain('SDWebImage');
    expect(text).toContain('SDWebImageWebPCoder');
  });

  it('returns an empty string when nothing is unmapped', () => {
    expect(renderUnmappedDependencyWarning([])).toBe('');
  });
});

describe('renderLeftOutCompanionWarning', () => {
  const adapter = (autolinkWhen, precompiled = true) => ({
    podName: 'ExpoModulesWorkletsAdapter',
    productName: 'ExpoModulesWorkletsAdapter',
    packageName: 'expo-modules-core',
    moduleRoot: '/m/expo-modules-core',
    precompiled,
    linkedThrough: 'ExpoModulesCore',
    autolinkWhen,
  });

  it.each([
    {
      gate: 'a pod',
      autolinkWhen: { podName: 'RNWorklets' },
      because: 'the app has the RNWorklets pod',
    },
    {
      gate: 'an npm package',
      autolinkWhen: { npmPackage: 'react-native-worklets' },
      because: 'the app depends on react-native-worklets',
    },
  ])(
    'says which product is left out although CocoaPods links it, for $gate',
    ({ autolinkWhen, because }) => {
      const text = renderLeftOutCompanionWarning([adapter(autolinkWhen)]);

      expect(text).toContain(
        'warning: Expo module "expo-modules-core" links its pod ExpoModulesCore as a precompiled XCFramework, so its product "ExpoModulesWorkletsAdapter" is left out of the app.'
      );
      expect(text).toContain(`CocoaPods links "ExpoModulesWorkletsAdapter" because ${because}.`);
    }
  );

  it('says the feature is unavailable and how Swift Package Manager would link it', () => {
    const text = renderLeftOutCompanionWarning([adapter({ podName: 'RNWorklets' }, false)]);

    expect(text).toContain('from source without a checked-in Package.swift');
    expect(text).toContain('unavailable at runtime');
    expect(text).toContain('`.library(name: "ExpoModulesWorkletsAdapter", …)`');
    expect(text).toContain(
      'Otherwise, if the app needs "ExpoModulesWorkletsAdapter", build the app with CocoaPods.'
    );
    expect(text).not.toContain('until then');
    expect(text).not.toContain('https://github.com/expo/expo/issues');
    expect(text).not.toContain('error: ');
  });

  it('names every left-out companion', () => {
    const text = renderLeftOutCompanionWarning([
      adapter({ podName: 'RNWorklets' }),
      {
        ...adapter({ npmPackage: 'expo-camera' }),
        podName: 'ExpoCameraBarcodeScanning',
        productName: 'ExpoCameraBarcodeScanning',
        packageName: 'expo-camera',
      },
    ]);

    expect(text).toContain('"ExpoModulesWorkletsAdapter"');
    expect(text).toContain('"ExpoCameraBarcodeScanning"');
  });

  it('returns an empty string when nothing is left out', () => {
    expect(renderLeftOutCompanionWarning([])).toBe('');
  });
});

describe('reportUnsupported', () => {
  it('returns null and prints nothing when every module is covered', () => {
    const spy = jest.spyOn(console, 'error').mockImplementation(() => {});
    expect(reportUnsupported([])).toBeNull();
    expect(spy).not.toHaveBeenCalled();
    spy.mockRestore();
  });

  it('prints the report and returns an error carrying the entries', () => {
    const spy = jest.spyOn(console, 'error').mockImplementation(() => {});
    const entries = [
      {
        reason: 'mixed-no-manifest',
        podName: 'ExpoAudio',
        packageName: 'expo-audio',
        moduleRoot: '/m',
      },
    ];
    const error = reportUnsupported(entries);
    expect(spy).toHaveBeenCalledTimes(1);
    expect(error).toBeInstanceOf(UnsupportedModulesError);
    expect(error.unsupported).toEqual(entries);
    expect(error.message).toContain('1');
    spy.mockRestore();
  });
});

describe('unresolvable target paths', () => {
  const pending = [
    pendingPod({
      podName: 'ExpoFoo',
      packageName: 'expo-foo',
      moduleRoot: '/node_modules/expo-foo',
      hasSources: true,
      prebuildProduct: null,
      refusal: { reason: 'unresolvable-target-path', targetNames: ['Example'] },
    }),
  ];

  it('classifies a module whose target sources could not be located', () => {
    expect(classifyUnsupported({ pending, coreAvailable: true })).toEqual([
      {
        reason: 'unresolvable-target-path',
        podName: 'ExpoFoo',
        packageName: 'expo-foo',
        moduleRoot: '/node_modules/expo-foo',
        targetNames: ['Example'],
      },
    ]);
  });

  it('reports what failed, the likely cause and the next step', () => {
    const report = renderUnsupportedReport(classifyUnsupported({ pending, coreAvailable: true }));
    expect(report).toMatch(/^error: Expo module "expo-foo" \(pod ExpoFoo\)/);
    expect(report).toContain('"Example"');
    expect(report).toContain('Sources');
    expect(report).toContain('npx patch-package expo-foo');
    expect(report).toContain('Module path: /node_modules/expo-foo');
  });
});

describe('dependencies on targets the generated package cannot declare', () => {
  const podDependingOn = (dependencies) =>
    pendingPod({
      podName: 'ExpoFoo',
      packageName: 'expo-foo',
      moduleRoot: '/node_modules/expo-foo',
      hasSources: true,
      prebuildProduct: null,
      refusal: { reason: 'unsupported-target-dependency', dependencies },
    });
  const pending = [podDependingOn([{ target: 'ExpoFoo', dependsOn: 'FooKit', kind: 'binary' }])];

  it('classifies a module whose manifest depends on a non-regular target', () => {
    expect(classifyUnsupported({ pending, coreAvailable: true })).toEqual([
      {
        reason: 'unsupported-target-dependency',
        podName: 'ExpoFoo',
        packageName: 'expo-foo',
        moduleRoot: '/node_modules/expo-foo',
        dependencies: [{ target: 'ExpoFoo', dependsOn: 'FooKit', kind: 'binary' }],
      },
    ]);
  });

  it('names both targets, the kind, and the prebuild remedy', () => {
    const report = renderUnsupportedReport(classifyUnsupported({ pending, coreAvailable: true }));
    expect(report).toMatch(/^error: Expo module "expo-foo" \(pod ExpoFoo\)/);
    expect(report).toContain('"ExpoFoo"');
    expect(report).toContain('"FooKit"');
    expect(report).toContain('binary target');
    expect(report).toContain('spm.config.json');
    expect(report).toContain('packages/expo-sensors');
    expect(report).toContain('npx patch-package expo-foo');
    expect(report).toContain('Module path: /node_modules/expo-foo');
  });

  it('renders every kind as prose, and explains the rule without enumerating kinds', () => {
    const report = renderUnsupportedReport(
      classifyUnsupported({
        pending: [
          podDependingOn([
            { target: 'ExpoFoo', dependsOn: 'FooSystem', kind: 'systemLibrary' },
            { target: 'ExpoFoo', dependsOn: 'FooMystery' },
          ]),
        ],
        coreAvailable: true,
      })
    );
    expect(report).toContain('"FooSystem", a system library target');
    expect(report).not.toContain('systemLibrary');
    expect(report).not.toContain('undefined target');
    expect(report).not.toContain('binary, macro, plugin or system');
  });

  it('lists every dependency it found, not just the first', () => {
    const report = renderUnsupportedReport(
      classifyUnsupported({
        pending: [
          podDependingOn([
            { target: 'ExpoFoo', dependsOn: 'FooKit', kind: 'binary' },
            { target: 'ExpoFooObjC', dependsOn: 'FooMacros', kind: 'macro' },
          ]),
        ],
        coreAvailable: true,
      })
    );
    expect(report).toContain('"FooKit"');
    expect(report).toContain('"FooMacros"');
    expect(report).toContain('macro target');
  });
});

describe('a module installed twice', () => {
  let tmp;
  const dir = (...segments) => {
    const created = path.join(tmp, ...segments);
    fs.mkdirSync(created, { recursive: true });
    return created;
  };
  const conflicts = (documented, autolinked) =>
    collectRootConflicts(
      resolvePodIdentities(
        [{ packageName: 'expo-camera', pods: [{ podName: 'ExpoCamera' }] }],
        new Map([['ExpoCamera', { packageRoot: documented }]]),
        new Map([['expo-camera', autolinked]])
      )
    );

  beforeAll(() => {
    tmp = fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(), 'expo-spm-roots-')));
  });

  afterEach(() => jest.restoreAllMocks());

  it('finds no conflict when both roots are the same directory through a symlink', () => {
    const packageRoot = dir('node_modules', 'expo-camera');
    const link = path.join(dir('links'), 'expo-camera');
    fs.symlinkSync(packageRoot, link, 'dir');

    expect(conflicts(packageRoot, link)).toEqual([]);
  });

  it('finds a conflict when the two roots are different directories', () => {
    const packageRoot = dir('node_modules', 'expo-camera');
    const autolinkedRoot = dir('node_modules', 'some-lib', 'node_modules', 'expo-camera');

    expect(conflicts(packageRoot, autolinkedRoot)).toEqual([
      { packageName: 'expo-camera', moduleRoot: packageRoot, autolinkedRoot },
    ]);
  });

  it('finds no conflict for a documented root that is gone', () => {
    expect(conflicts(path.join(tmp, 'vanished'), dir('node_modules', 'expo-camera'))).toEqual([]);
  });

  // A path that cannot be resolved cannot be compared, and a diagnostic is never
  // worth failing a sync over.
  it('reports nothing, and does not throw, when a root cannot be resolved', () => {
    const packageRoot = dir('node_modules', 'expo-camera');
    jest.spyOn(fs, 'realpathSync').mockImplementation(() => {
      throw Object.assign(new Error('ENOENT'), { code: 'ENOENT' });
    });

    expect(conflicts(packageRoot, path.join(tmp, 'elsewhere'))).toEqual([]);
  });

  // The copies can be different versions, so the mismatch is not confined to runtime.
  it('names both directories, what uses each, both failure modes, and how to deduplicate', () => {
    const report = renderRootConflictWarning([
      {
        packageName: 'expo-camera',
        moduleRoot: '/app/node_modules/expo-camera',
        autolinkedRoot: '/app/node_modules/some-lib/node_modules/expo-camera',
      },
    ]);
    expect(report).toMatch(/^warning: Expo module "expo-camera"/);
    expect(report).toContain('/app/node_modules/expo-camera');
    expect(report).toContain('/app/node_modules/some-lib/node_modules/expo-camera');
    expect(report).toContain('npm ls expo-camera');
    expect(report).toContain('dedupe');
    expect(report).toContain(spmUpdateCommand());
    expect(report).toContain("your app's JavaScript imports the second");
    expect(report).toContain('usually surfaces at runtime');
    expect(report).toContain('can fail the build');
  });

  it('renders nothing when no module is installed twice', () => {
    expect(renderRootConflictWarning([])).toBe('');
  });
});

describe('a package kept for more than the products a precompiled framework provides', () => {
  it('names the package, both sets of products, why that can duplicate one, and the fixes', () => {
    const report = renderPartlyProvidedPackageWarning([
      {
        packageName: 'expo-maps-extra',
        moduleRoot: '/app/node_modules/expo-maps-extra',
        url: 'https://github.com/SDWebImage/SDWebImage.git',
        providedProducts: ['SDWebImage'],
        keptProducts: ['SDWebImageMapKit'],
      },
    ]);
    expect(report).toMatch(
      /^warning: Expo module "expo-maps-extra" still declares https:\/\/github\.com\/SDWebImage\/SDWebImage\.git for "SDWebImageMapKit"/
    );
    expect(report).toContain('"SDWebImage" comes from a precompiled framework');
    expect(report).toContain('second copy');
    expect(report).toContain('stop using "SDWebImageMapKit"');
    expect(report).toContain('from source');
    expect(report).toContain('Module path: /app/node_modules/expo-maps-extra');
  });

  it('names a product depended on by name without a package, and every package kept', () => {
    const report = renderPartlyProvidedPackageWarning([
      {
        packageName: 'expo-maps-extra',
        moduleRoot: '/app/node_modules/expo-maps-extra',
        providedProducts: ['SDWebImage'],
        keptPackages: ['https://github.com/SDWebImage/libavif-Xcode.git'],
      },
    ]);
    expect(report).toMatch(
      /^warning: Expo module "expo-maps-extra" names "SDWebImage" without a package, and it comes from a precompiled framework\./
    );
    expect(report).toContain(
      'may still build it from https://github.com/SDWebImage/libavif-Xcode.git, which'
    );
    expect(report).toContain('stop using https://github.com/SDWebImage/libavif-Xcode.git');
    expect(report).toContain('from source');
    expect(report).toContain('Module path: /app/node_modules/expo-maps-extra');
  });

  it('says "one of" only when more than one package is still declared', () => {
    const report = renderPartlyProvidedPackageWarning([
      {
        packageName: 'expo-maps-extra',
        moduleRoot: '/app/node_modules/expo-maps-extra',
        providedProducts: ['SDWebImage'],
        keptPackages: [
          'https://github.com/SDWebImage/libavif-Xcode.git',
          'https://github.com/airbnb/lottie-spm.git',
        ],
      },
    ]);
    expect(report).toContain(
      'may still build it from one of https://github.com/SDWebImage/libavif-Xcode.git, https://github.com/airbnb/lottie-spm.git, which'
    );
  });

  // Only the package's own products can be attributed to it.
  it('names a remaining byName dependency as possibly, not certainly, from the package', () => {
    const report = renderPartlyProvidedPackageWarning([
      {
        packageName: 'expo-maps-extra',
        moduleRoot: '/app/node_modules/expo-maps-extra',
        url: 'https://github.com/SDWebImage/SDWebImage.git',
        providedProducts: ['SDWebImage'],
        keptProducts: [],
        unattributedNames: ['Lottie'],
      },
    ]);
    expect(report).toMatch(
      /^warning: Expo module "expo-maps-extra" still declares https:\/\/github\.com\/SDWebImage\/SDWebImage\.git, while "SDWebImage" comes from a precompiled framework\./
    );
    expect(report).not.toContain('for "Lottie"');
    expect(report).not.toContain('for ""');
    expect(report).toContain('names "Lottie" without a package, which may come from it');
  });

  it('names each product the module uses once, joined as alternatives', () => {
    const report = renderPartlyProvidedPackageWarning([
      {
        packageName: 'expo-maps-extra',
        moduleRoot: '/app/node_modules/expo-maps-extra',
        url: 'https://github.com/SDWebImage/SDWebImage.git',
        providedProducts: ['SDWebImage'],
        keptProducts: ['SDWebImageMapKit'],
        unattributedNames: ['SDWebImageMapKit', 'Lottie'],
      },
    ]);
    expect(report).toContain('If "SDWebImageMapKit" or "Lottie" depends on "SDWebImage"');
    expect(report).toContain('stop using "SDWebImageMapKit" or "Lottie" in "expo-maps-extra"');
  });

  it('renders nothing when every such package was left out', () => {
    expect(renderPartlyProvidedPackageWarning([])).toBe('');
  });
});

describe('separate copies of one pod name', () => {
  let tmp;
  beforeAll(() => {
    tmp = fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(), 'expo-spm-copies-')));
  });
  const dir = (name) => {
    const created = path.join(tmp, name);
    fs.mkdirSync(created, { recursive: true });
    return created;
  };
  const duplicatesIn = (...listings) =>
    collectDuplicatePods(
      new Map(
        listings.map(([packageName, declaringRoot], index) => [
          index,
          { podName: 'ExpoX', packageName, declaringRoot },
        ])
      )
    );

  // P at r1 and P at r2 are one package; Q at r2 is the directory P at r2 is in.
  // Joined either way, all three are one copy.
  it('is one copy for listings joined through a shared package or directory, in any order', () => {
    const a = ['expo-p', dir('r1')];
    const b = ['expo-q', dir('r2')];
    const c = ['expo-p', dir('r2')];

    for (const order of [
      [a, b, c],
      [a, c, b],
      [b, a, c],
      [b, c, a],
      [c, a, b],
      [c, b, a],
    ]) {
      expect(duplicatesIn(...order)).toEqual([]);
    }
  });

  it('shows each copy by its lowest root, in any order', () => {
    const a = ['expo-p', dir('r1')];
    const c = ['expo-p', dir('r2')];
    const d = ['expo-z', dir('r3')];
    const copies = [
      { packageName: 'expo-p', moduleRoot: a[1] },
      { packageName: 'expo-z', moduleRoot: d[1] },
    ];

    for (const order of [
      [a, c, d],
      [a, d, c],
      [c, a, d],
      [c, d, a],
      [d, a, c],
      [d, c, a],
    ]) {
      expect(duplicatesIn(...order)).toEqual([
        { reason: 'duplicate-pod-name', podName: 'ExpoX', copies },
      ]);
    }
  });

  it('is one copy for one directory reached through a symlink', () => {
    const link = path.join(tmp, 'alias');
    fs.symlinkSync(dir('shared'), link, 'dir');

    expect(duplicatesIn(['expo-a', dir('shared')], ['expo-b', link])).toEqual([]);
  });

  it('keeps two roots that cannot be resolved apart, in any order', () => {
    const a = ['expo-a', path.join(tmp, 'missing-a')];
    const b = ['expo-b', path.join(tmp, 'missing-b')];
    const duplicate = [
      {
        reason: 'duplicate-pod-name',
        podName: 'ExpoX',
        copies: [
          { packageName: a[0], moduleRoot: a[1] },
          { packageName: b[0], moduleRoot: b[1] },
        ],
      },
    ];

    expect(duplicatesIn(a, b)).toEqual(duplicate);
    expect(duplicatesIn(b, a)).toEqual(duplicate);
  });

  it('is one copy for one unresolvable root two packages name identically', () => {
    const missing = path.join(tmp, 'missing');

    expect(duplicatesIn(['expo-a', missing], ['expo-b', missing])).toEqual([]);
  });

  it('names every copy, why the sync fails, and how to keep one', () => {
    const report = renderUnsupportedReport([
      {
        reason: 'duplicate-pod-name',
        podName: 'ExpoX',
        copies: [
          { packageName: 'expo-x', moduleRoot: '/app/node_modules/expo-x' },
          { packageName: 'expo-x-fork', moduleRoot: '/app/node_modules/expo-x-fork' },
          { packageName: 'expo-x-next', moduleRoot: '/app/node_modules/expo-x-next' },
        ],
      },
    ]);

    expect(report).toMatch(/^error: The pod ExpoX is declared by 3 different packages/);
    expect(report).toContain('\n      "expo-x" at /app/node_modules/expo-x\n');
    expect(report).toContain('\n      "expo-x-fork" at /app/node_modules/expo-x-fork\n');
    expect(report).toContain('links a pod name only once');
    expect(report).toContain('"exclude": ["expo-x-fork", "expo-x-next"]');
  });
});

describe('extra CocoaPods dependencies', () => {
  const FIREBASE_GIT = 'https://github.com/firebase/firebase-ios-sdk.git';
  const origins = [
    [
      'MyLocalPod (local path: ../vendor/MyLocalPod)',
      { name: 'MyLocalPod', path: '../vendor/MyLocalPod' },
    ],
    [`Firebase (git: ${FIREBASE_GIT})`, { name: 'Firebase', git: FIREBASE_GIT }],
    ['AppCenter (published pod)', { name: 'AppCenter' }],
    [
      'InternalSDK (spec repo: https://specs.example.com/private.git, version 2.1.0)',
      { name: 'InternalSDK', source: 'https://specs.example.com/private.git', version: '2.1.0' },
    ],
    ['AppCenter (published pod, version 5.0.0)', { name: 'AppCenter', version: '5.0.0' }],
    // A git pod's ref is the only thing that says which code it means.
    [
      `Firebase (git: ${FIREBASE_GIT}, tag 10.0.0)`,
      { name: 'Firebase', git: FIREBASE_GIT, tag: '10.0.0' },
    ],
    [
      'Sentry (git: https://github.com/getsentry/sentry-cocoa.git, branch main)',
      { name: 'Sentry', git: 'https://github.com/getsentry/sentry-cocoa.git', branch: 'main' },
    ],
    [
      'Lottie (git: https://github.com/airbnb/lottie-ios.git, commit a1b2c3d)',
      { name: 'Lottie', git: 'https://github.com/airbnb/lottie-ios.git', commit: 'a1b2c3d' },
    ],
  ];
  const report = renderExtraPodsWarning(origins.map(([, pod]) => pod));

  it.each(origins)('lists %s', (line) => {
    expect(report).toContain(line);
  });

  it('says what declared them, how they fail, and what to do instead', () => {
    expect(report).toMatch(/^warning: /);
    expect(report).toContain('extraPods');
    expect(report).toContain('Podfile.properties.json');
    expect(report).toContain('fails to compile or link');
    expect(report).toContain('at runtime');
    expect(report).toContain('keep this app on CocoaPods');
  });

  it('renders nothing when the app declares none', () => {
    expect(renderExtraPodsWarning([])).toBe('');
  });
});

describe('Swift packages the generated package cannot declare', () => {
  const podDeclaring = (dependencies) =>
    pendingPod({
      podName: 'ExpoImage',
      packageName: 'expo-image',
      moduleRoot: '/node_modules/expo-image',
      hasSources: true,
      prebuildProduct: null,
      refusal: { reason: 'unsupported-package-dependency', dependencies },
    });
  const pending = [podDeclaring([{ form: 'local-path', identity: 'sdwebimage', target: null }])];

  const report = (unsupportedPackageDeps) =>
    renderUnsupportedReport(
      classifyUnsupported({
        pending: [podDeclaring(unsupportedPackageDeps)],
        coreAvailable: true,
      })
    );

  it('classifies a module whose manifest declares a package it cannot mirror', () => {
    expect(classifyUnsupported({ pending, coreAvailable: true })).toEqual([
      {
        reason: 'unsupported-package-dependency',
        podName: 'ExpoImage',
        packageName: 'expo-image',
        moduleRoot: '/node_modules/expo-image',
        dependencies: [{ form: 'local-path', identity: 'sdwebimage', target: null }],
      },
    ]);
  });

  it('names the package, what is wrong with it, and the next step', () => {
    const text = renderUnsupportedReport(classifyUnsupported({ pending, coreAvailable: true }));
    expect(text).toMatch(/^error: Expo module "expo-image" \(pod ExpoImage\)/);
    expect(text).toContain('"sdwebimage"');
    expect(text).toContain('local path');
    expect(text).toContain('npx patch-package expo-image');
    expect(text).toContain('Module path: /node_modules/expo-image');
  });

  it('names the target of a product whose package the manifest never declared', () => {
    const text = report([
      { form: 'undeclared-package', identity: 'libavif-Xcode', target: 'ExpoImage' },
    ]);
    expect(text).toContain('"libavif-Xcode"');
    expect(text).toContain('target "ExpoImage"');
  });

  it('describes a product that names no package without printing a placeholder', () => {
    const text = report([{ form: 'undeclared-package', identity: null, target: 'ExpoImage' }]);
    expect(text).toContain('target "ExpoImage"');
    expect(text).not.toContain('null');
    expect(text).not.toContain('undefined');
  });

  // One remedy cannot serve every cause: a collision is already declared the way a
  // local path should be, and an undeclared package needs a declaration ADDED.
  it('gives each fault its own next step', () => {
    const step = (form) => report([{ form, identity: 'acme', target: 'Main' }]);
    expect(step('local-path')).toContain('remote URL');
    expect(step('undeclared-package')).toContain('Declare that package');
    expect(step('unsupported-requirement')).toContain(
      'an exact version, a branch, a revision or a version range'
    );
    expect(step('module-aliases')).toContain('alias');
    expect(step('unsupported-condition')).toContain('platform');
    expect(step('collides-with-injected')).toContain('React Native');
    expect(step('collides-with-injected')).not.toContain('remote URL');
  });

  it('calls a package a package and a target dependency a dependency', () => {
    expect(
      report([{ form: 'unsupported-condition', identity: 'SDWebImage', target: 'Main' }])
    ).toContain('package "SDWebImage", used by target "Main",');
    const sibling = report([
      { form: 'unsupported-target-condition', identity: 'Helper', target: 'Main' },
    ]);
    expect(sibling).toContain('the dependency on "Helper" in target "Main"');
    expect(sibling).not.toContain('package "Helper"');
  });

  it('names a package claimed twice without calling either one the package', () => {
    const text = report([{ form: 'ambiguous-package-name', identity: 'libavif', target: null }]);
    expect(text).toContain('"libavif" is claimed by two');
    expect(text).toContain('distinct');
  });

  it('lists every dependency it found, not just the first', () => {
    const text = report([
      { form: 'registry', identity: 'acme.widgets', target: null },
      { form: 'unsupported-requirement', identity: 'futured', target: null },
    ]);
    expect(text).toContain('"acme.widgets"');
    expect(text).toContain('"futured"');
  });

  it('renders every form as prose, never as the name the parser uses for it', () => {
    const dependencies = [
      { form: 'local-path', identity: 'alpha', target: null },
      { form: 'registry', identity: 'bravo', target: null },
      { form: 'unsupported-location', identity: 'charlie', target: null },
      { form: 'unsupported-requirement', identity: 'delta', target: null },
      { form: 'unknown-form', identity: 'echo', target: null },
      { form: 'undeclared-package', identity: 'foxtrot', target: 'Main' },
      { form: 'collides-with-injected', identity: 'golf', target: null },
      { form: 'module-aliases', identity: 'hotel', target: 'Main' },
      { form: 'unsupported-condition', identity: 'india', target: 'Main' },
      { form: 'unsupported-traits', identity: 'juliett', target: null },
      { form: 'unsupported-target-condition', identity: 'kilo', target: 'Main' },
      { form: 'ambiguous-package-name', identity: 'lima', target: null },
    ];
    const text = report(dependencies);
    for (const { form, identity } of dependencies) {
      expect(text).toContain(`"${identity}"`);
      // "registry" is also the plain English word the prose uses.
      if (form !== 'registry') expect(text).not.toContain(form);
    }
    expect(text).not.toContain('undefined');
  });
});

describe('a module with only some pods precompiled', () => {
  const artifactDirs = [
    '/precompiled/expo-dual/output',
    '/repo/packages/precompile/.build/expo-dual/output',
    '/node_modules/expo-dual/prebuilds/output',
  ];
  const pending = ({
    prebuildProduct = null,
    precompiledSiblings = ['ExpoDual'],
    precompiledProducts = ['ExpoDual'],
  } = {}) =>
    pendingPod({
      podName: 'ExpoDualExtras',
      packageName: 'expo-dual',
      moduleRoot: '/node_modules/expo-dual',
      hasSources: true,
      prebuildProduct,
      refusal: {
        reason: 'partially-precompiled',
        precompiledSiblings,
        precompiledProducts,
        artifactDirs,
        prebuildProduct,
      },
    });
  const entries = (extra) =>
    classifyUnsupported({ pending: [pending(extra)], coreAvailable: true });

  it('classifies the pod that is not precompiled, naming the siblings that are', () => {
    expect(entries()).toEqual([
      {
        reason: 'partially-precompiled',
        podName: 'ExpoDualExtras',
        packageName: 'expo-dual',
        moduleRoot: '/node_modules/expo-dual',
        precompiledSiblings: ['ExpoDual'],
        precompiledProducts: ['ExpoDual'],
        artifactDirs,
        prebuildProduct: null,
      },
    ]);
  });

  it('reports it before the prebuild route, which would not explain the double link', () => {
    expect(
      entries({ prebuildProduct: { name: 'ExpoDualExtras', sourceOnly: false } })[0].reason
    ).toBe('partially-precompiled');
  });

  it('names both pods, the double link, and the all-or-none remedies', () => {
    const report = renderUnsupportedReport(entries());
    expect(report).toMatch(/^error: Expo module "expo-dual" \(pod ExpoDualExtras\)/);
    expect(report).toContain('ExpoDual ');
    expect(report).toContain('twice');
    expect(report).toContain('node tools/bin/expotools.js prebuild expo-dual');
    expect(report).toMatch(/in the Expo repository, from its root/i);
    expect(report).toContain('spm.config.json');
    expect(report).toContain('"exclude": ["expo-dual"]');
    expect(report).toContain('Module path: /node_modules/expo-dual');
  });

  it('lists every precompiled sibling', () => {
    const report = renderUnsupportedReport(
      entries({ precompiledSiblings: ['ExpoDual', 'ExpoDualKit'] })
    );
    expect(report).toContain('ExpoDual, ExpoDualKit');
  });

  it('names every directory the artifact resolver searches, in its order, and both artifact forms', () => {
    const report = renderUnsupportedReport(entries());
    const positions = artifactDirs.map((dir) => report.indexOf(dir));
    expect(positions.every((position) => position >= 0)).toBe(true);
    expect(positions).toEqual([...positions].sort((a, b) => a - b));
    expect(report).toContain('ExpoDual.xcframework');
    expect(report).toContain('ExpoDual.tar.gz');
    expect(report).toContain('debug/xcframeworks');
    expect(report).toContain('release/xcframeworks');
    expect(report).toContain("add a product for ExpoDualExtras to expo-dual's spm.config.json");
  });

  it('names the artifacts after the product a sibling ships, not after its pod', () => {
    const report = renderUnsupportedReport(
      entries({ precompiledSiblings: ['RNSkiaPod'], precompiledProducts: ['RNSkia'] })
    );
    expect(report).toContain('— RNSkia.xcframework or RNSkia.tar.gz, under');
    expect(report).not.toContain('RNSkiaPod.xcframework');
    expect(report).toContain('its sibling pod RNSkiaPod does');
  });

  it('says so when spm.config.json already declares the pod it asks to build', () => {
    const report = renderUnsupportedReport(
      entries({ prebuildProduct: { name: 'ExpoDualExtras', sourceOnly: false } })
    );
    expect(report).toContain('already declares "ExpoDualExtras"');
    expect(report).toContain('node tools/bin/expotools.js prebuild expo-dual');
  });

  it('does not promise an XCFramework for a source-only product', () => {
    const report = renderUnsupportedReport(
      entries({ prebuildProduct: { name: 'ExpoDualExtras', sourceOnly: true } })
    );
    expect(report).toContain('sourceOnly');
    expect(report).not.toContain('expotools.js prebuild');
    expect(report).toMatch(/^ {2}1\. To build it from source instead/m);
  });
});
